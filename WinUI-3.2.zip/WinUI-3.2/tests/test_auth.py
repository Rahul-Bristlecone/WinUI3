from datetime import datetime, timedelta, timezone

import jwt

from conftest import PASSWORD, login, register
from supplier_service.auth.models import Supplier


def test_register_login_and_profile(client):
    code = register(client)["supplierCode"]
    assert code == Supplier.generate_supplier_code("Acme Traders")

    api = login(client, email="ACME@Example.com")  # emails are case-insensitive
    profile = api.get("/api/supplier/profile").json
    assert profile["email"] == "acme@example.com"
    assert profile["gstNumber"] == "27ABCDE1234F1Z5"  # normalised to upper case

    profile.update(city="Mumbai", email="ignored@example.com", supplierCode="IGNORED")
    updated = api.put("/api/supplier/profile", profile).json
    assert updated["city"] == "Mumbai"
    assert updated["email"] == "acme@example.com"
    assert updated["supplierCode"] == code


def test_same_day_supplier_codes_are_disambiguated(client):
    first = register(client, "a@example.com", "Acme Traders")["supplierCode"]
    second = register(client, "b@example.com", "ACME Foods")["supplierCode"]
    assert second == f"{first}-2"


def test_register_validation(client):
    register(client)
    r = client.post("/api/auth/register", json={"email": "acme@example.com"})
    assert r.status_code == 400 and r.json["message"] == "companyName is required."

    payload = {"companyName": "X", "contactPerson": "Y", "email": "acme@example.com", "password": PASSWORD,
               "phone": "+91 98765 43210", "address": "A", "city": "C", "state": "S", "country": "IN",
               "postalCode": "411001"}
    assert client.post("/api/auth/register", json=payload).status_code == 409
    weak = client.post("/api/auth/register", json={**payload, "email": "new@example.com", "password": "short"})
    assert weak.status_code == 400 and "at least 8 characters" in weak.json["message"]


def test_login_rejects_bad_credentials(client):
    register(client)
    r = client.post("/api/auth/login", json={"email": "acme@example.com", "password": "Wrong@1234"})
    assert r.status_code == 401
    assert r.json == {"message": "Invalid email or password."}


def test_change_password(client):
    register(client)
    api = login(client)
    wrong = api.post("/api/auth/change-password", {"currentPassword": "Nope@1234", "newPassword": "Newpass@123"})
    assert wrong.status_code == 400
    assert api.post("/api/auth/change-password", {"currentPassword": PASSWORD, "newPassword": "Newpass@123"}).status_code == 204
    assert client.post("/api/auth/login", json={"email": "acme@example.com", "password": PASSWORD}).status_code == 401
    login(client, password="Newpass@123")


def test_protected_endpoints_require_a_valid_token(app, client):
    register(client)
    assert client.get("/api/products").status_code == 401
    assert client.get("/api/products", headers={"Authorization": "Bearer not-a-jwt"}).status_code == 401

    expired = jwt.encode(
        {"sub": "1", "exp": datetime.now(timezone.utc) - timedelta(minutes=1)}, app.config["JWT_SECRET_KEY"], "HS256"
    )
    r = client.get("/api/products", headers={"Authorization": f"Bearer {expired}"})
    assert r.status_code == 401
    assert r.json["message"] == "Your session has expired. Please sign in again."
