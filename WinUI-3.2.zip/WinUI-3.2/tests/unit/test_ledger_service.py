"""ledger/service.py (business days, balances) and ledger/schemas.py (entry rules, statement lines)."""

from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

import pytest
from sqlalchemy import select

from supplier_service.config import utc_offset
from supplier_service.extensions.database import db
from supplier_service.invoices.models import Invoice
from supplier_service.invoices.schemas import InvoiceLineInput
from supplier_service.invoices.service import save_draft, send_invoice
from supplier_service.ledger import service as ledger_service
from supplier_service.ledger.models import EntryType, LedgerAccount, LedgerEntry
from supplier_service.ledger.schemas import (
    MAX_AMOUNT,
    EntryRequest,
    account_name,
    day_book_amounts,
    entry_json,
    invoice_entry_json,
)
from supplier_service.ledger.service import (
    Totals,
    business_day,
    business_today,
    day_start,
    ensure_online_accounts,
    last_payments,
    opening_balances,
    totals,
)
from supplier_service.retailers.models import Retailer

from .factories import (
    ledger_entry,
    make_order,
    make_product,
    make_retailer,
    offline_account,
    validation_message,
)

D = Decimal


def NOV(day: int) -> date:  # noqa: N802  (reads like a calendar)
    return date(2026, 11, day)


def sent_invoice(supplier, product, *, retailer_id=1, number="ORD-0001", sent_at=None) -> Invoice:
    """An order for 2 × 50.00, invoiced in full: 100 + 18% GST = 118.00."""
    order = make_order(supplier, [(product, 2, "50")], retailer_id=retailer_id, number=number)
    invoice = send_invoice(order, [InvoiceLineInput(order_line_id=order.items[0].id, invoiced_quantity=2)])
    if sent_at is not None:
        invoice.invoice_date = sent_at
    db.session.commit()
    return invoice


# -- business days ---------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "stamp, day",
    [
        (datetime(2026, 11, 4, 18, 29), NOV(4)),  # naive = UTC; 23:59 in India
        (datetime(2026, 11, 4, 18, 30), NOV(5)),  # midnight in India
        (datetime(2026, 11, 4, 20, 0, tzinfo=timezone(timedelta(hours=-5))), NOV(5)),
        (datetime(2026, 11, 5, 0, 0, tzinfo=timezone.utc), NOV(5)),
    ],
)
def test_business_day_of_a_timestamp(fixed_rates, stamp, day):
    assert business_day(stamp) == day


def test_a_business_day_starts_at_local_midnight_in_utc(app, fixed_rates, monkeypatch):
    assert day_start(NOV(5)) == datetime(2026, 11, 4, 18, 30)
    monkeypatch.setitem(app.config, "BUSINESS_TIMEZONE", utc_offset("-05:00"))
    assert day_start(NOV(5)) == datetime(2026, 11, 5, 5, 0)


@pytest.mark.parametrize("offset", ["+05:30", "-05:00", "+00:00", "+14:00"])
def test_day_start_and_business_day_agree(app, monkeypatch, offset):
    monkeypatch.setitem(app.config, "BUSINESS_TIMEZONE", utc_offset(offset))
    start = day_start(NOV(5))
    assert business_day(start) == NOV(5)
    assert business_day(start - timedelta(microseconds=1)) == NOV(4)


def test_business_today_follows_the_business_timezone(fixed_rates, monkeypatch):
    monkeypatch.setattr(ledger_service, "utcnow", lambda: datetime(2026, 11, 4, 19, 0, tzinfo=timezone.utc))
    assert business_today() == NOV(5)


def test_net_is_what_the_retailer_owes():
    assert Totals().net == 0
    assert Totals(opening=D(100), offline_orders=D(50), online_orders=D(118), payments=D(70)).net == D(198)
    assert Totals(payments=D(20)).net == D(-20)  # paid in advance


# -- totals ----------------------------------------------------------------------------------------


@pytest.fixture
def book(supplier, fixed_rates):
    """An offline account with a week of entries (one voided)."""
    account = offline_account(supplier)
    ledger_entry(account, EntryType.OPENING_BALANCE, 1000, NOV(1))
    ledger_entry(account, EntryType.OFFLINE_ORDER, 200, NOV(3))
    ledger_entry(account, EntryType.PAYMENT, 300, NOV(4), payment_mode="Cash")
    ledger_entry(account, EntryType.PAYMENT, 50, NOV(4), payment_mode="Cash", voided=True)
    ledger_entry(account, EntryType.OFFLINE_ORDER, 75, NOV(5))
    return account


def test_totals_add_up_every_entry_that_is_not_voided(supplier, book):
    result = totals(supplier.id)[book.id]
    assert (result.opening, result.offline_orders, result.online_orders, result.payments) == (D(1000), D(275), 0, D(300))
    assert result.net == D(975)


def test_totals_count_from_the_start_day_up_to_but_not_including_the_end_day(supplier, book):
    result = totals(supplier.id, start=NOV(3), end=NOV(5))[book.id]
    assert (result.opening, result.offline_orders, result.payments) == (0, D(200), D(300))


def test_totals_can_be_limited_to_one_account(supplier, book):
    other = offline_account(supplier, "Other Kirana")
    ledger_entry(other, EntryType.OFFLINE_ORDER, 999, NOV(2))
    assert set(totals(supplier.id)) == {book.id, other.id}
    assert set(totals(supplier.id, account_id=other.id)) == {other.id}


def test_totals_are_private_to_the_supplier(supplier, other_supplier, book):
    assert totals(other_supplier.id) == {}
    assert totals(supplier.id)[999].net == 0  # an account with nothing recorded reads as zero


def test_sent_invoices_count_as_online_orders_on_the_day_they_were_sent(supplier, fixed_rates):
    make_retailer(supplier)
    ensure_online_accounts(supplier.id)
    account = db.session.scalar(select(LedgerAccount).filter_by(supplier_id=supplier.id, retailer_id=1))
    product = make_product(supplier, stock=100)
    sent_invoice(supplier, product, sent_at=datetime(2026, 11, 4, 19, 0))  # 00:30 on 5 Nov in India
    draft_order = make_order(supplier, [(product, 1, "50")], number="ORD-0002")
    save_draft(draft_order, [])  # drafts are only planned quantities
    db.session.commit()

    assert totals(supplier.id)[account.id].online_orders == D("118.00")
    assert totals(supplier.id, start=NOV(5), end=NOV(6))[account.id].online_orders == D("118.00")
    assert totals(supplier.id, end=NOV(5))[account.id].online_orders == 0


# -- last payment and opening balance --------------------------------------------------------------


def test_last_payment_is_the_total_received_on_the_latest_day(supplier, fixed_rates):
    account = offline_account(supplier)
    ledger_entry(account, EntryType.PAYMENT, 100, NOV(2), payment_mode="Cash")
    ledger_entry(account, EntryType.PAYMENT, 40, NOV(4), payment_mode="Upi")
    ledger_entry(account, EntryType.PAYMENT, 60, NOV(4), payment_mode="Cash")
    ledger_entry(account, EntryType.PAYMENT, 500, NOV(6), payment_mode="Cash", voided=True)
    ledger_entry(account, EntryType.OFFLINE_ORDER, 700, NOV(7))

    assert last_payments(supplier.id) == {account.id: (NOV(4), D(100))}
    assert last_payments(supplier.id, account_id=account.id + 1) == {}


def test_an_account_without_payments_has_no_last_payment(supplier):
    account = offline_account(supplier)
    ledger_entry(account, EntryType.OFFLINE_ORDER, 700, NOV(7))
    assert last_payments(supplier.id) == {}


def test_opening_balances_from_linked_accounts_add_up_from_the_earliest_date(supplier):
    account = offline_account(supplier)
    ledger_entry(account, EntryType.OPENING_BALANCE, 500, NOV(1))
    ledger_entry(account, EntryType.OPENING_BALANCE, 250, date(2026, 10, 20))
    ledger_entry(account, EntryType.OPENING_BALANCE, 9999, NOV(2), voided=True)
    assert opening_balances(supplier.id) == {account.id: (date(2026, 10, 20), D(750))}


# -- ensure_online_accounts ------------------------------------------------------------------------


def test_connected_and_invoiced_retailers_get_one_account_each(supplier, fixed_rates):
    make_retailer(supplier, 1)  # connected
    product = make_product(supplier, stock=100)
    sent_invoice(supplier, product, retailer_id=2)  # invoiced, no longer connected
    save_draft(make_order(supplier, [(product, 1, "50")], retailer_id=3, number="ORD-0003"), [])  # only a draft
    offline = offline_account(supplier)
    db.session.commit()

    ensure_online_accounts(supplier.id)
    ensure_online_accounts(supplier.id)  # idempotent

    accounts = db.session.scalars(select(LedgerAccount).filter_by(supplier_id=supplier.id)).all()
    assert sorted(a.retailer_id for a in accounts if a.retailer_id) == [1, 2]
    assert [a.id for a in accounts if a.retailer_id is None] == [offline.id]


def test_other_suppliers_retailers_get_no_account(supplier, other_supplier):
    make_retailer(other_supplier)
    ensure_online_accounts(supplier.id)
    assert db.session.scalars(select(LedgerAccount)).all() == []


# -- entry requests --------------------------------------------------------------------------------


def entry_request(**changes) -> dict:
    return {"type": "OfflineOrder", "date": "2026-11-04", "amount": 200} | changes


def test_a_valid_entry():
    body = EntryRequest.model_validate(entry_request(reference=" BILL-7 ", notes=""))
    assert (body.entry_type, body.entry_date, body.amount) == ("OfflineOrder", NOV(4), D(200))
    assert body.reference == "BILL-7" and body.notes is None


def test_a_payment_needs_a_mode():
    assert validation_message(EntryRequest, entry_request(type="Payment")) == "Choose how the payment was made."
    assert EntryRequest.model_validate(entry_request(type="Payment", paymentMode="Upi")).payment_mode == "Upi"


@pytest.mark.parametrize(
    "changes, message",
    [
        ({"amount": 0}, "amount must be greater than 0."),
        ({"amount": -5}, "amount must be greater than 0."),
        ({"date": "yesterday"}, "Enter a valid date."),
    ],
)
def test_invalid_entries_are_explained(changes, message):
    assert validation_message(EntryRequest, entry_request(**changes)) == message


@pytest.mark.parametrize(
    "changes, field",
    [
        ({"date": None}, "date"),
        ({"amount": str(MAX_AMOUNT + D("0.01"))}, "amount"),
        ({"type": "Refund"}, "type"),
        ({"type": "Payment", "paymentMode": "Barter"}, "paymentMode"),
    ],
)
def test_invalid_entries_name_the_field(changes, field):
    assert validation_message(EntryRequest, entry_request(**changes)).startswith(f"{field}: ")


def test_the_entry_date_is_the_day_the_client_picked():
    assert EntryRequest.model_validate(entry_request(date="2026-11-04T23:30:00+05:30")).entry_date == NOV(4)


# -- statement lines -------------------------------------------------------------------------------


def test_orders_are_debits_and_payments_are_credits():
    order = LedgerEntry(id=1, entry_type=EntryType.OFFLINE_ORDER, amount=D(200), entry_date=NOV(3), reference="B-1")
    payment = LedgerEntry(id=2, entry_type=EntryType.PAYMENT, amount=D(300), entry_date=NOV(4), payment_mode="Upi",
                          collected_by="Ravi")

    order_line, payment_line = entry_json(order, D(1200)), entry_json(payment, D(900))
    assert (order_line["debit"], order_line["credit"], order_line["balance"]) == (D(200), 0, D(1200))
    assert (payment_line["debit"], payment_line["credit"], payment_line["balance"]) == (0, D(300), D(900))
    assert order_line["date"] == "2026-11-03T00:00:00"
    assert order_line["canVoid"] and not order_line["isVoided"]


@pytest.mark.parametrize(
    "kind, mode, collector, description",
    [
        (EntryType.OPENING_BALANCE, None, None, "Opening balance"),
        (EntryType.OFFLINE_ORDER, None, None, "Offline order"),
        (EntryType.PAYMENT, "Cash", None, "Payment (Cash)"),
        (EntryType.PAYMENT, "Upi", "Ravi", "Payment (UPI), collected by Ravi"),
        (EntryType.PAYMENT, "BankTransfer", "", "Payment (Bank transfer)"),
        (EntryType.PAYMENT, "Barter", None, "Payment (Barter)"),  # an unknown stored mode is shown as stored
    ],
)
def test_entry_descriptions(kind, mode, collector, description):
    row = LedgerEntry(entry_type=kind, amount=D(1), entry_date=NOV(1), payment_mode=mode, collected_by=collector)
    assert entry_json(row)["description"] == description


def test_a_voided_entry_is_listed_but_does_not_move_the_balance():
    row = LedgerEntry(entry_type=EntryType.PAYMENT, amount=D(50), entry_date=NOV(4), payment_mode="Cash",
                      voided_at=datetime(2026, 11, 6), void_reason="Entered twice")
    line = entry_json(row, D(900))
    assert (line["balance"], line["isVoided"], line["canVoid"], line["voidReason"]) == (None, True, False, "Entered twice")


def test_an_invoice_is_a_read_only_statement_line_on_its_business_day(fixed_rates):
    invoice = Invoice(id=8, invoice_number="INV-0001-202611-0001", invoice_date=datetime(2026, 11, 4, 19, 0),
                      grand_total=D("118.00"))
    line = invoice_entry_json(invoice, "ORD-0001", D(1118))
    assert line["date"] == "2026-11-05T00:00:00"
    assert (line["kind"], line["description"], line["reference"]) == ("OnlineOrder", "Online order ORD-0001", "INV-0001-202611-0001")
    assert (line["debit"], line["credit"], line["balance"]) == (D("118.00"), 0, D(1118))
    assert (line["invoiceId"], line["canVoid"]) == (8, False)


def test_account_names():
    retailer = Retailer(business_name="Green Valley Mart")
    assert account_name(LedgerAccount(name="Old name", retailer_id=1), retailer) == "Green Valley Mart"
    assert account_name(LedgerAccount(name="Shree Kirana"), None) == "Shree Kirana"
    assert account_name(LedgerAccount(retailer_id=9), None) == "Retailer #9"


def test_day_book_closing_balance():
    day = Totals(online_orders=D(118), offline_orders=D(200), payments=D(300))
    assert day_book_amounts(D(1000), day) == {
        "openingBalance": D(1000), "onlineOrders": D(118), "offlineOrders": D(200), "payments": D(300),
        "closingBalance": D(1018),
    }
