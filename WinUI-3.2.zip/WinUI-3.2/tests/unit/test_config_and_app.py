"""config.py, create_app()'s config checks, the Alembic hooks in extensions/database.py, JSON and to_dict()."""

from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from types import SimpleNamespace

import pytest

from supplier_service import create_app
from supplier_service import models  # noqa: F401  (configures every mapper before models are built)
from supplier_service.auth.models import Supplier
from supplier_service.common.json_provider import ApiJSONProvider
from supplier_service.config import DEFAULT_DATABASE_URL, SERVICE_ROOT, load_config, normalize_database_url, utc_offset
from supplier_service.extensions.database import (
    SERVICE_SCHEMA,
    include_service_schema_only,
    migrate_options,
    skip_external_tables,
)
from supplier_service.invoices.models import Invoice

from .factories import JWT_SECRET

# -- utc_offset ------------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "value, expected",
    [
        ("+05:30", timedelta(hours=5, minutes=30)),
        ("-04:00", timedelta(hours=-4)),
        ("-03:30", -timedelta(hours=3, minutes=30)),
        ("+00:00", timedelta(0)),
        ("  +05:45 ", timedelta(hours=5, minutes=45)),
    ],
)
def test_utc_offset_parses_signed_hours_and_minutes(value, expected):
    assert utc_offset(value).utcoffset(None) == expected


@pytest.mark.parametrize("value", ["+5:30", "05:30", "IST", "+05:30:00", "", "+0530"])
def test_utc_offset_rejects_anything_but_plus_or_minus_hh_mm(value):
    with pytest.raises(ValueError, match="BUSINESS_UTC_OFFSET must look like"):
        utc_offset(value)


# -- normalize_database_url ------------------------------------------------------------------------


@pytest.mark.parametrize(
    "url, expected",
    [
        ("postgres://u:p@db:5432/x", "postgresql+psycopg://u:p@db:5432/x"),
        ("postgresql://u:p@db/x", "postgresql+psycopg://u:p@db/x"),
        ("postgresql+psycopg2://u:p@db/x", "postgresql+psycopg://u:p@db/x"),
        ("postgresql+psycopg://u:p@db/x", "postgresql+psycopg://u:p@db/x"),
        ("sqlite://", "sqlite://"),
        ("sqlite:///postgres://not-a-prefix.db", "sqlite:///postgres://not-a-prefix.db"),
    ],
)
def test_database_urls_always_use_the_psycopg3_driver(url, expected):
    assert normalize_database_url(url) == expected


# -- load_config -----------------------------------------------------------------------------------

_CONFIG_VARS = [
    "DATABASE_URL", "JWT_SECRET_KEY", "JWT_ACCESS_EXPIRES_MINUTES", "JWT_EXPIRES_HOURS", "REFRESH_TOKEN_IDLE_DAYS",
    "REFRESH_TOKEN_MAX_DAYS", "GST_RATE", "BUSINESS_UTC_OFFSET", "UPLOAD_FOLDER", "IMAGE_STORAGE", "PUBLIC_BASE_URL",
]


@pytest.fixture
def clean_env(monkeypatch):
    for name in _CONFIG_VARS:
        monkeypatch.delenv(name, raising=False)
    return monkeypatch


def test_config_defaults_when_nothing_is_set(clean_env):
    config = load_config()
    assert config["SQLALCHEMY_DATABASE_URI"] == DEFAULT_DATABASE_URL
    assert config["JWT_SECRET_KEY"] == ""
    assert config["JWT_EXPIRES"] == timedelta(minutes=15)
    assert config["REFRESH_IDLE"] == timedelta(days=7)
    assert config["REFRESH_MAX"] == timedelta(days=30)
    assert config["REFRESH_REUSE_GRACE"] == timedelta(seconds=30)
    assert config["GST_RATE"] == Decimal("0.18") and isinstance(config["GST_RATE"], Decimal)
    assert config["BUSINESS_TIMEZONE"].utcoffset(None) == timedelta(hours=5, minutes=30)
    assert config["UPLOAD_FOLDER"] == str(SERVICE_ROOT / "uploads")
    assert config["IMAGE_STORAGE"] == "local"
    assert config["PUBLIC_BASE_URL"] is None


def test_config_reads_the_environment(clean_env):
    clean_env.setenv("DATABASE_URL", "postgresql://a:b@host/db")
    clean_env.setenv("JWT_EXPIRES_HOURS", "2")
    clean_env.setenv("REFRESH_TOKEN_IDLE_DAYS", "3")
    clean_env.setenv("REFRESH_TOKEN_MAX_DAYS", "60")
    clean_env.setenv("GST_RATE", "0.05")
    clean_env.setenv("BUSINESS_UTC_OFFSET", "-03:00")
    clean_env.setenv("UPLOAD_FOLDER", "D:/media")
    clean_env.setenv("PUBLIC_BASE_URL", "https://api.example.com")

    config = load_config()
    assert config["SQLALCHEMY_DATABASE_URI"] == "postgresql://a:b@host/db"  # normalised later, by create_app
    assert config["JWT_EXPIRES"] == timedelta(hours=2)  # JWT_EXPIRES_HOURS still counts when it's all that's set
    assert config["REFRESH_IDLE"] == timedelta(days=3)
    assert config["REFRESH_MAX"] == timedelta(days=60)
    assert config["GST_RATE"] == Decimal("0.05")
    assert config["BUSINESS_TIMEZONE"].utcoffset(None) == timedelta(hours=-3)
    assert config["UPLOAD_FOLDER"] == "D:/media"
    assert config["PUBLIC_BASE_URL"] == "https://api.example.com"


def test_the_access_token_lifetime_in_minutes_wins_over_the_old_hours_setting(clean_env):
    clean_env.setenv("JWT_ACCESS_EXPIRES_MINUTES", "5")
    clean_env.setenv("JWT_EXPIRES_HOURS", "12")
    assert load_config()["JWT_EXPIRES"] == timedelta(minutes=5)


def test_blank_optional_settings_fall_back_to_their_defaults(clean_env):
    clean_env.setenv("UPLOAD_FOLDER", "")
    clean_env.setenv("PUBLIC_BASE_URL", "")
    config = load_config()
    assert config["UPLOAD_FOLDER"] == str(SERVICE_ROOT / "uploads")
    assert config["PUBLIC_BASE_URL"] is None


def test_a_bad_business_offset_fails_at_startup(clean_env):
    clean_env.setenv("BUSINESS_UTC_OFFSET", "IST")
    with pytest.raises(ValueError, match="BUSINESS_UTC_OFFSET"):
        load_config()


def test_upload_limits_leave_room_for_multipart_overhead():
    config = load_config()
    assert config["MAX_CONTENT_LENGTH"] > config["MAX_IMAGE_BYTES"]


# -- create_app config checks ----------------------------------------------------------------------


@pytest.mark.parametrize("secret", [None, "", "x" * 31])
def test_the_app_refuses_to_start_without_a_long_enough_jwt_secret(secret):
    with pytest.raises(RuntimeError, match="JWT_SECRET_KEY"):
        create_app({"SQLALCHEMY_DATABASE_URI": "sqlite://", "JWT_SECRET_KEY": secret})


def test_a_32_character_secret_is_enough():
    app = create_app({"SQLALCHEMY_DATABASE_URI": "sqlite://", "JWT_SECRET_KEY": "x" * 32})
    assert app.config["JWT_SECRET_KEY"] == "x" * 32


def test_postgres_connections_are_pinned_to_utc():
    app = create_app({"SQLALCHEMY_DATABASE_URI": "postgres://u:p@localhost/db", "JWT_SECRET_KEY": JWT_SECRET})
    assert app.config["SQLALCHEMY_DATABASE_URI"] == "postgresql+psycopg://u:p@localhost/db"
    options = app.config["SQLALCHEMY_ENGINE_OPTIONS"]
    assert options["connect_args"]["options"] == "-c timezone=UTC"
    assert options["pool_pre_ping"] is True  # the other engine options are kept


def test_explicit_postgres_connect_options_are_not_overwritten():
    app = create_app({
        "SQLALCHEMY_DATABASE_URI": "postgresql://u:p@localhost/db",
        "SQLALCHEMY_ENGINE_OPTIONS": {"connect_args": {"options": "-c search_path=supplier"}},
        "JWT_SECRET_KEY": JWT_SECRET,
    })
    assert app.config["SQLALCHEMY_ENGINE_OPTIONS"]["connect_args"]["options"] == "-c search_path=supplier"


def test_sqlite_gets_no_postgres_connect_options():
    app = create_app({"SQLALCHEMY_DATABASE_URI": "sqlite://", "JWT_SECRET_KEY": JWT_SECRET})
    assert "connect_args" not in app.config["SQLALCHEMY_ENGINE_OPTIONS"]


# -- Alembic hooks ---------------------------------------------------------------------------------


def test_tables_in_the_retailer_schema_are_never_migrated():
    assert skip_external_tables(SimpleNamespace(schema="retailer"), "retailers", "table", False, None) is False
    assert skip_external_tables(SimpleNamespace(schema=SERVICE_SCHEMA), "orders", "table", False, None) is True
    assert skip_external_tables(SimpleNamespace(schema=None), "orders", "table", False, None) is True
    # Only tables are filtered; their indexes and columns follow the table.
    assert skip_external_tables(SimpleNamespace(schema="retailer"), "ix_x", "index", False, None) is True


def test_only_the_service_schema_is_reflected():
    assert include_service_schema_only(SERVICE_SCHEMA, "schema", {}) is True
    assert include_service_schema_only("public", "schema", {}) is False
    assert include_service_schema_only("retailer", "schema", {}) is False
    assert include_service_schema_only("orders", "table", {"schema_name": SERVICE_SCHEMA}) is True


def test_migrate_options_use_schemas_on_postgres_only():
    assert migrate_options("sqlite://") == {"include_object": skip_external_tables}

    options = migrate_options("postgresql+psycopg://u:p@h/db")
    assert options["include_object"] is skip_external_tables
    assert options["include_schemas"] is True
    assert options["include_name"] is include_service_schema_only
    assert options["version_table_schema"] == SERVICE_SCHEMA


# -- JSON ------------------------------------------------------------------------------------------


def test_json_writes_money_as_numbers_and_dates_as_iso_strings():
    assert ApiJSONProvider.default(Decimal("12.50")) == 12.5
    assert ApiJSONProvider.default(Decimal("99999999.99")) == 99999999.99
    assert ApiJSONProvider.default(date(2026, 11, 5)) == "2026-11-05"
    assert ApiJSONProvider.default(datetime(2026, 11, 5, 8, 30, tzinfo=timezone.utc)) == "2026-11-05T08:30:00+00:00"


def test_json_rejects_values_it_cannot_represent():
    with pytest.raises(TypeError):
        ApiJSONProvider.default(object())


def test_json_keeps_key_order(shared_app):
    assert shared_app.json.dumps({"zeta": 1, "alpha": Decimal("1.10")}) == '{"zeta": 1, "alpha": 1.1}'


# -- BaseModel.to_dict -----------------------------------------------------------------------------


def test_to_dict_converts_decimals_and_dates():
    invoice = Invoice(subtotal=Decimal("10.50"), invoice_date=datetime(2026, 11, 5, 10, 0), status="Draft")
    payload = invoice.to_dict()
    assert payload["subtotal"] == 10.5 and isinstance(payload["subtotal"], float)
    assert payload["invoice_date"] == "2026-11-05T10:00:00"
    assert payload["status"] == "Draft"
    assert payload["id"] is None


def test_a_suppliers_dict_never_contains_the_password_hash():
    supplier = Supplier(email="a@example.com", password_hash="scrypt:secret")
    payload = supplier.to_dict()
    assert "password_hash" not in payload
    assert payload["email"] == "a@example.com"
