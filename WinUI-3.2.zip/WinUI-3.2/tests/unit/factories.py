"""Rows built directly through the ORM (no HTTP, no password hashing). Each factory commits, so the code under
test sees the rows the way it would in a request. Call them inside the `app` fixture's app context.

Also validation_message(), the API's error message for a request body."""

import itertools
from datetime import datetime
from decimal import Decimal

import pytest
from pydantic import ValidationError

from supplier_service.auth.models import Supplier
from supplier_service.catalogue.models import Product
from supplier_service.common.http import _describe
from supplier_service.extensions.database import db
from supplier_service.inventory.models import Inventory, ReferenceType, TransactionType
from supplier_service.inventory.service import new_inventory, record_movement
from supplier_service.orders.service import create_order
from supplier_service.pricing.models import STANDARD_GROUP, PriceGroup, ProductPrice
from supplier_service.retailers.models import Retailer, RetailerPriceGroup, RetailerSettings, SupplierConnection

JWT_SECRET = "unit-test-secret-key-0123456789-abcdefghij"


def validation_message(schema, payload: dict) -> str:
    """The message the API would answer this body with (parse_body's 400), asserting that it fails."""
    with pytest.raises(ValidationError) as caught:
        schema.model_validate(payload)
    return _describe(caught.value)


_supplier_numbers = itertools.count(1)


def make_supplier(company: str = "Acme Traders", *, active: bool = True) -> Supplier:
    n = next(_supplier_numbers)
    supplier = Supplier(
        supplier_code=f"GDP-TEST-{n:04d}", company_name=company, contact_person="Asha Verma",
        email=f"supplier{n}@example.com", phone="+91 98765 43210", address="42 Industrial Estate",
        city="Pune", state="Maharashtra", country="India", postal_code="411001",
        password_hash="not-used", is_active=active,
    )
    db.session.add(supplier)
    db.session.flush()
    # Registration gives every supplier a Standard group; so does this factory.
    db.session.add(PriceGroup(supplier_id=supplier.id, group_name=STANDARD_GROUP, is_default=True))
    db.session.commit()
    return supplier


def standard_group(supplier: Supplier) -> PriceGroup:
    return db.session.scalar(db.select(PriceGroup).filter_by(supplier_id=supplier.id, is_default=True))


def make_group(supplier: Supplier, name: str = "Wholesale") -> PriceGroup:
    group = PriceGroup(supplier_id=supplier.id, group_name=name)
    db.session.add(group)
    db.session.commit()
    return group


def make_product(
    supplier: Supplier, code: str = "COLA", *, name: str | None = None, stock: int | None = 100, active: bool = True
) -> Product:
    """stock=None: no inventory row at all."""
    product = Product(
        supplier_id=supplier.id, product_code=code, product_name=name or code.title(), unit_of_measure="pcs",
        is_active=active,
    )
    db.session.add(product)
    db.session.flush()
    if stock is not None:
        inventory = new_inventory(product.id)
        db.session.add(inventory)
        if stock:
            record_movement(inventory, TransactionType.STOCK_ADDED, stock, reference_type=ReferenceType.OPENING_STOCK)
    db.session.commit()
    return product


def inventory_of(product: Product) -> Inventory:
    return db.session.scalar(db.select(Inventory).filter_by(product_id=product.id))


def set_price(
    group: PriceGroup, product: Product, price, *, effective_from: datetime | None = None,
    effective_to: datetime | None = None,
) -> ProductPrice:
    row = ProductPrice(
        price_group_id=group.id, product_id=product.id, unit_price=Decimal(str(price)),
        effective_from=effective_from or datetime(2020, 1, 1), effective_to=effective_to,
    )
    db.session.add(row)
    db.session.commit()
    return row


def make_retailer(
    supplier: Supplier | None, retailer_id: int = 1, *, name: str = "Green Valley Mart",
    group: PriceGroup | None = None, gst: bool | None = None,
) -> Retailer:
    """A retailer account (the retailer service's table), connected to `supplier` unless that is None.

    group=None leaves it in the supplier's Standard group; gst=None leaves its settings at the defaults.
    """
    retailer = db.session.get(Retailer, retailer_id)
    if retailer is None:
        retailer = Retailer(
            id=retailer_id, retailer_code=f"RTL-{retailer_id:06d}", business_name=name, contact_person="Ravi Kumar",
            email=f"orders{retailer_id}@retailer.example", password_hash="x", phone="+91 90000 10000",
            address="10, MG Road", city="Pune", state="Maharashtra", country="India", postal_code="411005",
        )
        db.session.add(retailer)
        db.session.flush()
    if supplier is not None:
        db.session.add(SupplierConnection(retailer_id=retailer_id, supplier_id=supplier.id))
        if group is not None:
            db.session.add(RetailerPriceGroup(supplier_id=supplier.id, retailer_id=retailer_id, price_group_id=group.id))
        if gst is not None:
            db.session.add(RetailerSettings(supplier_id=supplier.id, retailer_id=retailer_id, gst_applicable=gst))
    db.session.commit()
    return retailer


def make_order(supplier: Supplier, lines, *, retailer_id: int = 1, number: str = "ORD-0001", **kw):
    """lines: [(product, quantity, unit price)]."""
    order = create_order(
        supplier, retailer_id=retailer_id, order_number=number,
        lines=[(product, quantity, Decimal(str(price))) for product, quantity, price in lines], **kw,
    )
    db.session.commit()
    return order
