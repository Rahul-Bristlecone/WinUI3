"""orders/models.py (status rules), orders/service.py (create, reject, look up) and orders/schemas.py (wire format)."""

from datetime import datetime
from decimal import Decimal

import pytest
from sqlalchemy import select

from supplier_service.common.errors import NOT_FOUND, ApiError
from supplier_service.extensions.database import db
from supplier_service.invoices.models import Invoice
from supplier_service.invoices.schemas import InvoiceLineInput
from supplier_service.invoices.service import save_draft, send_invoice
from supplier_service.orders.models import Order, OrderStatus
from supplier_service.orders.schemas import API_STATUS, STATUS_FILTER, order_json
from supplier_service.orders.service import create_order, ensure_transition, owned_order, reject_order

from .factories import inventory_of, make_order, make_product, make_retailer


@pytest.fixture
def stock(supplier):
    make_retailer(supplier)
    return {"cola": make_product(supplier, "COLA", stock=50), "chips": make_product(supplier, "CHIPS", stock=30)}


@pytest.fixture
def order(supplier, stock, fixed_rates) -> Order:
    """Pending: 10 x Cola @ 12.50 and 5 x Chips @ 4.00."""
    return make_order(supplier, [(stock["cola"], 10, "12.50"), (stock["chips"], 5, "4.00")])


def line(order, product, quantity) -> InvoiceLineInput:
    item = next(i for i in order.items if i.product_id == product.id)
    return InvoiceLineInput(order_line_id=item.id, invoiced_quantity=quantity)


# -- status rules ----------------------------------------------------------------------------------


def test_every_status_has_transition_rules():
    assert set(OrderStatus.ALLOWED_TRANSITIONS) == OrderStatus.VALUES
    for targets in OrderStatus.ALLOWED_TRANSITIONS.values():
        assert targets <= OrderStatus.VALUES


@pytest.mark.parametrize("final", [OrderStatus.CANCELLED, OrderStatus.SUPPLIER_REJECT, OrderStatus.FULFILLED])
def test_closed_orders_cannot_change(final):
    assert OrderStatus.ALLOWED_TRANSITIONS[final] == set()


def test_nothing_goes_back_to_pending():
    assert all(OrderStatus.PENDING not in targets for targets in OrderStatus.ALLOWED_TRANSITIONS.values())


@pytest.mark.parametrize(
    "current, target, allowed",
    [
        (OrderStatus.PENDING, OrderStatus.INVOICE_SENT, True),
        (OrderStatus.PENDING, OrderStatus.SUPPLIER_REJECT, True),
        (OrderStatus.INVOICE_SENT, OrderStatus.FULFILLED, True),
        (OrderStatus.IN_TRANSIT, OrderStatus.FULFILLED, True),
        (OrderStatus.INVOICE_SENT, OrderStatus.SUPPLIER_REJECT, False),
        (OrderStatus.SUPPLIER_REJECT, OrderStatus.INVOICE_SENT, False),
        (OrderStatus.FULFILLED, OrderStatus.IN_TRANSIT, False),
        ("Not A Status", OrderStatus.INVOICE_SENT, False),
    ],
)
def test_ensure_transition(current, target, allowed):
    order = Order(status=current)
    if allowed:
        ensure_transition(order, target, "nope")
    else:
        with pytest.raises(ApiError) as caught:
            ensure_transition(order, target, "Not now.")
        assert (caught.value.status, caught.value.message) == (400, "Not now.")


# -- create_order ----------------------------------------------------------------------------------


def test_an_order_needs_a_line(supplier):
    with pytest.raises(ValueError, match="at least one line"):
        create_order(supplier, retailer_id=1, order_number="ORD-1", lines=[])


def test_a_new_order_is_pending_with_header_totals_over_every_line(supplier, stock):
    order = make_order(
        supplier, [(stock["cola"], 3, "12.333"), (stock["chips"], 2, "4.00")],
        retailer_id=1, number="ORD-7", store_id=4, notes="Back door",
    )
    assert order.id is not None
    assert (order.status, order.order_number, order.retailer_id, order.store_id, order.notes) == (
        OrderStatus.PENDING, "ORD-7", 1, 4, "Back door",
    )
    assert [item.total_amount for item in order.items] == [Decimal("37.00"), Decimal("8.00")]  # rounded to paise
    # Header product and price describe the first line; quantity and amount cover all of them.
    assert (order.product_id, order.price) == (stock["cola"].id, Decimal("12.33"))
    assert (order.ordered_qty, order.total_amount) == (5, Decimal("45.00"))


def test_an_order_date_can_be_given(supplier, stock):
    placed = datetime(2026, 10, 1, 9, 30)
    assert make_order(supplier, [(stock["cola"], 1, 1)], order_date=placed).order_date == placed


def test_a_new_order_reserves_its_stock(supplier, stock):
    make_order(supplier, [(stock["cola"], 10, 1), (stock["chips"], 5, 1)])
    assert (inventory_of(stock["cola"]).reserved_quantity, inventory_of(stock["cola"]).available_quantity) == (10, 40)
    assert inventory_of(stock["chips"]).reserved_quantity == 5
    assert inventory_of(stock["cola"]).on_hand_quantity == 50  # nothing leaves until it is invoiced


def test_an_order_is_recorded_even_when_it_exceeds_available_stock(supplier, stock):
    # Orders arrive from the retailer side and can't be refused here; stock is checked when invoicing.
    make_order(supplier, [(stock["cola"], 80, 1)])
    assert inventory_of(stock["cola"]).available_quantity == -30


def test_a_product_without_an_inventory_row_is_not_reserved(supplier):
    service_item = make_product(supplier, "INSTALL", stock=None)
    order = make_order(supplier, [(service_item, 2, 100)])
    assert order.status == OrderStatus.PENDING and inventory_of(service_item) is None


# -- reject_order ----------------------------------------------------------------------------------


def test_rejecting_releases_the_reservation_and_records_the_reason(order, stock):
    reject_order(order, "No delivery slot")
    db.session.commit()

    assert (order.status, order.rejection_reason, order.invoiced_qty) == (OrderStatus.SUPPLIER_REJECT, "No delivery slot", 0)
    assert inventory_of(stock["cola"]).reserved_quantity == 0
    assert inventory_of(stock["chips"]).available_quantity == 30


def test_rejecting_deletes_the_draft_invoice(order, stock):
    save_draft(order, [line(order, stock["cola"], 3)])
    db.session.commit()
    assert db.session.scalar(select(Invoice).filter_by(order_id=order.id)) is not None

    reject_order(order, None)
    db.session.commit()
    assert db.session.scalar(select(Invoice).filter_by(order_id=order.id)) is None


@pytest.mark.parametrize("close", ["reject", "invoice"])
def test_only_pending_orders_can_be_rejected(order, stock, close):
    if close == "reject":
        reject_order(order, None)
    else:
        send_invoice(order, [line(order, stock["cola"], 1)])
    db.session.commit()
    reserved = inventory_of(stock["cola"]).reserved_quantity

    with pytest.raises(ApiError) as caught:
        reject_order(order, "again")
    assert caught.value.message == "Only pending orders can be rejected."
    assert inventory_of(stock["cola"]).reserved_quantity == reserved


# -- owned_order -----------------------------------------------------------------------------------


def test_owned_order_finds_the_suppliers_order(supplier, order):
    assert owned_order(supplier.id, order.id).id == order.id
    assert owned_order(supplier.id, order.id, lock=True).id == order.id


def test_another_suppliers_order_is_not_found(other_supplier, order):
    with pytest.raises(ApiError) as caught:
        owned_order(other_supplier.id, order.id)
    assert (caught.value.status, caught.value.message) == (404, NOT_FOUND)


def test_owned_order_can_say_what_is_missing(supplier):
    with pytest.raises(ApiError) as caught:
        owned_order(supplier.id, 12345, missing="Order not found.")
    assert (caught.value.status, caught.value.message) == (404, "Order not found.")


# -- wire format -----------------------------------------------------------------------------------


def test_every_order_status_has_a_client_name():
    assert set(API_STATUS) == OrderStatus.VALUES
    assert API_STATUS[OrderStatus.SUPPLIER_REJECT] == "SupplierRejected"
    assert API_STATUS[OrderStatus.INVOICE_SENT] == "Invoiced"
    assert API_STATUS[OrderStatus.IN_TRANSIT] == "InTransit"


def test_status_filters_map_client_names_back_to_database_values():
    assert STATUS_FILTER["Invoiced"] == {OrderStatus.INVOICE_SENT}
    assert STATUS_FILTER["SupplierRejected"] == {OrderStatus.SUPPLIER_REJECT}
    assert set(STATUS_FILTER) == set(API_STATUS.values())


def test_order_json(order):
    payload = order_json(order, "Green Valley Mart")
    assert payload["status"] == "Pending" and payload["amount"] == Decimal("145.00")
    assert payload["orderDate"].endswith("Z")
    assert order_json(order, None)["retailerName"] == "Retailer #1"


def test_an_unknown_status_is_passed_through(order):
    order.status = "On Hold"
    assert order_json(order, "x")["status"] == "On Hold"
