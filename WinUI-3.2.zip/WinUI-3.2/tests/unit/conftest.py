"""Fixtures for unit tests. Row factories are in factories.py.

`app` here overrides tests/conftest.py's: every unit test shares one app (create_app() compiles ~60 URL rules,
about a quarter of a second, which would dominate a suite of small tests) but still gets freshly created
tables in a new app context. Like the API tests, it runs on in-memory SQLite unless TEST_DATABASE_URL is set.
"""

import os
from decimal import Decimal

import pytest

from conftest import _prepare_database  # tests/conftest.py (this file is unit.conftest, so no clash)
from supplier_service import create_app
from supplier_service.config import utc_offset
from supplier_service.extensions.database import db

from .factories import JWT_SECRET, make_supplier


@pytest.fixture(scope="session")
def shared_app(tmp_path_factory):
    """The app every unit test uses. Outside the `app` fixture it has no tables: use it directly for helpers
    that only need the config or a request context. Change its config with monkeypatch.setitem (undone after
    each test); don't add routes to it."""
    app = create_app({
        "TESTING": True,
        "SQLALCHEMY_DATABASE_URI": os.environ.get("TEST_DATABASE_URL", "sqlite://"),
        "JWT_SECRET_KEY": JWT_SECRET,
        "UPLOAD_FOLDER": str(tmp_path_factory.mktemp("uploads")),
    })
    with app.app_context():
        _prepare_database()  # once per engine: attaches the schemas (SQLite) or checks the database is empty
    return app


@pytest.fixture
def app(shared_app, tmp_path, monkeypatch):
    """The shared app with fresh tables and upload folder, inside an app context."""
    monkeypatch.setitem(shared_app.config, "UPLOAD_FOLDER", str(tmp_path / "uploads"))
    with shared_app.app_context():
        db.create_all()
        yield shared_app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def fixed_rates(app, monkeypatch):
    """Pins the settings that money and dates depend on, whatever the environment says."""
    monkeypatch.setitem(app.config, "GST_RATE", Decimal("0.18"))
    monkeypatch.setitem(app.config, "BUSINESS_TIMEZONE", utc_offset("+05:30"))


@pytest.fixture
def supplier(app):
    return make_supplier()


@pytest.fixture
def other_supplier(app):
    return make_supplier("Other Supplies")
