"""catalogue/schemas.py, catalogue/images.py (validation, thumbnails) and catalogue/storage.py (local files)."""

import logging
import re
from io import BytesIO
from pathlib import Path

import pytest
from PIL import Image
from werkzeug.datastructures import FileStorage

from supplier_service import models  # noqa: F401  (configures every mapper before models are built)
from supplier_service.catalogue import images
from supplier_service.catalogue.images import (
    delete_product_image,
    ensure_thumbnail,
    make_thumbnail,
    product_image_url,
    product_thumbnail_url,
    store_product_image,
    thumbnail_key,
)
from supplier_service.catalogue.models import Category, Product
from supplier_service.catalogue.schemas import CategoryRequest, ProductRequest, category_json, product_json
from supplier_service.catalogue.storage import LocalImageStorage, get_storage
from supplier_service.common.errors import ApiError

from .factories import validation_message

NOT_AN_IMAGE = "The file is not a valid PNG or JPEG image."
STEM = "7-" + "a" * 32  # <productId>-<uuid hex>, as store_product_image names files


def image_bytes(fmt: str = "PNG", size=(40, 30), mode: str = "RGB", color="red", **save) -> bytes:
    out = BytesIO()
    Image.new(mode, size, color).save(out, fmt, **save)
    return out.getvalue()


def truncated_png() -> bytes:
    """The first half of a noisy (so: large, incompressible) PNG."""
    out = BytesIO()
    Image.effect_noise((200, 200), 64).convert("RGB").save(out, "PNG")
    return out.getvalue()[: len(out.getvalue()) // 2]


def upload(data: bytes, filename: str | None) -> FileStorage:
    return FileStorage(stream=BytesIO(data), filename=filename)


def opened(data: bytes) -> Image.Image:
    image = Image.open(BytesIO(data))
    image.load()
    return image


@pytest.fixture
def storage(app) -> LocalImageStorage:
    return get_storage()


# -- request schemas -------------------------------------------------------------------------------


def product(**changes) -> dict:
    return {"productCode": "P-001", "name": "Cola 500ml", "categoryId": 1} | changes


def test_product_codes_are_trimmed_and_upper_cased():
    assert ProductRequest.model_validate(product(productCode="  cola_500-ml ")).product_code == "COLA_500-ML"


@pytest.mark.parametrize("code", ["A", "P 01", "P/01", "Ä1", "X" * 65])
def test_product_codes_allow_only_letters_digits_dash_and_underscore(code):
    assert validation_message(ProductRequest, product(productCode=code)) == (
        "Product code must be 2–64 letters, digits, '-' or '_'."
    )


def test_product_defaults():
    body = ProductRequest.model_validate(product(description="  ", barcode=""))
    assert (body.unit_of_measure, body.initial_stock, body.status) == ("pcs", 0, "Active")
    assert body.description is None and body.barcode is None


def test_opening_stock_must_be_a_whole_non_negative_number():
    assert ProductRequest.model_validate(product(initialStock=12.0)).initial_stock == 12
    assert validation_message(ProductRequest, product(initialStock=2.5)) == "Quantity must be a whole number."
    assert validation_message(ProductRequest, product(initialStock=-1)).startswith("initialStock: ")


def test_status_must_be_active_or_inactive():
    assert ProductRequest.model_validate(product(status="Inactive")).status == "Inactive"
    assert validation_message(ProductRequest, product(status="Deleted")).startswith("status: ")
    assert validation_message(CategoryRequest, {"name": "Snacks", "status": "deleted"}).startswith("status: ")


def test_category_json_names_the_parent():
    parent = Category(id=1, category_name="Beverages", is_active=True)
    child = Category(id=2, category_name="Juices", parent_category=parent, parent_category_id=1, is_active=False)
    assert category_json(child) == {
        "id": 2, "name": "Juices", "parentCategoryId": 1, "parentCategoryName": "Beverages", "status": "Inactive",
    }
    assert category_json(parent)["parentCategoryName"] is None


def test_product_json_fills_what_the_client_cannot_take_as_null():
    item = Product(id=3, product_code="COLA", product_name="Cola", description=None, category_id=None,
                   unit_of_measure="pcs", barcode=None, is_active=True, image_filename=None)
    payload = product_json(item, current_stock=12, category_name=None)
    assert (payload["description"], payload["categoryId"], payload["categoryName"]) == ("", 0, "")
    assert payload["currentStock"] == 12 and payload["status"] == "Active"
    assert payload["imageUrl"] is None and payload["thumbnailUrl"] is None


# -- image names and URLs --------------------------------------------------------------------------


def test_thumbnail_names_are_derived_from_the_original():
    assert thumbnail_key(f"{STEM}.png") == f"{STEM}-thumb.jpg"
    assert thumbnail_key(f"{STEM}.jpg") == f"{STEM}-thumb.jpg"


def test_image_urls_use_the_public_base_url_behind_a_proxy(app, monkeypatch):
    monkeypatch.setitem(app.config, "PUBLIC_BASE_URL", "https://cdn.example.com/")
    assert product_image_url(f"{STEM}.png") == f"https://cdn.example.com/media/products/{STEM}.png"
    assert product_thumbnail_url(f"{STEM}.png") == f"https://cdn.example.com/media/products/{STEM}-thumb.jpg"
    assert product_image_url(None) is None and product_thumbnail_url(None) is None


def test_image_urls_use_the_request_host_otherwise(app, monkeypatch):
    monkeypatch.setitem(app.config, "PUBLIC_BASE_URL", None)
    with app.test_request_context(base_url="http://api.test:5000"):
        assert product_image_url(f"{STEM}.png") == f"http://api.test:5000/media/products/{STEM}.png"


# -- thumbnails ------------------------------------------------------------------------------------


def test_thumbnails_are_jpegs_no_larger_than_the_configured_size(app):
    thumb = opened(make_thumbnail(image_bytes("PNG", size=(1000, 500))))
    assert thumb.format == "JPEG"
    assert thumb.size == (256, 128)


def test_thumbnail_size_is_configurable(app, monkeypatch):
    monkeypatch.setitem(app.config, "THUMBNAIL_SIZE", 64)
    assert opened(make_thumbnail(image_bytes("JPEG", size=(300, 600)))).size == (32, 64)


def test_small_images_are_not_enlarged(app):
    assert opened(make_thumbnail(image_bytes("PNG", size=(50, 40)))).size == (50, 40)


@pytest.mark.parametrize("mode, color", [("RGBA", (0, 0, 0, 0)), ("LA", (0, 0)), ("P", 0)])
def test_transparency_is_flattened_onto_white(app, mode, color):
    save = {"transparency": 0} if mode == "P" else {}
    thumb = opened(make_thumbnail(image_bytes("PNG", size=(20, 20), mode=mode, color=color, **save)))
    assert thumb.mode == "RGB"
    assert all(channel > 245 for channel in thumb.getpixel((10, 10)))


def test_camera_rotation_is_applied(app):
    exif = Image.Exif()
    exif[0x0112] = 6  # Orientation: rotate 90° clockwise to display
    photo = image_bytes("JPEG", size=(40, 20), exif=exif.tobytes())
    assert opened(make_thumbnail(photo)).size == (20, 40)


def test_photo_metadata_is_dropped(app):
    exif = Image.Exif()
    exif[0x010F] = "Leaky Camera Co"  # Make
    exif[0x0110] = "Model X"
    photo = image_bytes("JPEG", exif=exif.tobytes())
    assert opened(photo).getexif()  # the original has it...
    assert not opened(make_thumbnail(photo)).getexif()  # ...the thumbnail doesn't


# -- store_product_image ---------------------------------------------------------------------------


@pytest.mark.parametrize("filename, extension", [("photo.png", ".png"), ("PHOTO.PNG", ".png")])
def test_a_png_is_stored_with_its_thumbnail(storage, filename, extension):
    data = image_bytes("PNG")
    name = store_product_image(7, upload(data, filename))

    assert re.fullmatch(r"7-[0-9a-f]{32}" + re.escape(extension), name)
    assert storage.read(name) == data  # the original is kept byte for byte
    assert opened(storage.read(thumbnail_key(name))).format == "JPEG"


@pytest.mark.parametrize("filename", ["photo.jpg", "photo.jpeg", "photo.JPEG"])
def test_jpegs_are_stored_as_jpg(storage, filename):
    name = store_product_image(7, upload(image_bytes("JPEG"), filename))
    assert name.endswith(".jpg") and storage.exists(name) and storage.exists(thumbnail_key(name))


def test_every_upload_gets_a_new_name(storage):
    first = store_product_image(7, upload(image_bytes(), "a.png"))
    second = store_product_image(7, upload(image_bytes(), "a.png"))
    assert first != second


@pytest.mark.parametrize("filename", ["photo.gif", "photo.webp", "photo", "", None, "png"])
def test_only_png_and_jpeg_file_names_are_accepted(storage, filename):
    with pytest.raises(ApiError) as caught:
        store_product_image(7, upload(image_bytes(), filename))
    assert caught.value.message == "Only PNG or JPEG images are supported."


def test_uploads_over_the_size_limit_are_refused_before_decoding(app, storage, monkeypatch):
    monkeypatch.setitem(app.config, "MAX_IMAGE_BYTES", 1024 * 1024)
    too_big = b"\x89PNG\r\n\x1a\n" + b"\0" * (1024 * 1024)
    with pytest.raises(ApiError) as caught:
        store_product_image(7, upload(too_big, "big.png"))
    assert (caught.value.status, caught.value.message) == (400, "Image must be 1 MB or smaller.")


@pytest.mark.parametrize(
    "data, filename",
    [
        pytest.param(image_bytes("JPEG"), "photo.png", id="jpeg named png"),
        pytest.param(image_bytes("PNG"), "photo.jpg", id="png named jpg"),
        pytest.param(b"GIF89a" + b"\0" * 100, "photo.png", id="gif named png"),
        pytest.param(b"\x89PNG\r\n\x1a\n" + b"garbage" * 20, "photo.png", id="png header, garbage body"),
        pytest.param(truncated_png(), "photo.png", id="truncated png"),
        pytest.param(b"", "photo.png", id="empty"),
    ],
)
def test_files_that_are_not_real_images_are_refused(storage, data, filename):
    with pytest.raises(ApiError) as caught:
        store_product_image(7, upload(data, filename))
    assert (caught.value.status, caught.value.message) == (400, NOT_AN_IMAGE)
    assert not storage.folder.exists() or not any(storage.folder.iterdir())  # nothing half-saved


def test_images_with_too_many_pixels_are_refused(app, storage, monkeypatch):
    monkeypatch.setitem(app.config, "MAX_IMAGE_PIXELS", 99)
    with pytest.raises(ApiError) as caught:
        store_product_image(7, upload(image_bytes(size=(10, 10)), "big.png"))
    assert caught.value.message == "The image's dimensions are too large."
    assert store_product_image(7, upload(image_bytes(size=(9, 11)), "ok.png"))


# -- delete_product_image --------------------------------------------------------------------------


def test_deleting_removes_the_original_and_its_thumbnail(storage):
    name = store_product_image(7, upload(image_bytes(), "a.png"))
    delete_product_image(name)
    assert not storage.exists(name) and not storage.exists(thumbnail_key(name))


@pytest.mark.parametrize("name", [None, ""])
def test_deleting_no_image_does_nothing(app, monkeypatch, name):
    monkeypatch.setattr(images, "get_storage", lambda: pytest.fail("storage should not be touched"))
    delete_product_image(name)


def test_a_file_that_cannot_be_deleted_is_logged_not_raised(app, monkeypatch, caplog):
    class LockedStorage:
        def delete(self, key):
            raise PermissionError("in use")

    monkeypatch.setattr(images, "get_storage", LockedStorage)
    with caplog.at_level(logging.WARNING, logger=images.__name__):
        delete_product_image(f"{STEM}.png")
    assert caplog.text.count("Could not delete product image") == 2  # original and thumbnail


# -- ensure_thumbnail ------------------------------------------------------------------------------


@pytest.mark.parametrize("original", [".png", ".jpg"])
def test_a_missing_thumbnail_is_made_from_its_original(storage, original):
    storage.save(f"{STEM}{original}", image_bytes("PNG" if original == ".png" else "JPEG", size=(600, 300)))
    ensure_thumbnail(f"{STEM}-thumb.jpg")
    assert opened(storage.read(f"{STEM}-thumb.jpg")).size == (256, 128)


def test_an_existing_thumbnail_is_left_alone(storage):
    storage.save(f"{STEM}.png", image_bytes())
    storage.save(f"{STEM}-thumb.jpg", b"already here")
    ensure_thumbnail(f"{STEM}-thumb.jpg")
    assert storage.read(f"{STEM}-thumb.jpg") == b"already here"


@pytest.mark.parametrize("key", [f"{STEM}.png", "logo-thumb.jpg", "7-abc-thumb.jpg", f"../{STEM}-thumb.jpg"])
def test_only_thumbnail_names_are_generated(storage, key):
    storage.save(f"{STEM}.png", image_bytes())
    ensure_thumbnail(key)
    assert sorted(p.name for p in storage.folder.iterdir()) == [f"{STEM}.png"]


def test_no_original_means_no_thumbnail(storage):
    ensure_thumbnail(f"{STEM}-thumb.jpg")
    assert not storage.exists(f"{STEM}-thumb.jpg")


def test_a_corrupt_original_is_logged_not_raised(storage, caplog):
    storage.save(f"{STEM}.png", b"\x89PNG\r\n\x1a\n not really")
    with caplog.at_level(logging.WARNING, logger=images.__name__):
        ensure_thumbnail(f"{STEM}-thumb.jpg")
    assert not storage.exists(f"{STEM}-thumb.jpg")
    assert "Could not create thumbnail" in caplog.text


# -- LocalImageStorage -----------------------------------------------------------------------------


def test_local_storage_round_trip(app, storage):
    assert storage.folder == Path(app.config["UPLOAD_FOLDER"]) / "products"
    assert not storage.exists("a.png")
    storage.save("a.png", b"data")  # creates the folder on first use
    assert storage.exists("a.png") and storage.read("a.png") == b"data"
    storage.delete("a.png")
    assert not storage.exists("a.png")
    storage.delete("a.png")  # deleting a missing file is fine


def test_local_storage_keys_cannot_leave_the_folder(app, storage):
    storage.save("../../escaped.png", b"data")
    assert (storage.folder / "escaped.png").read_bytes() == b"data"
    assert not (storage.folder.parent / "escaped.png").exists()
    assert not (storage.folder.parent.parent / "escaped.png").exists()
    assert storage.read("../escaped.png") == b"data"


def test_local_storage_urls(app, storage, monkeypatch):
    monkeypatch.setitem(app.config, "PUBLIC_BASE_URL", None)
    with app.test_request_context(base_url="https://portal.example.com"):
        assert storage.url("a.png") == "https://portal.example.com/media/products/a.png"
    monkeypatch.setitem(app.config, "PUBLIC_BASE_URL", "https://api.example.com/")
    assert storage.url("a.png") == "https://api.example.com/media/products/a.png"


def test_an_unknown_storage_backend_is_a_configuration_error(app, monkeypatch):
    monkeypatch.setitem(app.config, "IMAGE_STORAGE", "s3")
    with pytest.raises(RuntimeError, match=r"Unknown IMAGE_STORAGE 's3' \(supported: local\)"):
        get_storage()
