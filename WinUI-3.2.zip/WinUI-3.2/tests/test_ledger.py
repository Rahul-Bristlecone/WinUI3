from datetime import date, datetime, timedelta

from conftest import connect_retailer, place_order

from supplier_service.extensions.database import db


def today(api) -> date:
    """The business day (BUSINESS_TIMEZONE), as the API sees it."""
    return date.fromisoformat(api.get("/api/ledger/summary").json["date"][:10])


def send_invoice(app, api, number="ORD-0001", retailer_id=1, quantity=2, price=50) -> dict:
    """An order from a connected retailer, invoiced in full (GST on: 2 × 50 → 118)."""
    product = api.product(f"P{number[-4:]}", stock=100)
    order_id = place_order(app, api.supplier["id"], retailer_id, [(product["id"], quantity, price)], number=number)
    lines = [{"orderLineId": line["id"], "invoicedQuantity": line["quantity"]} for line in api.get(f"/api/orders/{order_id}").json["lines"]]
    sent = api.post("/api/invoices", {"orderId": order_id, "lines": lines})
    assert sent.status_code == 201, sent.json
    return sent.json


def offline_retailer(api, name="Shree Kirana Stores") -> dict:
    created = api.post("/api/ledger/accounts", {"name": name, "contactPerson": "Mohan Lal", "phone": "+91 98220 11111"})
    assert created.status_code == 201, created.json
    return created.json


def record(api, account_id: int, kind: str, amount, day: date, **fields) -> dict:
    created = api.post(f"/api/ledger/accounts/{account_id}/entries", {"type": kind, "date": day.isoformat(), "amount": amount, **fields})
    assert created.status_code == 201, created.json
    return created.json


def statement(api, account_id: int, start: date, end: date) -> dict:
    return api.get(f"/api/ledger/accounts/{account_id}/statement?from={start.isoformat()}&to={end.isoformat()}").json


def test_online_retailers_get_an_account_and_their_invoices_post_to_it(app, api):
    connect_retailer(app, api.supplier["id"], None)
    invoice = send_invoice(app, api)

    [account] = api.get("/api/ledger/accounts").json["items"]
    assert (account["name"], account["isOnline"], account["retailerId"], account["retailerCode"]) == ("Green Valley Mart", True, 1, "RTL-000001")
    assert (account["phone"], account["balance"], account["lastPaymentDate"], account["lastPaymentAmount"]) == ("+91 90000 10000", 118, None, None)
    assert (account["openingBalance"], account["openingBalanceDate"]) == (None, None)

    day = today(api)
    [entry] = statement(api, account["id"], day, day)["entries"]
    assert (entry["kind"], entry["reference"], entry["debit"], entry["credit"], entry["balance"]) == ("OnlineOrder", invoice["invoiceNumber"], 118, 0, 118)
    assert (entry["id"], entry["invoiceId"], entry["canVoid"]) == (None, invoice["id"], False)
    assert entry["description"] == "Online order ORD-0001"


def test_offline_retailer_entries_make_up_the_balance(api):
    day = today(api)
    shop = offline_retailer(api)
    assert (shop["isOnline"], shop["retailerId"], shop["contactPerson"], shop["balance"]) == (False, None, "Mohan Lal", 0)
    assert api.post("/api/ledger/accounts", {"name": "shree kirana stores"}).status_code == 409

    record(api, shop["id"], "OpeningBalance", 1000, day - timedelta(days=3))
    record(api, shop["id"], "OfflineOrder", 500.5, day - timedelta(days=1), reference="B-17")
    record(api, shop["id"], "Payment", 50, day - timedelta(days=2), paymentMode="Cash")
    payment = record(api, shop["id"], "Payment", 300, day, paymentMode="Upi", collectedBy="Ravi", reference="UPI-9921")
    assert (payment["kind"], payment["debit"], payment["credit"]) == ("Payment", 0, 300)
    assert payment["description"] == "Payment (UPI), collected by Ravi"
    record(api, shop["id"], "Payment", 25, day, paymentMode="Cash")
    # Payment details are kept for payments only.
    order = record(api, shop["id"], "OfflineOrder", 99.5, day, paymentMode="Cash", collectedBy="Ravi")
    assert (order["paymentMode"], order["collectedBy"], order["description"]) == (None, "", "Offline order")

    account = api.get("/api/ledger/accounts").json["items"][0]
    assert account["balance"] == 1225
    # The last day money came in, and all of that day's payments.
    assert (account["lastPaymentDate"], account["lastPaymentAmount"]) == (f"{day.isoformat()}T00:00:00", 325)
    assert (account["openingBalance"], account["openingBalanceDate"]) == (1000, f"{(day - timedelta(days=3)).isoformat()}T00:00:00")


def test_entries_are_validated(api):
    day = today(api)
    shop = offline_retailer(api)
    url = f"/api/ledger/accounts/{shop['id']}/entries"

    def message(body):
        response = api.post(url, {"date": day.isoformat(), "amount": 10, **body})
        assert response.status_code == 400
        return response.json["message"]

    assert message({"type": "Payment"}) == "Choose how the payment was made."
    assert message({"type": "OfflineOrder", "amount": 0}) == "amount must be greater than 0."
    assert message({"type": "OfflineOrder", "amount": 0.004}) == "Amount must be greater than zero."
    assert message({"type": "OfflineOrder", "date": (day + timedelta(days=1)).isoformat()}) == "The date can't be in the future."
    assert message({"type": "Refund"}).startswith("type:")
    assert message({"type": "Payment", "paymentMode": "Card"}).startswith("paymentMode:")

    record(api, shop["id"], "OpeningBalance", 100, day)
    assert message({"type": "OpeningBalance"}) == "This retailer already has an opening balance. Void it to enter a different one."
    assert api.post("/api/ledger/accounts/999/entries", {"type": "OfflineOrder", "date": day.isoformat(), "amount": 1}).status_code == 404


def test_a_voided_entry_stays_listed_but_stops_counting(api, other_api):
    day = today(api)
    shop = offline_retailer(api)
    record(api, shop["id"], "OfflineOrder", 500, day)
    wrong = record(api, shop["id"], "Payment", 5000, day, paymentMode="Cash")

    assert api.post(f"/api/ledger/entries/{wrong['id']}/void", {"reason": " "}).json["message"] == "reason is required."
    assert other_api.post(f"/api/ledger/entries/{wrong['id']}/void", {"reason": "typo"}).status_code == 404
    voided = api.post(f"/api/ledger/entries/{wrong['id']}/void", {"reason": "Typed 5000 instead of 500"}).json
    assert (voided["isVoided"], voided["voidReason"], voided["canVoid"]) == (True, "Typed 5000 instead of 500", False)
    assert api.post(f"/api/ledger/entries/{wrong['id']}/void", {"reason": "again"}).json["message"] == "This entry is already voided."

    # Voiding the opening balance allows a new one.
    opening = record(api, shop["id"], "OpeningBalance", 50, day)
    api.post(f"/api/ledger/entries/{opening['id']}/void", {"reason": "Wrong retailer"})
    record(api, shop["id"], "OpeningBalance", 70, day)

    listed = statement(api, shop["id"], day, day)
    assert [(e["kind"], e["isVoided"], e["balance"]) for e in listed["entries"]] == [
        ("OpeningBalance", True, None), ("OpeningBalance", False, 70), ("OfflineOrder", False, 570), ("Payment", True, None),
    ]
    assert (listed["totalDebit"], listed["totalCredit"], listed["closingBalance"]) == (570, 0, 570)
    assert (listed["account"]["openingBalance"], listed["account"]["lastPaymentAmount"]) == (70, None)  # voided ones don't show


def test_statement_carries_the_balance_into_the_chosen_dates(app, api):
    connect_retailer(app, api.supplier["id"], None)
    send_invoice(app, api)  # 118, today
    account = api.get("/api/ledger/accounts").json["items"][0]
    day = today(api)
    record(api, account["id"], "OpeningBalance", 1000, day - timedelta(days=5))
    record(api, account["id"], "OfflineOrder", 200, day - timedelta(days=2))
    record(api, account["id"], "Payment", 400, day - timedelta(days=1), paymentMode="Cash")

    listed = statement(api, account["id"], day - timedelta(days=2), day)
    assert (listed["from"], listed["to"]) == (f"{(day - timedelta(days=2)).isoformat()}T00:00:00", f"{day.isoformat()}T00:00:00")
    assert listed["openingBalance"] == 1000
    assert [(e["kind"], e["debit"], e["credit"], e["balance"]) for e in listed["entries"]] == [
        ("OfflineOrder", 200, 0, 1200), ("Payment", 0, 400, 800), ("OnlineOrder", 118, 0, 918),
    ]
    assert (listed["totalDebit"], listed["totalCredit"], listed["closingBalance"]) == (318, 400, 918)
    assert listed["account"]["balance"] == 918

    backwards = api.get(f"/api/ledger/accounts/{account['id']}/statement?from={day.isoformat()}&to={(day - timedelta(days=1)).isoformat()}")
    assert backwards.json["message"] == "The To date can't be before the From date."
    assert api.get(f"/api/ledger/accounts/{account['id']}/statement?from=yesterday").json["message"] == "from: enter a valid date."


def test_day_book_shows_what_each_retailer_owed_ordered_and_paid(app, api):
    connect_retailer(app, api.supplier["id"], None)
    send_invoice(app, api)  # 118 online, today
    day = today(api)
    online = next(a for a in api.get("/api/ledger/accounts/all").json if a["isOnline"])
    shop = offline_retailer(api)
    new_shop = offline_retailer(api, "Laxmi General")
    offline_retailer(api, "Nothing Owed Mart")

    record(api, online["id"], "OfflineOrder", 50, day)  # a phone order from an onboarded retailer
    record(api, shop["id"], "OpeningBalance", 1000, day - timedelta(days=10))
    record(api, shop["id"], "OfflineOrder", 300, day)
    record(api, shop["id"], "Payment", 400, day, paymentMode="Cash")
    record(api, new_shop["id"], "OpeningBalance", 250, day)  # carried over from the paper ledger today

    book = api.get(f"/api/ledger/daybook?date={day.isoformat()}").json
    assert book["date"] == f"{day.isoformat()}T00:00:00"
    rows = {row["name"]: row for row in book["rows"]}
    assert list(rows) == ["Green Valley Mart", "Laxmi General", "Shree Kirana Stores"]  # nothing owed or done: not listed
    columns = ("openingBalance", "onlineOrders", "offlineOrders", "payments", "closingBalance")
    assert [rows["Green Valley Mart"][c] for c in columns] == [0, 118, 50, 0, 168]
    assert [rows["Laxmi General"][c] for c in columns] == [250, 0, 0, 0, 250]
    assert [rows["Shree Kirana Stores"][c] for c in columns] == [1000, 0, 300, 400, 900]
    assert rows["Shree Kirana Stores"]["accountId"] == shop["id"] and rows["Shree Kirana Stores"]["isOnline"] is False
    assert book["totals"] == {"openingBalance": 1250, "onlineOrders": 118, "offlineOrders": 350, "payments": 400, "closingBalance": 1318}

    # The day before: only the older opening balance.
    earlier = api.get(f"/api/ledger/daybook?date={(day - timedelta(days=1)).isoformat()}").json
    assert [(r["name"], r["openingBalance"], r["closingBalance"]) for r in earlier["rows"]] == [("Shree Kirana Stores", 1000, 1000)]

    summary = api.get("/api/ledger/summary").json
    assert (summary["accountCount"], summary["accountsWithDues"], summary["totalDue"]) == (4, 3, 1318)
    assert (summary["todayOrders"], summary["todayPayments"]) == (468, 400)


def test_an_invoice_counts_on_the_business_day_it_was_sent(app, api):
    """Business days are India time by default: 20:00 UTC on 3 Nov is 01:30 on 4 Nov."""
    connect_retailer(app, api.supplier["id"], None)
    invoice = send_invoice(app, api)
    from supplier_service.invoices.models import Invoice

    with app.app_context():
        db.session.get(Invoice, invoice["id"]).invoice_date = datetime(2026, 11, 3, 20, 0)
        db.session.commit()

    def online_orders(day: str):
        return [row["onlineOrders"] for row in api.get(f"/api/ledger/daybook?date={day}").json["rows"]]

    assert online_orders("2026-11-04") == [118]
    assert online_orders("2026-11-03") == []
    account = api.get("/api/ledger/accounts").json["items"][0]
    [entry] = statement(api, account["id"], date(2026, 11, 1), date(2026, 11, 30))["entries"]
    assert entry["date"] == "2026-11-04T00:00:00"


def test_linking_an_onboarded_retailer_joins_their_history(app, api):
    day = today(api)
    shop = offline_retailer(api, "Green Valley Kirana")
    record(api, shop["id"], "OpeningBalance", 1000, day - timedelta(days=30))
    api.put(f"/api/ledger/accounts/{shop['id']}", {"name": "Green Valley Kirana", "notes": "Pays on Saturdays"})

    # They onboard as Green Valley Mart, order online and pay against the new account before anyone links them.
    connect_retailer(app, api.supplier["id"], None)
    send_invoice(app, api)
    online = next(a for a in api.get("/api/ledger/accounts").json["items"] if a["isOnline"])
    record(api, online["id"], "Payment", 100, day, paymentMode="Cash")

    assert api.post(f"/api/ledger/accounts/{shop['id']}/link", {"retailerId": 2}).json["message"] == "Retailer not found among your connected retailers."
    linked = api.post(f"/api/ledger/accounts/{shop['id']}/link", {"retailerId": 1}).json
    assert (linked["id"], linked["isOnline"], linked["name"], linked["notes"], linked["balance"]) == (shop["id"], True, "Green Valley Mart", "Pays on Saturdays", 1018)
    assert [a["id"] for a in api.get("/api/ledger/accounts").json["items"]] == [shop["id"]]
    entries = statement(api, shop["id"], day - timedelta(days=30), day)["entries"]
    assert [e["kind"] for e in entries] == ["OpeningBalance", "OnlineOrder", "Payment"]  # same day: in the order they happened

    assert api.post(f"/api/ledger/accounts/{shop['id']}/link", {"retailerId": 1}).json["message"] == "This retailer is already online."
    edit = api.put(f"/api/ledger/accounts/{shop['id']}", {"name": "Renamed"})
    assert edit.json["message"] == "An online retailer's details come from their own profile."


def area(item) -> tuple:
    return item["circleName"], item["locationName"]


def test_online_and_offline_retailers_are_in_circles(app, api, other_api):
    for retailer_id, name in ((1, "Green Valley Mart"), (2, "City Fresh Grocers")):
        connect_retailer(app, api.supplier["id"], None, retailer_id=retailer_id, name=name)
    north = api.post("/api/circles", {"name": "North", "locations": [{"name": "Karol Bagh"}, {"name": "Rohini"}]}).json
    karol_bagh, rohini = (location["id"] for location in north["locations"])
    api.put("/api/retailers/1/area", {"circleId": north["id"], "locationId": karol_bagh})

    shop = api.post("/api/ledger/accounts", {"name": "Shree Kirana", "circleId": north["id"], "locationId": rohini}).json
    assert (shop["circleId"], shop["locationId"], area(shop)) == (north["id"], rohini, ("North", "Rohini"))
    bad = api.post("/api/ledger/accounts", {"name": "Bad", "circleId": north["id"], "locationId": 999})
    assert (bad.status_code, bad.json["message"]) == (400, "Location not found.")
    assert api.post("/api/ledger/accounts", {"name": "Bad", "circleId": 999}).json["message"] == "Circle not found."
    edited = api.put(f"/api/ledger/accounts/{shop['id']}", {"name": "Shree Kirana", "circleId": north["id"]}).json
    assert area(edited) == ("North", None)
    cleared = api.put(f"/api/ledger/accounts/{shop['id']}", {"name": "Shree Kirana", "circleId": None, "locationId": rohini}).json
    assert area(cleared) == (None, None)
    api.put(f"/api/ledger/accounts/{shop['id']}", {"name": "Shree Kirana", "circleId": north["id"], "locationId": rohini})

    # Online accounts show their retailer's area; search matches circle and location names.
    areas = {a["name"]: area(a) for a in api.get("/api/ledger/accounts").json["items"]}
    assert areas == {"City Fresh Grocers": (None, None), "Green Valley Mart": ("North", "Karol Bagh"), "Shree Kirana": ("North", "Rohini")}

    def names(query):
        return [a["name"] for a in api.get(f"/api/ledger/accounts?{query}").json["items"]]

    assert names("search=north") == ["Green Valley Mart", "Shree Kirana"]
    assert names("search=rohini") == ["Shree Kirana"]
    assert names(f"circleId={north['id']}") == ["Green Valley Mart", "Shree Kirana"]
    assert names(f"locationId={karol_bagh}") == ["Green Valley Mart"]
    assert names("circleId=999") == []

    # Linking: the retailer keeps its own area; one without takes the offline account's.
    banner = api.post("/api/ledger/accounts", {"name": "Banner Stores", "circleId": north["id"], "locationId": rohini}).json
    linked = api.post(f"/api/ledger/accounts/{banner['id']}/link", {"retailerId": 2}).json
    assert area(linked) == ("North", "Rohini")
    assert area(next(r for r in api.get("/api/retailers").json["items"] if r["id"] == 2)) == ("North", "Rohini")
    wakad = api.post("/api/ledger/accounts", {"name": "Wakad Mart", "circleId": north["id"], "locationId": rohini}).json
    assert area(api.post(f"/api/ledger/accounts/{wakad['id']}/link", {"retailerId": 1}).json) == ("North", "Karol Bagh")
    # The linked accounts no longer count on their own: only the two retailers and Shree Kirana remain.
    circle = api.get("/api/circles").json[0]
    assert (circle["retailerCount"], [l["retailerCount"] for l in circle["locations"]]) == (3, [1, 2])

    day = today(api)
    record(api, shop["id"], "OfflineOrder", 10, day)
    [row] = api.get(f"/api/ledger/daybook?date={day.isoformat()}").json["rows"]
    assert (row["name"], row["circleId"], row["locationId"], area(row)) == ("Shree Kirana", north["id"], rohini, ("North", "Rohini"))


def test_accounts_list_searches_sorts_and_stays_private(app, api, other_api):
    day = today(api)
    small, big = offline_retailer(api, "Alpha Stores"), offline_retailer(api, "Beta Mart")
    offline_retailer(api, "Gamma Traders")
    record(api, small["id"], "OfflineOrder", 10, day)
    record(api, big["id"], "OfflineOrder", 900, day)

    assert [a["name"] for a in api.get("/api/ledger/accounts").json["items"]] == ["Alpha Stores", "Beta Mart", "Gamma Traders"]
    by_dues = api.get("/api/ledger/accounts?sortBy=balance&pageSize=2").json
    assert ([a["name"] for a in by_dues["items"]], by_dues["totalCount"]) == (["Beta Mart", "Alpha Stores"], 3)
    assert [a["name"] for a in api.get("/api/ledger/accounts?search=mart").json["items"]] == ["Beta Mart"]

    assert other_api.get("/api/ledger/accounts").json["items"] == []
    assert other_api.get(f"/api/ledger/accounts/{big['id']}/statement").status_code == 404
    assert other_api.put(f"/api/ledger/accounts/{big['id']}", {"name": "Mine"}).status_code == 404
    assert other_api.post("/api/ledger/accounts", {"name": "Beta Mart"}).status_code == 201  # names are per supplier


def test_accounts_list_filters_and_sorts_by_column(app, api):
    day = today(api)
    connect_retailer(app, api.supplier["id"], None)
    east = api.post("/api/circles", {"name": "East", "locations": [{"name": "Laxmi Nagar"}]}).json
    laxmi_nagar = east["locations"][0]["id"]
    west = api.post("/api/circles", {"name": "West"}).json
    api.put("/api/retailers/1/area", {"circleId": east["id"], "locationId": laxmi_nagar})
    send_invoice(app, api)  # Green Valley Mart owes 118
    [green] = api.get("/api/ledger/accounts").json["items"]
    alpha = api.post("/api/ledger/accounts", {"name": "Alpha Stores", "circleId": east["id"]}).json
    beta = offline_retailer(api, "Beta Mart")
    api.post("/api/ledger/accounts", {"name": "Gamma Traders", "circleId": west["id"]})  # never paid, owes 0
    record(api, alpha["id"], "OfflineOrder", 500, day - timedelta(days=3))
    record(api, alpha["id"], "Payment", 100, day - timedelta(days=1), paymentMode="Cash")  # owes 400
    record(api, beta["id"], "OfflineOrder", 300, day - timedelta(days=3))
    record(api, beta["id"], "Payment", 300, day - timedelta(days=2), paymentMode="Upi")  # owes 0
    record(api, green["id"], "Payment", 18, day - timedelta(days=1), paymentMode="Cash")  # owes 100

    def names(query=""):
        return [a["name"] for a in api.get(f"/api/ledger/accounts?{query}").json["items"]]

    alpha_beta_gamma_green = ["Alpha Stores", "Beta Mart", "Gamma Traders", "Green Valley Mart"]
    assert names() == alpha_beta_gamma_green
    assert names("sortDir=desc") == alpha_beta_gamma_green[::-1]
    # Equal balances stay A-Z both ways; with no sortDir, balance is largest first.
    assert names("sortBy=balance&sortDir=asc") == ["Beta Mart", "Gamma Traders", "Green Valley Mart", "Alpha Stores"]
    assert names("sortBy=balance&sortDir=desc") == ["Alpha Stores", "Green Valley Mart", "Beta Mart", "Gamma Traders"]
    assert names("sortBy=balance") == names("sortBy=balance&sortDir=desc")
    # By day, then that day's amount; never paid is last both ways.
    assert names("sortBy=lastPayment&sortDir=asc") == ["Beta Mart", "Green Valley Mart", "Alpha Stores", "Gamma Traders"]
    assert names("sortBy=lastPayment&sortDir=desc") == ["Alpha Stores", "Green Valley Mart", "Beta Mart", "Gamma Traders"]

    # The online account matches on its retailer's circle and location.
    assert names(f"circleId={east['id']}") == ["Alpha Stores", "Green Valley Mart"]
    assert names(f"locationId={laxmi_nagar}") == ["Green Valley Mart"]
    assert names("type=online") == ["Green Valley Mart"]
    assert names("type=offline") == ["Alpha Stores", "Beta Mart", "Gamma Traders"]
    assert names("dues=true") == ["Alpha Stores", "Green Valley Mart"]
    assert names(f"circleId={east['id']}&type=offline&dues=true") == ["Alpha Stores"]
    assert names("search=mart&dues=true") == ["Green Valley Mart"]
    paged = api.get("/api/ledger/accounts?dues=true&sortBy=balance&sortDir=asc&pageSize=1&page=2").json
    assert ([a["name"] for a in paged["items"]], paged["totalCount"]) == (["Alpha Stores"], 2)
    assert api.get("/api/ledger/summary").json["accountCount"] == 4  # the summary isn't filtered
