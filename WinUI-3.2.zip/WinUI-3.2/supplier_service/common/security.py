from datetime import datetime, timezone
from functools import wraps

import jwt
from flask import current_app, g, request

from supplier_service.auth.models import Supplier
from supplier_service.common.errors import ApiError
from supplier_service.extensions.database import db

SESSION_EXPIRED = "Your session has expired. Please sign in again."
_ALGORITHM = "HS256"


def issue_token(supplier: Supplier) -> tuple[str, datetime]:
    issued = datetime.now(timezone.utc)
    expires = issued + current_app.config["JWT_EXPIRES"]
    claims = {
        "sub": str(supplier.id),
        "email": supplier.email,
        "supplierCode": supplier.supplier_code,
        "iat": issued,
        "exp": expires,
    }
    return jwt.encode(claims, current_app.config["JWT_SECRET_KEY"], algorithm=_ALGORITHM), expires


def require_supplier() -> None:
    """Authenticates the bearer token and loads the supplier into g. Usable as a before_request hook."""
    scheme, _, token = request.headers.get("Authorization", "").partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise ApiError(401, SESSION_EXPIRED)
    try:
        claims = jwt.decode(
            token, current_app.config["JWT_SECRET_KEY"], algorithms=[_ALGORITHM], options={"require": ["exp", "sub"]}
        )
        supplier_id = int(claims["sub"])
    except (jwt.PyJWTError, ValueError):
        raise ApiError(401, SESSION_EXPIRED) from None
    supplier = db.session.get(Supplier, supplier_id)
    if supplier is None or not supplier.is_active:
        raise ApiError(401, SESSION_EXPIRED)
    g.supplier = supplier


def auth_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        require_supplier()
        return view(*args, **kwargs)

    return wrapper


def current_supplier() -> Supplier:
    return g.supplier
