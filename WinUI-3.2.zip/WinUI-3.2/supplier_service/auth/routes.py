from flask import Blueprint
from sqlalchemy import select

from supplier_service.auth.models import Supplier
from supplier_service.auth.schemas import (
    ChangePasswordRequest,
    LoginRequest,
    ProfileRequest,
    RegisterRequest,
    profile_json,
)
from supplier_service.common.errors import ApiError
from supplier_service.common.http import iso_timestamp, parse_body
from supplier_service.common.security import auth_required, current_supplier, issue_token
from supplier_service.extensions.database import db
from supplier_service.pricing.models import STANDARD_GROUP, PriceGroup

bp = Blueprint("auth", __name__, url_prefix="/api")


@bp.post("/auth/login")
def login():
    body = parse_body(LoginRequest)
    supplier = db.session.scalar(select(Supplier).filter_by(email=body.email))
    if supplier is None or not supplier.check_password(body.password):
        raise ApiError(401, "Invalid email or password.")
    if not supplier.is_active:
        raise ApiError(403, "This supplier account has been deactivated.")
    token, expires_at = issue_token(supplier)
    return {"token": token, "expiresAt": iso_timestamp(expires_at), "supplier": profile_json(supplier)}


@bp.post("/auth/register")
def register():
    body = parse_body(RegisterRequest)
    if db.session.scalar(select(Supplier.id).filter_by(email=body.email)) is not None:
        raise ApiError(409, "An account with this email already exists.")
    supplier = Supplier(email=body.email, supplier_code=_unique_supplier_code(body.company_name))
    body.apply_to(supplier)
    supplier.set_password(body.password)
    db.session.add(supplier)
    db.session.flush()
    # Every supplier starts with the Standard price group, which retailers use until assigned another.
    db.session.add(PriceGroup(
        supplier_id=supplier.id, group_name=STANDARD_GROUP, description="Default prices for every retailer", is_default=True,
    ))
    db.session.commit()
    return {"supplierCode": supplier.supplier_code, "message": "Registration successful."}, 201


def _unique_supplier_code(company_name: str) -> str:
    # generate_supplier_code() yields one code per 4-letter prefix per day; suffix same-day repeats.
    base = Supplier.generate_supplier_code(company_name)
    taken = set(db.session.scalars(select(Supplier.supplier_code).where(Supplier.supplier_code.like(f"{base}%"))))
    if base not in taken:
        return base
    suffix = 2
    while f"{base}-{suffix}" in taken:
        suffix += 1
    return f"{base}-{suffix}"


@bp.post("/auth/change-password")
@auth_required
def change_password():
    body = parse_body(ChangePasswordRequest)
    supplier = current_supplier()
    if not supplier.check_password(body.current_password):
        raise ApiError(400, "Current password is incorrect.")
    if body.new_password == body.current_password:
        raise ApiError(400, "New password must differ from the current password.")
    supplier.set_password(body.new_password)
    db.session.commit()
    return "", 204


@bp.get("/supplier/profile")
@auth_required
def get_profile():
    return profile_json(current_supplier())


@bp.put("/supplier/profile")
@auth_required
def update_profile():
    body = parse_body(ProfileRequest)
    supplier = current_supplier()
    body.apply_to(supplier)
    db.session.commit()
    return profile_json(supplier)
