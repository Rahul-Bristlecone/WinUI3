from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import Field, model_validator

from supplier_service.circles.models import Circle, CircleLocation
from supplier_service.circles.service import area_json
from supplier_service.common.http import CalendarDate, OptionalText, RequestSchema, Text, iso_calendar_date
from supplier_service.invoices.models import Invoice
from supplier_service.ledger.models import ONLINE_ORDER, PAYMENT_MODES, EntryType, LedgerAccount, LedgerEntry
from supplier_service.ledger.service import ZERO, Totals, business_day
from supplier_service.retailers.models import Retailer

MAX_AMOUNT = Decimal("9999999999.99")  # NUMERIC(12, 2)


class AccountRequest(RequestSchema):
    """An offline retailer's details."""

    name: Text = Field(min_length=1, max_length=120)
    contact_person: OptionalText = Field(default=None, max_length=120)
    phone: OptionalText = Field(default=None, max_length=20)
    address: OptionalText = Field(default=None, max_length=500)
    notes: OptionalText = Field(default=None, max_length=1000)
    # A null circle clears both.
    circle_id: int | None = None
    location_id: int | None = None


class LinkRequest(RequestSchema):
    retailer_id: int


class EntryRequest(RequestSchema):
    entry_type: Literal["OpeningBalance", "OfflineOrder", "Payment"] = Field(alias="type")
    entry_date: CalendarDate = Field(alias="date")
    amount: Decimal = Field(gt=0, le=MAX_AMOUNT)
    reference: OptionalText = Field(default=None, max_length=64)
    # Payments only (ignored otherwise).
    payment_mode: Literal["Cash", "Upi", "Cheque", "BankTransfer", "Other"] | None = None
    collected_by: OptionalText = Field(default=None, max_length=120)
    notes: OptionalText = Field(default=None, max_length=1000)

    @model_validator(mode="after")
    def _payment_mode(self):
        if self.entry_type == EntryType.PAYMENT and self.payment_mode is None:
            raise ValueError("Choose how the payment was made.")
        return self


class VoidRequest(RequestSchema):
    reason: Text = Field(min_length=1, max_length=250)


def account_name(account: LedgerAccount, retailer: Retailer | None) -> str:
    if retailer is not None:
        return retailer.business_name
    return account.name or f"Retailer #{account.retailer_id}"


def account_json(
    account: LedgerAccount,
    retailer: Retailer | None,
    circle: Circle | None,
    location: CircleLocation | None,
    balance: Decimal,
    last_payment: tuple[date, Decimal] | None = None,
    opening: tuple[date, Decimal] | None = None,
) -> dict:
    """circle / location: the online retailer's (retailer_settings), else the offline account's own.
    last_payment / opening: (day, amount), from last_payments() / opening_balances()."""
    # An online retailer's own profile wins over details kept from before they onboarded.
    return {
        "id": account.id,
        "name": account_name(account, retailer),
        "isOnline": account.retailer_id is not None,
        "retailerId": account.retailer_id,
        "retailerCode": (retailer.retailer_code if retailer else None) or "",
        "contactPerson": (retailer.contact_person if retailer else account.contact_person) or "",
        "phone": (retailer.phone if retailer else account.phone) or "",
        "address": (retailer.full_address if retailer else account.address) or "",
        "notes": account.notes or "",
        **area_json(circle, location),
        # What the retailer owes; negative = paid in advance.
        "balance": balance,
        # The latest day a payment came in, and the total received that day.
        "lastPaymentDate": iso_calendar_date(last_payment[0]) if last_payment else None,
        "lastPaymentAmount": last_payment[1] if last_payment else None,
        # The non-voided OpeningBalance entry (null until one is recorded).
        "openingBalance": opening[1] if opening else None,
        "openingBalanceDate": iso_calendar_date(opening[0]) if opening else None,
    }


_DESCRIPTIONS = {EntryType.OPENING_BALANCE: "Opening balance", EntryType.OFFLINE_ORDER: "Offline order"}


def _description(entry: LedgerEntry) -> str:
    if entry.entry_type != EntryType.PAYMENT:
        return _DESCRIPTIONS[entry.entry_type]
    text = f"Payment ({PAYMENT_MODES.get(entry.payment_mode, entry.payment_mode)})"
    return f"{text}, collected by {entry.collected_by}" if entry.collected_by else text


def entry_json(entry: LedgerEntry, balance: Decimal | None = None) -> dict:
    """balance: the running balance after this entry, in a statement (voided entries don't move it)."""
    debit = entry.entry_type in EntryType.DEBITS
    voided = entry.voided_at is not None
    return {
        "id": entry.id,
        "kind": entry.entry_type,
        "date": iso_calendar_date(entry.entry_date),
        "description": _description(entry),
        "reference": entry.reference or "",
        "paymentMode": entry.payment_mode,
        "collectedBy": entry.collected_by or "",
        "notes": entry.notes or "",
        "debit": entry.amount if debit else ZERO,
        "credit": ZERO if debit else entry.amount,
        "balance": None if voided else balance,
        "isVoided": voided,
        "voidReason": entry.void_reason or "",
        "invoiceId": None,
        "canVoid": not voided,
    }


def invoice_entry_json(invoice: Invoice, order_number: str, balance: Decimal | None = None) -> dict:
    """A sent invoice as a statement entry: read-only (fixing it means fixing the invoice)."""
    return {
        "id": None,
        "kind": ONLINE_ORDER,
        "date": iso_calendar_date(business_day(invoice.invoice_date)),
        "description": f"Online order {order_number}",
        "reference": invoice.invoice_number,
        "paymentMode": None,
        "collectedBy": "",
        "notes": "",
        "debit": invoice.grand_total,
        "credit": ZERO,
        "balance": balance,
        "isVoided": False,
        "voidReason": "",
        "invoiceId": invoice.id,
        "canVoid": False,
    }


def day_book_amounts(owed_at_start: Decimal, day: Totals) -> dict:
    return {
        "openingBalance": owed_at_start,
        "onlineOrders": day.online_orders,
        "offlineOrders": day.offline_orders,
        "payments": day.payments,
        "closingBalance": owed_at_start + day.online_orders + day.offline_orders - day.payments,
    }
