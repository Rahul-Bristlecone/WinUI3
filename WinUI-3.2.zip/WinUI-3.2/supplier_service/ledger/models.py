from sqlalchemy import UniqueConstraint
from supplier_service.common.base_model import BaseModel
from supplier_service.extensions.database import db


class EntryType:
    """What the supplier records in the ledger. Online orders aren't stored: they are read from sent invoices."""

    OPENING_BALANCE = "OpeningBalance"
    OFFLINE_ORDER = "OfflineOrder"
    PAYMENT = "Payment"
    VALUES = {OPENING_BALANCE, OFFLINE_ORDER, PAYMENT}
    # Raise what the retailer owes; a payment lowers it.
    DEBITS = {OPENING_BALANCE, OFFLINE_ORDER}


# The API's kind for a sent invoice in a statement.
ONLINE_ORDER = "OnlineOrder"

PAYMENT_MODES = {"Cash": "Cash", "Upi": "UPI", "Cheque": "Cheque", "BankTransfer": "Bank transfer", "Other": "Other"}


class LedgerAccount(BaseModel):
    """A retailer the supplier keeps a ledger for.

    Connected (online) retailers get one automatically, keyed by retailer_id, and their details come from the
    retailer service. Offline retailers are added by the supplier with their own details; once one onboards,
    linking sets retailer_id, so their offline history and new invoices share one balance.
    """

    __tablename__ = "ledger_accounts"
    __table_args__ = (
        UniqueConstraint("supplier_id", "retailer_id", name="uq_ledger_account_retailer"),
    )
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False, index=True)
    # No foreign key: retailers live in the retailer service's schema. Null for an offline retailer.
    retailer_id = db.Column(db.Integer, nullable=True, index=True)
    # Offline retailers' details (an online retailer's own profile takes precedence).
    name = db.Column(db.String(120), nullable=True)
    contact_person = db.Column(db.String(120), nullable=True)
    phone = db.Column(db.String(20), nullable=True)
    address = db.Column(db.String(500), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    # Offline accounts only: an online account shows its retailer's circle and location (retailer_settings).
    circle_id = db.Column(db.Integer, db.ForeignKey("circles.id"), nullable=True, index=True)
    location_id = db.Column(db.Integer, db.ForeignKey("circle_locations.id"), nullable=True, index=True)


class LedgerEntry(BaseModel):
    """An entry the supplier recorded. Entries are never edited or deleted: a wrong one is voided, with a reason."""

    __tablename__ = "ledger_entries"
    id = db.Column(db.Integer, primary_key=True)
    account_id = db.Column(db.Integer, db.ForeignKey("ledger_accounts.id"), nullable=False, index=True)
    entry_type = db.Column(db.String(20), nullable=False)
    # The business day (BUSINESS_TIMEZONE) it belongs to, as written in the ledger book.
    entry_date = db.Column(db.Date, nullable=False, index=True)
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    reference = db.Column(db.String(64), nullable=True)  # bill no., cheque no., UPI reference
    payment_mode = db.Column(db.String(20), nullable=True)
    collected_by = db.Column(db.String(120), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    voided_at = db.Column(db.DateTime, nullable=True)
    void_reason = db.Column(db.Text, nullable=True)
    account = db.relationship("LedgerAccount", backref=db.backref("entries", lazy="dynamic"))
