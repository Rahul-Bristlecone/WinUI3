from datetime import timedelta
from decimal import ROUND_HALF_UP, Decimal

from flask import Blueprint, request
from sqlalchemy import and_, case, func, or_, select, update

from supplier_service.circles.models import Circle, CircleLocation
from supplier_service.circles.service import checked_area
from supplier_service.common.base_model import utcnow
from supplier_service.common.errors import ApiError, not_found
from supplier_service.common.http import (
    contains,
    iso_calendar_date,
    iso_timestamp,
    paginate_list,
    parse_body,
    query_date,
    search_term,
    sort_descending,
)
from supplier_service.common.security import current_supplier, require_supplier
from supplier_service.extensions.database import db
from supplier_service.invoices.models import Invoice
from supplier_service.ledger.models import EntryType, LedgerAccount, LedgerEntry
from supplier_service.ledger.schemas import (
    AccountRequest,
    EntryRequest,
    LinkRequest,
    PaymentUpdateRequest,
    VoidRequest,
    account_json,
    day_book_amounts,
    entry_json,
    invoice_entry_json,
)
from supplier_service.ledger.service import (
    ZERO,
    business_day,
    business_today,
    day_start,
    ensure_online_accounts,
    last_payments,
    opening_balances,
    sent_invoices,
    totals,
)
from supplier_service.orders.models import Order
from supplier_service.retailers.models import Retailer, RetailerSettings, SupplierConnection
from supplier_service.retailers.service import settings_for

bp = Blueprint("ledger", __name__, url_prefix="/api")
bp.before_request(require_supplier)

MONEY = Decimal("0.01")
DAY_BOOK_ACCOUNT_KEYS = ("name", "isOnline", "circleId", "circleName", "locationId", "locationName")


def _account_rows(supplier_id: int):
    """select(LedgerAccount, Retailer | None, Circle | None, CircleLocation | None).

    The circle and location are the online retailer's (retailer_settings), else the offline account's own."""
    offline = LedgerAccount.retailer_id.is_(None)
    circle_id = case((offline, LedgerAccount.circle_id), else_=RetailerSettings.circle_id)
    location_id = case((offline, LedgerAccount.location_id), else_=RetailerSettings.location_id)
    return (
        select(LedgerAccount, Retailer, Circle, CircleLocation)
        .outerjoin(Retailer, Retailer.id == LedgerAccount.retailer_id)
        .outerjoin(
            RetailerSettings,
            and_(
                RetailerSettings.supplier_id == LedgerAccount.supplier_id,
                RetailerSettings.retailer_id == LedgerAccount.retailer_id,
            ),
        )
        .outerjoin(Circle, Circle.id == circle_id)
        .outerjoin(CircleLocation, CircleLocation.id == location_id)
        .where(LedgerAccount.supplier_id == supplier_id)
    )


def _accounts(search: str | None = None) -> list[dict]:
    """Every account (online ones created as needed) with its balance, by name."""
    supplier_id = current_supplier().id
    ensure_online_accounts(supplier_id)
    stmt = _account_rows(supplier_id)
    if search:
        pattern = contains(search)
        stmt = stmt.where(
            or_(
                LedgerAccount.name.ilike(pattern, escape="\\"),
                Retailer.business_name.ilike(pattern, escape="\\"),
                Retailer.retailer_code.ilike(pattern, escape="\\"),
                Circle.name.ilike(pattern, escape="\\"),
                CircleLocation.name.ilike(pattern, escape="\\"),
            )
        )
    balances = totals(supplier_id)
    paid = last_payments(supplier_id)
    openings = opening_balances(supplier_id)
    accounts = [
        account_json(account, retailer, circle, location, balances[account.id].net, paid.get(account.id), openings.get(account.id))
        for account, retailer, circle, location in db.session.execute(stmt)
    ]
    return sorted(accounts, key=lambda a: (a["name"].lower(), a["id"]))


def _owned_row(account_id: int):
    row = db.session.execute(_account_rows(current_supplier().id).where(LedgerAccount.id == account_id)).first()
    if row is None:
        raise not_found()
    return row


def _owned_account(account_id: int) -> LedgerAccount:
    return _owned_row(account_id)[0]


def _account_response(account_id: int) -> dict:
    supplier_id = current_supplier().id
    account, retailer, circle, location = _owned_row(account_id)
    balance = totals(supplier_id, account_id=account.id)[account.id].net
    return account_json(
        account, retailer, circle, location, balance,
        last_payments(supplier_id, account.id).get(account.id), opening_balances(supplier_id, account.id).get(account.id),
    )


def _sort(accounts: list[dict]) -> list[dict]:
    """sortBy=name (default) | balance | lastPayment, sortDir=asc|desc. Ties stay A-Z (the sorts are stable).

    sortDir defaults to asc, except for balance: largest dues first, as before sortDir was added."""
    sort_by = request.args.get("sortBy")
    descending = sort_descending(default=sort_by == "balance")
    match sort_by:
        case "balance":
            accounts.sort(key=lambda a: a["balance"], reverse=descending)
        case "lastPayment":
            # By day, then that day's amount (ISO dates sort as text). Never paid goes last either way.
            paid = [a for a in accounts if a["lastPaymentDate"]]
            paid.sort(key=lambda a: (a["lastPaymentDate"], a["lastPaymentAmount"]), reverse=descending)
            accounts = paid + [a for a in accounts if not a["lastPaymentDate"]]
        case _:
            if descending:
                accounts.reverse()
    return accounts


@bp.get("/ledger/accounts")
def list_accounts():
    """Paged, with search and filters: circleId and locationId (an online retailer's own), type=online|offline,
    dues=true (balance above zero). See _sort for the order."""
    accounts = _accounts(search_term())
    for key in ("circleId", "locationId"):
        if (wanted := request.args.get(key, type=int)) is not None:
            accounts = [a for a in accounts if a[key] == wanted]
    if (kind := request.args.get("type")) in ("online", "offline"):
        accounts = [a for a in accounts if a["isOnline"] == (kind == "online")]
    if request.args.get("dues") == "true":
        accounts = [a for a in accounts if a["balance"] > 0]
    return paginate_list(_sort(accounts))


@bp.get("/ledger/accounts/all")
def all_accounts():
    """Every account, by name, for pickers."""
    return _accounts()


@bp.get("/ledger/summary")
def ledger_summary():
    """Totals across every retailer, and today's (business day) orders and collections."""
    balances = [account["balance"] for account in _accounts()]
    dues = [balance for balance in balances if balance > 0]
    today = business_today()
    day = totals(current_supplier().id, start=today, end=today + timedelta(days=1)).values()
    return {
        "date": iso_calendar_date(today),
        "accountCount": len(balances),
        "accountsWithDues": len(dues),
        "totalDue": sum(dues, ZERO),
        "todayOrders": sum((t.online_orders + t.offline_orders for t in day), ZERO),
        "todayPayments": sum((t.payments for t in day), ZERO),
    }


@bp.post("/ledger/accounts")
def create_account():
    """Adds an offline retailer (one not onboarded yet)."""
    account = LedgerAccount(supplier_id=current_supplier().id)
    _apply_account(account, parse_body(AccountRequest))
    db.session.add(account)
    db.session.commit()
    return _account_response(account.id), 201


@bp.put("/ledger/accounts/<int:account_id>")
def update_account(account_id: int):
    account = _owned_account(account_id)
    if account.retailer_id is not None:
        raise ApiError(400, "An online retailer's details come from their own profile.")
    _apply_account(account, parse_body(AccountRequest))
    db.session.commit()
    return _account_response(account.id)


@bp.post("/ledger/accounts/<int:account_id>/link")
def link_account(account_id: int):
    """An offline retailer has onboarded: their history joins their online account, so they have one balance."""
    body = parse_body(LinkRequest)
    supplier_id = current_supplier().id
    account = _owned_account(account_id)
    if account.retailer_id is not None:
        raise ApiError(400, "This retailer is already online.")
    connected = select(SupplierConnection.id).filter_by(supplier_id=supplier_id, retailer_id=body.retailer_id)
    if db.session.scalar(connected) is None:
        raise ApiError(400, "Retailer not found among your connected retailers.")
    online = db.session.scalar(select(LedgerAccount).filter_by(supplier_id=supplier_id, retailer_id=body.retailer_id))
    if online is not None:
        db.session.execute(update(LedgerEntry).where(LedgerEntry.account_id == online.id).values(account_id=account.id))
        db.session.delete(online)
        db.session.flush()  # frees the retailer id before this account takes it
    # Online accounts show the retailer's circle: the offline one carries over only if the retailer has none.
    if account.circle_id is not None:
        settings = settings_for(supplier_id, body.retailer_id)
        if settings.circle_id is None:
            settings.circle_id, settings.location_id = account.circle_id, account.location_id
        account.circle_id = account.location_id = None
    account.retailer_id = body.retailer_id
    db.session.commit()
    return _account_response(account.id)


@bp.get("/ledger/accounts/<int:account_id>/statement")
def account_statement(account_id: int):
    """Entries from..to (default: this month so far) with a running balance, starting from what was owed before."""
    supplier_id = current_supplier().id
    account = _owned_account(account_id)
    today = business_today()
    start = query_date("from") or today.replace(day=1)
    end = query_date("to") or today
    if end < start:
        raise ApiError(400, "The To date can't be before the From date.")

    # (sort key, payload builder): by day; an opening balance first in its day, then in the order recorded.
    rows = []
    entries = db.session.scalars(
        select(LedgerEntry).where(
            LedgerEntry.account_id == account.id, LedgerEntry.entry_date >= start, LedgerEntry.entry_date <= end
        )
    )
    for entry in entries:
        first = entry.entry_type == EntryType.OPENING_BALANCE
        rows.append(((entry.entry_date, not first, entry.created_at), entry_json, entry))
    if account.retailer_id is not None:
        invoices = db.session.execute(
            select(Invoice, Order.order_number)
            .join(Order, Order.id == Invoice.order_id)
            .where(
                Invoice.supplier_id == supplier_id,
                Invoice.retailer_id == account.retailer_id,
                sent_invoices(),
                Invoice.invoice_date >= day_start(start),
                Invoice.invoice_date < day_start(end + timedelta(days=1)),
            )
        )
        for invoice, order_number in invoices:
            rows.append(((business_day(invoice.invoice_date), True, invoice.invoice_date), invoice_entry_json, (invoice, order_number)))
    rows.sort(key=lambda row: row[0])

    opening = balance = totals(supplier_id, end=start, account_id=account.id)[account.id].net
    debits = credits = ZERO
    items = []
    for _, build, source in rows:
        item = build(*source) if isinstance(source, tuple) else build(source)
        if not item["isVoided"]:
            debits += item["debit"]
            credits += item["credit"]
            balance += item["debit"] - item["credit"]
            item["balance"] = balance
        items.append(item)
    return {
        "account": _account_response(account.id),
        "from": iso_calendar_date(start),
        "to": iso_calendar_date(end),
        "openingBalance": opening,
        "totalDebit": debits,
        "totalCredit": credits,
        "closingBalance": balance,
        "entries": items,
    }


@bp.post("/ledger/accounts/<int:account_id>/entries")
def add_entry(account_id: int):
    body = parse_body(EntryRequest)
    account = _owned_account(account_id)
    amount = _checked_amount(body.amount)
    _check_not_future(body.entry_date)
    if body.entry_type == EntryType.OPENING_BALANCE:
        existing = select(LedgerEntry.id).filter_by(account_id=account.id, entry_type=EntryType.OPENING_BALANCE, voided_at=None)
        if db.session.scalar(existing) is not None:
            raise ApiError(400, "This retailer already has an opening balance. Void it to enter a different one.")
    payment = body.entry_type == EntryType.PAYMENT
    entry = LedgerEntry(
        account_id=account.id,
        entry_type=body.entry_type,
        entry_date=body.entry_date,
        amount=amount,
        reference=body.reference,
        payment_mode=body.payment_mode if payment else None,
        collected_by=body.collected_by if payment else None,
        notes=body.notes,
    )
    db.session.add(entry)
    db.session.commit()
    return entry_json(entry), 201


@bp.post("/ledger/entries/<int:entry_id>/void")
def void_entry(entry_id: int):
    """A wrong entry stays visible with the reason, but no longer counts."""
    body = parse_body(VoidRequest)
    entry = _owned_entry(entry_id)
    if entry.voided_at is not None:
        raise ApiError(400, "This entry is already voided.")
    entry.voided_at = utcnow()
    entry.void_reason = body.reason
    db.session.commit()
    return entry_json(entry)


@bp.get("/ledger/accounts/<int:account_id>/payments")
def account_payments(account_id: int):
    """The retailer's latest payments that count (limit, default 10, at most 50), newest first, and how many there are.
    The first is their last payment, the only one that can be edited (canEdit)."""
    account = _owned_account(account_id)
    limit = min(max(request.args.get("limit", 10, type=int), 1), 50)
    payments = _counted_payments(account.id)
    total = db.session.scalar(select(func.count()).select_from(payments.subquery()))
    items = []
    for index, entry in enumerate(db.session.scalars(payments.order_by(*LATEST_PAYMENT_FIRST).limit(limit))):
        item = entry_json(entry)
        item["canEdit"] = index == 0
        item["recordedAt"] = iso_timestamp(entry.created_at)
        items.append(item)
    return {"payments": items, "totalCount": total}


@bp.put("/ledger/entries/<int:entry_id>")
def update_payment(entry_id: int):
    """Corrects a retailer's last payment (any other entry is voided instead). Same rules as recording one; the
    balance, Last Payment and today's collections follow from the entry."""
    body = parse_body(PaymentUpdateRequest)
    entry = _owned_entry(entry_id, lock=True)
    if entry.entry_type != EntryType.PAYMENT:
        raise ApiError(400, "Only payments can be edited.")
    last = db.session.scalar(_counted_payments(entry.account_id).order_by(*LATEST_PAYMENT_FIRST).limit(1))
    if entry.voided_at is not None or last is None or last.id != entry.id:
        raise ApiError(400, "Only the last payment can be edited.")
    entry.amount = _checked_amount(body.amount)
    _check_not_future(body.entry_date)
    entry.entry_date = body.entry_date
    entry.payment_mode = body.payment_mode
    entry.reference = body.reference
    entry.collected_by = body.collected_by
    entry.notes = body.notes
    db.session.commit()
    return entry_json(entry)


# Newest first: by business day, then the later recorded (id breaks ties within the same instant).
LATEST_PAYMENT_FIRST = (LedgerEntry.entry_date.desc(), LedgerEntry.created_at.desc(), LedgerEntry.id.desc())


def _counted_payments(account_id: int):
    """SELECT of an account's payments that count (not voided)."""
    return select(LedgerEntry).where(
        LedgerEntry.account_id == account_id, LedgerEntry.entry_type == EntryType.PAYMENT, LedgerEntry.voided_at.is_(None)
    )


def _owned_entry(entry_id: int, *, lock: bool = False) -> LedgerEntry:
    query = (
        select(LedgerEntry)
        .join(LedgerEntry.account)
        .where(LedgerEntry.id == entry_id, LedgerAccount.supplier_id == current_supplier().id)
    )
    entry = db.session.scalar(query.with_for_update(of=LedgerEntry) if lock else query)
    if entry is None:
        raise not_found()
    return entry


def _checked_amount(amount: Decimal) -> Decimal:
    amount = amount.quantize(MONEY, rounding=ROUND_HALF_UP)
    if amount <= 0:
        raise ApiError(400, "Amount must be greater than zero.")
    return amount


def _check_not_future(day) -> None:
    if day > business_today():
        raise ApiError(400, "The date can't be in the future.")


@bp.get("/ledger/daybook")
def day_book():
    """One business day (default today), per retailer: owed at the start, orders and payments that day, owed at the end.

    Lists retailers who owe something (or are in advance) or had activity that day. An opening balance dated
    that day counts as owed at the start: it is what the paper ledger carried over.
    """
    supplier_id = current_supplier().id
    day = query_date("date") or business_today()
    ensure_online_accounts(supplier_id)
    before = totals(supplier_id, end=day)
    during = totals(supplier_id, start=day, end=day + timedelta(days=1))

    rows = []
    for account, retailer, circle, location in db.session.execute(_account_rows(supplier_id)):
        that_day = during[account.id]
        owed_at_start = before[account.id].net + that_day.opening
        if not (owed_at_start or that_day.online_orders or that_day.offline_orders or that_day.payments):
            continue
        rows.append({
            "accountId": account.id,
            **{key: value for key, value in account_json(account, retailer, circle, location, ZERO).items() if key in DAY_BOOK_ACCOUNT_KEYS},
            **day_book_amounts(owed_at_start, that_day),
        })
    rows.sort(key=lambda row: (row["name"].lower(), row["accountId"]))
    columns = ("openingBalance", "onlineOrders", "offlineOrders", "payments", "closingBalance")
    return {
        "date": iso_calendar_date(day),
        "rows": rows,
        "totals": {column: sum((row[column] for row in rows), ZERO) for column in columns},
    }


def _apply_account(account: LedgerAccount, body: AccountRequest) -> None:
    clash = select(LedgerAccount.id).where(
        LedgerAccount.supplier_id == account.supplier_id,
        LedgerAccount.retailer_id.is_(None),
        func.lower(LedgerAccount.name) == body.name.lower(),
    )
    if account.id is not None:
        clash = clash.where(LedgerAccount.id != account.id)
    if db.session.scalar(clash) is not None:
        raise ApiError(409, "An offline retailer with this name already exists.")
    account.name = body.name
    account.contact_person = body.contact_person
    account.phone = body.phone
    account.address = body.address
    account.notes = body.notes
    account.circle_id, account.location_id = checked_area(account.supplier_id, body.circle_id, body.location_id)
