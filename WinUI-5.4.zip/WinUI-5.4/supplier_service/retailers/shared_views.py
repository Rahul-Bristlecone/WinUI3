"""The two views the retailer service reads, and what that service may do with supplier tables.

The retailer service (retailer_portal_winui/retailer-service) sees suppliers and products only through these views. A
view runs with its owner's rights, so they must be created by the owner of the supplier tables, which is this
service's migration login. The retailer service's own login can't read those tables, and mustn't be able to.

Its sql/02_supplier_access.sql holds the same statements, and its tests build the views from that script. Keep the two
identical: tests/unit/test_shared_views.py compares them when both repositories are checked out side by side.

migrations/env.py calls refresh_shared_views() at the end of every `flask db upgrade` that leaves a PostgreSQL
database at the newest revision, so a new database needs no separate step:
- public.retailer_supplier_directory reads only supplier.suppliers, so it is always created or replaced.
- public.retailer_products also reads retailer.supplier_connections. Until the retailer service's migration has
  created that table the view is skipped, with a warning, and the next `flask db upgrade` creates it.
- The grants go to retailer_svc once that login exists (the retailer service's sql/01_retailer_schema.sql creates it).

CREATE OR REPLACE VIEW can only add columns at the end. To rename, remove or reorder a column, add a migration that
drops the view; the refresh at the end of the upgrade then creates it again.
"""

import logging
from collections.abc import Sequence

from sqlalchemy import Connection, text

RETAILER_ROLE = "retailer_svc"

# Suppliers a retailer can connect to by code, with what a tax invoice prints for the supplier (address and GSTIN).
SUPPLIER_DIRECTORY = """
CREATE OR REPLACE VIEW public.retailer_supplier_directory AS
SELECT s.id           AS supplier_id,
       s.supplier_code AS supplier_code,
       s.company_name AS supplier_name,
       s.email        AS contact_email,
       s.phone        AS contact_phone,
       s.city         AS city,
       s.is_active    AS is_active,
       s.address      AS address,
       s.state        AS state,
       s.postal_code  AS postal_code,
       s.country      AS country,
       s.gst_number   AS gst_number
FROM supplier.suppliers s
"""

# Products as one retailer sees them: one row per (retailer, product) for each supplier the retailer is connected to.
# The price is today's in the retailer's price group, or in the supplier's Standard group when none is assigned
# (pricing/service.py:retailer_price applies the same rule). No current price there means a NULL price. Stock is the
# available quantity, 0 without an inventory row. is_active is false unless the connection's status is Active.
RETAILER_PRODUCTS = """
CREATE OR REPLACE VIEW public.retailer_products AS
SELECT sc.retailer_id    AS retailer_id,
       p.id              AS product_id,
       p.supplier_id     AS supplier_id,
       p.product_code    AS product_code,
       p.product_name    AS product_name,
       p.description     AS description,
       c.category_name   AS category_name,
       p.unit_of_measure AS unit_of_measure,
       pp.unit_price     AS price,
       COALESCE(i.available_quantity, 0) AS available_qty,
       p.image_filename  AS image_filename,
       (p.is_active AND COALESCE(c.is_active, TRUE) AND sc.status = 'Active') AS is_active
FROM retailer.supplier_connections sc
JOIN supplier.products p ON p.supplier_id = sc.supplier_id
LEFT JOIN supplier.retailer_price_groups rpg
       ON rpg.supplier_id = sc.supplier_id AND rpg.retailer_id = sc.retailer_id
LEFT JOIN supplier.categories c ON c.id = p.category_id
LEFT JOIN supplier.inventory i ON i.product_id = p.id
LEFT JOIN supplier.product_prices pp
       ON pp.price_group_id = COALESCE(
              rpg.price_group_id,
              (SELECT g.id FROM supplier.price_groups g
               WHERE g.supplier_id = sc.supplier_id AND g.is_default LIMIT 1))
      AND pp.product_id = p.id
      AND pp.effective_from <= (now() AT TIME ZONE 'UTC')
      AND (pp.effective_to IS NULL OR pp.effective_to >= date_trunc('day', (now() AT TIME ZONE 'UTC')))
"""

# Besides reading the views: the retailer service places orders, cancels pending ones, and accepts sent invoices.
GRANTS = (
    "GRANT USAGE ON SCHEMA public, supplier TO retailer_svc",
    "GRANT SELECT, INSERT ON supplier.orders, supplier.order_items TO retailer_svc",
    "GRANT UPDATE (status, updated_at) ON supplier.orders TO retailer_svc",
    "GRANT USAGE ON SEQUENCE supplier.orders_id_seq, supplier.order_items_id_seq TO retailer_svc",
    "GRANT SELECT ON supplier.invoices, supplier.invoice_lines TO retailer_svc",
    "GRANT UPDATE (status, updated_at) ON supplier.invoices TO retailer_svc",
)


def should_refresh(dialect: str, revision_argument: str | None, current_heads: Sequence[str],
                   newest_heads: Sequence[str]) -> bool:
    """True when an Alembic command has just left a PostgreSQL database at the newest revision.

    revision_argument is None for commands that don't move the database (current, check, revision --autogenerate).
    A downgrade, or an upgrade to an older revision, doesn't end at the newest heads, and older schemas may lack
    what the views read.
    """
    return dialect == "postgresql" and revision_argument is not None and set(current_heads) == set(newest_heads)


def refresh_shared_views(connection: Connection) -> list[tuple[int, str]]:
    """Creates or replaces the views, and grants the retailer service its access. PostgreSQL only; doesn't commit.

    Returns (logging level, message) pairs describing what it did, for the upgrade's output.
    """
    log: list[tuple[int, str]] = []
    connection.exec_driver_sql(SUPPLIER_DIRECTORY)
    views = ["public.retailer_supplier_directory"]

    if connection.scalar(text("SELECT to_regclass('retailer.supplier_connections')")) is None:
        log.append((logging.WARNING, (
            "Skipped view public.retailer_products: retailer.supplier_connections doesn't exist yet. "
            "Run the retailer service's migration (flask --app wsgi db upgrade), then `flask db upgrade` here again."
        )))
    else:
        connection.exec_driver_sql(RETAILER_PRODUCTS)
        views.append("public.retailer_products")
    log.insert(0, (logging.INFO, f"Created or updated view(s): {', '.join(views)}."))

    if connection.scalar(text("SELECT 1 FROM pg_roles WHERE rolname = :role"), {"role": RETAILER_ROLE}) is None:
        log.append((logging.INFO, (
            f"No {RETAILER_ROLE} login, so no grants (fine when both services use the same login). The retailer "
            f"service's sql/01_retailer_schema.sql creates it; the next `flask db upgrade` then grants its access."
        )))
    else:
        connection.exec_driver_sql(f"GRANT SELECT ON {', '.join(views)} TO {RETAILER_ROLE}")
        for grant in GRANTS:
            connection.exec_driver_sql(grant)
        log.append((logging.INFO, f"Granted {RETAILER_ROLE} its access to the views, orders and invoices."))
    return log
