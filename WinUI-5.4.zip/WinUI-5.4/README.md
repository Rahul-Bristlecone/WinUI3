# supplier-service

Python / Flask / PostgreSQL backend for the Supplier Portal desktop client (`../SupplierPortal`).
It implements the REST contract the client's mock (`SupplierPortal/Services/Mock`) serves today:
camelCase JSON, enums as strings, paged lists as `{ items, totalCount, page, pageSize }`, errors as `{ message }`.

More documentation: [README.PRODUCTION.md](README.PRODUCTION.md) (deploying and running it in production) ·
[README.EXPLAINED.md](README.EXPLAINED.md) (what it does, in plain words) ·
[ARCHITECTURE.md](ARCHITECTURE.md) (how it is built, with diagrams of each flow).

## Run locally

Needs Python 3.11+ and PostgreSQL. For example, with Docker:

```powershell
docker run --name supplier-pg -d -p 5432:5432 `
  -e POSTGRES_USER=supplier -e POSTGRES_PASSWORD=supplier -e POSTGRES_DB=supplier_service postgres:17
```

Then:

```powershell
cd supplier-service
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -e ".[dev]"

copy .env.example .env      # set JWT_SECRET_KEY (and DATABASE_URL if it differs)
flask db upgrade            # creates the `supplier` schema, its tables, and the views the retailer service reads
flask seed-demo             # optional: demo@supplier.com / Password@123, plus 14 demo retailers in the retailer schema
python run.py               # http://127.0.0.1:5000 (or: flask run --port 5000)
```

`run.py` reads `HOST`, `PORT` and `FLASK_DEBUG=1` (auto-reload and debugger) from the environment or `.env`.

Point the client at it:

```powershell
$env:SUPPLIER_PORTAL_API_URL = "http://localhost:5000/"
cd ..\SupplierPortal; dotnet run -p:Platform=x64
```

For a production server, install one and serve `wsgi:app`: `pip install waitress` then `waitress-serve --port 5000 wsgi:app` on Windows, or `gunicorn wsgi:app` on Linux.
`GET /health` checks the database connection.

## Tests

```powershell
pytest                                   # SQLite in memory
$env:TEST_DATABASE_URL = "postgresql://supplier:supplier@localhost:5432/supplier_service_test"
pytest                                   # against a real Postgres database; it must be EMPTY (pytest refuses otherwise,
                                         # because the tests create and drop every table, including the retailer schema)
```

## Layout

```
supplier_service/
  __init__.py      create_app(): config, extensions, blueprints, `flask seed-demo`
  config.py        environment variables (see .env.example)
  common/          BaseModel, errors, JWT auth, request parsing/paging, JSON provider
  extensions/      db (Flask-SQLAlchemy; default schema `supplier`) + migrate (Flask-Migrate)
  auth/            Supplier, SupplierSession; login, refresh, logout, register, change password, profile;
                   sessions.py = sign-in sessions and refresh tokens
  catalogue/       Category, Product; product images (images.py) served from /media
  inventory/       Inventory, InventoryTransaction; service.py = every stock movement
  pricing/         PriceGroup, ProductPrice
  retailers/       Retailer, SupplierConnection, InvoiceAcceptance (the retailer service's tables, read here) + RetailerPriceGroup
  orders/          Order, OrderItem; service.py = create / reject
  invoices/        Invoice, InvoiceLine; service.py = draft / send
  dashboard/       KPI summary
  seed.py          demo data (a port of MockDatabase.cs)
migrations/        Alembic (flask db ...)
```

Each module's `routes.py` holds its endpoints. `schemas.py`, where present, holds the request models (pydantic) and the response serializers.

## Endpoints

All endpoints except login, register, refresh, logout, `/media` and `/health` need `Authorization: Bearer <token>`. Every query is scoped to the signed-in supplier, and another supplier's ids return 404.

| Area | Endpoints |
|---|---|
| Auth | `POST api/auth/login`, `POST api/auth/refresh` and `POST api/auth/logout` (both `{ refreshToken }`), `POST api/auth/register`, `POST api/auth/change-password`, `GET/PUT api/supplier/profile` |
| Dashboard | `GET api/dashboard` |
| Categories | `GET api/categories?search&page&pageSize`, `GET api/categories/all`, `POST`, `PUT {id}`, `POST {id}/deactivate` |
| Products | `GET api/products?search&categoryId&status&sortBy&sortDir&page&pageSize`, `POST`, `PUT {id}`, `POST {id}/deactivate`, `POST {id}/image` (multipart `file`), `DELETE {id}/image` |
| Inventory | `GET api/inventory`, `GET api/inventory/summary`, `POST api/inventory/{productId}/adjust`, `GET api/inventory/{productId}/history` |
| Pricing | `GET/POST api/pricegroups` (Standard first; it can't be deactivated), `PUT {id}`, `POST {id}/deactivate`, `GET api/pricegroups/matrix?search&page&pageSize` (active products × every group's price), `GET {id}/prices`, `PUT {id}/prices/{productId}` (`effectiveFrom` defaults to today), `DELETE {id}/prices/{productId}` |
| Retailers | `GET api/retailers`, `PUT {id}/price-group`, `PUT {id}/gst` (`{ gstApplicable }`; off = new invoices without GST), `POST {id}/block`, `POST {id}/activate` |
| Orders | `GET api/orders?search&status&sortBy&sortDir`, `GET {id}`, `POST {id}/reject`, `PUT {id}/invoiced-quantities` |
| Invoices | `GET api/invoices`, `GET {id}`, `POST api/invoices` |
| Media | `GET media/products/{file}` (public, cacheable) |

## Database schemas

| Schema | Owner | Contents |
|---|---|---|
| `supplier` | this service | all tables (`suppliers`, `products`, `orders`, `invoices`, ...) and `alembic_version` |
| `retailer` | retailer service | `retailers`, `supplier_connections`, `invoice_acceptances`, ... (mapped here, never migrated) |
| `public` | shared | the views the retailer side reads: `retailer_products`, `retailer_supplier_directory`. Created and refreshed at the end of every `flask db upgrade` on PostgreSQL (`retailers/shared_views.py`); `retailer_products` once `retailer.supplier_connections` exists |

Migration 0003 moved the tables from `public` into `supplier` (`ALTER TABLE ... SET SCHEMA`: data, keys, indexes and sequences are kept). Things to know:
- **Other readers/writers must use the new names.** Anything that queries these tables unqualified (for example `INSERT INTO orders`) must use `supplier.orders`, or have `supplier` on its `search_path`. The `public` views keep working because Postgres views refer to tables by id.
- **Access is carried over.** 0003 grants `USAGE` on the `supplier` schema to every role that already had privileges on the moved tables (table privileges themselves are unchanged).
- **The Alembic version table** lives in `supplier.alembic_version`. `migrations/env.py` moves an existing `public.alembic_version` there on the first run.
- Test databases: the suite creates all three schemas itself (SQLite attaches them in memory).

## Design notes

**Sign-in and refresh tokens.** Login and refresh both return `{ token, expiresAt, refreshToken, refreshTokenExpiresAt, supplier }`. `token` is the access token, a JWT that lasts `JWT_ACCESS_EXPIRES_MINUTES` (default 15). When it expires, `POST api/auth/refresh` with `{ refreshToken }` returns a new pair. `auth/sessions.py` has the details.
- *Sessions.* Each sign-in is a row in `supplier_sessions`. A session lasts while it is refreshed at least every `REFRESH_TOKEN_IDLE_DAYS` (default 7), and at most `REFRESH_TOKEN_MAX_DAYS` (default 30) after sign-in. After that, the user signs in again. Signing in also deletes the supplier's sessions that have ended.
- *Rotation and reuse.* Every refresh returns a new refresh token, and the old one stops working. If a replaced token is presented again, the service treats it as copied and revokes the session, so both holders are signed out. The exception is within 30 seconds of the rotation: there the old token gets the same new token back, so two requests that refresh at once both succeed. Clients should still refresh one request at a time.
- *Nothing secret is stored.* A refresh token is `<session id>.<generation>.<HMAC>`, signed with `JWT_SECRET_KEY`, and the row records only the current generation. Changing `JWT_SECRET_KEY` signs everyone out.
- *Ending sessions.* `POST api/auth/logout` ends the token's session. It answers 204 even when the session had already ended, and it needs no access token. Changing the password ends the supplier's other sessions. A refresh token that can't be used gets a 401 with the usual "session has expired" message.
- *Access tokens are not checked against the session.* After logout, revocation or a password change, an access token that was already issued keeps working until it expires. That is why its lifetime should be short.
- *The desktop client doesn't refresh yet.* It signs the user out when the access token expires. Until it uses refresh tokens, keep `JWT_EXPIRES_HOURS` set (see `.env.example`), which the service still honours when `JWT_ACCESS_EXPIRES_MINUTES` is unset. The new response fields are additive, so the client's `LoginResponse` is unaffected.

**Retailers.** Retailers live in the retailer service's `retailer` schema (same database). This service maps `retailer.retailers`, `retailer.supplier_connections` and `retailer.invoice_acceptances`, and its migrations never create, alter or drop that schema.
- *Who is a retailer of this supplier:* the rows in `supplier_connections` for the signed-in supplier. A retailer's API `id` is `retailers.id`, the same id `orders.retailer_id` carries. Name, contact details and GSTIN on orders and invoices are read live from `retailer.retailers`.
- *Block / activate* writes `supplier_connections.status` (`Blocked` / `Active`). Any status other than `Blocked` is shown as Active, so connection states other than these two are not visible in the portal.
- *Price groups* are the supplier's own, and `supplier_connections` has no column for them, so the assignment lives in this service's `retailer_price_groups` table. A retailer with no assignment is in the supplier's default group (the first-created active one); its pricing and group counts treat it that way.
- *Invoices with a `retailer.invoice_acceptances` row* are reported with status `Accepted`.
- *`public.retailer_products` view* (how the retailer side reads the catalogue, prices and stock) is defined over `retailer.supplier_connections` and `retailer_price_groups`. Migration 0002 repointed it from the old `retailer_connections` table, keeping its columns; it shows products only for connections whose status is exactly `Active`. Don't drop or rename tables that views depend on without updating the view in the same migration.
- *Both views are created by this service.* `migrations/env.py` runs `retailers/shared_views.py` at the end of every `flask db upgrade` that reaches the newest revision: it creates or replaces both views and grants the retailer service's `retailer_svc` login its access. It runs after the migrations, in its own transaction, and also when nothing was pending. The retailer service's `sql/02_supplier_access.sql` holds the same statements; `tests/unit/test_shared_views.py` checks they match.

**Status names.** The database stores the schema's values (`OrderStatus`, `InvoiceStatus`). The API translates them into the client's enums:

| Database | API (client enum) |
|---|---|
| `Pending` | `Pending` |
| `Supplier Reject` | `SupplierRejected` |
| `Invoice Sent` | `Invoiced` |
| `In-Transit` | `InTransit` |
| `Fulfilled` (retailer accepted the invoice) | `Fulfilled` |
| `Cancelled` | `Cancelled` |
| invoice `Invoice Sent` | `Sent` |
| invoice has a retailer acceptance | `Accepted` |
| invoice `Rejected` | unchanged (not in the client enum yet) |

Order status changes are checked against `OrderStatus.ALLOWED_TRANSITIONS`.

**Edit Order is a draft invoice.** `order_items` has no invoiced-quantity column. So `PUT api/orders/{id}/invoiced-quantities` saves the planned quantities as an invoice with status `Draft` and number `DRAFT-{orderId}`. `POST api/invoices` then turns that draft into the sent invoice and gives it a real number. Drafts never show up in invoice lists, in invoice counts, or in `GET api/invoices/{id}`. Rejecting the order deletes its draft. Invoice lines are matched to order items by product, so an order should list each product only once.

**Stock.**
- A new order reserves its quantities.
- Rejecting the order or sending its invoice releases the reservation.
- Sending the invoice also removes the invoiced quantities from on-hand stock.
- Manual adjustments can't remove reserved stock.

Every on-hand change goes through `inventory/service.py:record_movement`, so the transaction log always adds up to `on_hand_quantity`. History computes "balance after" from that log. Stock is stored as whole numbers, so quantities like `2.5` are rejected (the client form accepts decimals). Writes that change stock lock the affected rows (`SELECT … FOR UPDATE`).

**Invoices.**
- Numbers are `INV-{supplierId:0000}-{yyyymm}-{seq:0000}`. The supplier id is included because `invoice_number` is unique across all suppliers.
- GST is applied at `GST_RATE` (default 18%).
- Invoices don't store their tax rate. `taxRate` is the configured rate whenever that rate explains the stored tax amount; otherwise it is derived from the stored amounts.

**Supplier codes.** `Supplier.generate_supplier_code()` produces one code per company prefix per day, for example `GDP-ACME-20261103`. Registration adds `-2`, `-3`, … to same-day repeats, which would otherwise break the unique constraint.

**Product images.** PNG or JPEG, up to 2 MB, decoded on upload (a file with a PNG/JPEG header that isn't a real, complete image is rejected, as is anything over 25 megapixels). Each upload is kept twice, under new names every time: the original (`imageUrl`) and a 256 px JPEG thumbnail (`thumbnailUrl`, also drops photo metadata such as GPS). The client's product grid and edit dialog show the thumbnail, so a list of products no longer downloads full-size photos. `products.image_filename` records the original's name; the thumbnail's name is derived from it. Images uploaded before thumbnails existed get theirs the first time it is requested. URLs are absolute (the request host, or `PUBLIC_BASE_URL` behind a proxy). The media route is public because the client's `Image` control loads URLs without a token, and files are served with a one-year cache header.

File access goes through `catalogue/storage.py` (`ImageStorage`, selected by `IMAGE_STORAGE`, only `local` so far). Before production, add an Azure Blob / S3 backend there with a CDN in front: nothing else changes (database column, API responses, client).

**Inventory valuation.** `GET api/inventory/summary` values stock at the current price in the supplier's first-created price group.

## Not implemented

- **Order intake.** Retailers place orders through another system. `orders/service.py:create_order` is the entry point an intake consumer would call (the seed uses it), but there is no endpoint for it.
- **Session management.** There's no endpoint to list sessions or end one from another device. A password change ends the others, and an access token stays valid until it expires (see *Sign-in and refresh tokens*).
- **Rate limiting** on login.
