"""supplier_service/retailers/shared_views.py: the views the retailer service reads, refreshed by `flask db upgrade`."""

import os
import re
from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import text

from supplier_service.extensions.database import db
from supplier_service.retailers.shared_views import (
    GRANTS,
    RETAILER_PRODUCTS,
    SUPPLIER_DIRECTORY,
    refresh_shared_views,
    should_refresh,
)

from .factories import make_product, make_retailer, set_price, standard_group

# The retailer service's copy of these statements; both repositories normally sit side by side under one folder.
RETAILER_SCRIPT = Path(os.environ.get(
    "RETAILER_SERVICE_DIR", Path(__file__).resolve().parents[4] / "retailer_portal_winui" / "retailer-service"
)) / "sql" / "02_supplier_access.sql"


# -- when migrations/env.py refreshes the views ----------------------------------------------------


@pytest.mark.parametrize(
    "dialect, revision_argument, current, newest, expected",
    [
        pytest.param("postgresql", "0013", ["0013"], ["0013"], True, id="upgrade reaching the newest revision"),
        pytest.param("postgresql", "head", ["0013"], ["0013"], True, id="stamp head"),
        pytest.param("postgresql", "0013", ["b", "a"], ["a", "b"], True, id="several heads, any order"),
        pytest.param("postgresql", None, ["0013"], ["0013"], False, id="current or check: nothing moved"),
        pytest.param("postgresql", "0012", ["0012"], ["0013"], False, id="downgrade or older target"),
        pytest.param("sqlite", "0013", ["0013"], ["0013"], False, id="not PostgreSQL"),
    ],
)
def test_views_are_refreshed_only_after_reaching_the_newest_revision_on_postgresql(
    dialect, revision_argument, current, newest, expected
):
    assert should_refresh(dialect, revision_argument, current, newest) is expected


# -- the same statements as the retailer service's script ------------------------------------------


def statements(sql: str) -> list[str]:
    """The SQL statements in a script, comments removed and whitespace collapsed."""
    sql = re.sub(r"--[^\n]*", "", sql)
    return [" ".join(part.split()) for part in sql.split(";") if part.strip()]


@pytest.fixture
def retailer_script() -> list[str]:
    if not RETAILER_SCRIPT.is_file():
        pytest.skip(f"The retailer service isn't checked out at {RETAILER_SCRIPT.parents[1]} (set RETAILER_SERVICE_DIR)")
    return statements(RETAILER_SCRIPT.read_text(encoding="utf-8"))


def test_the_views_match_the_retailer_services_script(retailer_script):
    views = [s for s in retailer_script if s.startswith("CREATE OR REPLACE VIEW")]
    assert views == statements(SUPPLIER_DIRECTORY) + statements(RETAILER_PRODUCTS)


def test_the_grants_match_the_retailer_services_script(retailer_script):
    view_grant = "GRANT SELECT ON public.retailer_supplier_directory, public.retailer_products TO retailer_svc"
    assert {s for s in retailer_script if s.startswith("GRANT")} == {*GRANTS, view_grant}


# -- on PostgreSQL ---------------------------------------------------------------------------------


def test_the_views_show_what_a_retailer_sees_on_postgresql(app, supplier):
    if db.engine.dialect.name != "postgresql":
        pytest.skip("PostgreSQL only: set TEST_DATABASE_URL to an empty PostgreSQL database")
    make_retailer(supplier)
    cola = make_product(supplier, "COLA", stock=40)
    set_price(standard_group(supplier), cola, "12.50")
    expected_directory = [(supplier.supplier_code, supplier.company_name, True)]

    connection = db.session.connection()
    try:
        refresh_shared_views(connection)
        directory = connection.execute(text(
            "SELECT supplier_code, supplier_name, is_active FROM public.retailer_supplier_directory"
        )).all()
        products = connection.execute(text(
            "SELECT retailer_id, product_code, price, available_qty, is_active FROM public.retailer_products"
        )).all()
    finally:
        db.session.rollback()  # DDL is transactional here: the views go too, so the tables can be dropped after

    assert directory == expected_directory
    assert products == [(1, "COLA", Decimal("12.50"), 40, True)]
