import logging
from logging.config import fileConfig

from flask import current_app

from alembic import context
from alembic.script import ScriptDirectory
from sqlalchemy import text

from supplier_service.extensions.database import SERVICE_SCHEMA
from supplier_service.retailers.shared_views import refresh_shared_views, should_refresh

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
fileConfig(config.config_file_name)
logger = logging.getLogger('alembic.env')


def get_engine():
    try:
        # this works with Flask-SQLAlchemy<3 and Alchemical
        return current_app.extensions['migrate'].db.get_engine()
    except (TypeError, AttributeError):
        # this works with Flask-SQLAlchemy>=3
        return current_app.extensions['migrate'].db.engine


def get_engine_url():
    try:
        return get_engine().url.render_as_string(hide_password=False).replace(
            '%', '%%')
    except AttributeError:
        return str(get_engine().url).replace('%', '%%')


# add your model's MetaData object here
# for 'autogenerate' support
# from myapp import mymodel
# target_metadata = mymodel.Base.metadata
config.set_main_option('sqlalchemy.url', get_engine_url())
target_db = current_app.extensions['migrate'].db

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def get_metadata():
    if hasattr(target_db, 'metadatas'):
        return target_db.metadatas[None]
    return target_db.metadata


def run_migrations_offline():
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url, target_metadata=get_metadata(), literal_binds=True,
        **current_app.extensions['migrate'].configure_args
    )

    with context.begin_transaction():
        context.run_migrations()


def prepare_service_schema(connection):
    """PostgreSQL: create the service schema, and bring the Alembic version table into it.

    Alembic keeps its version table in the service schema. Databases migrated before that schema
    existed have it in public, so move it once (only if it is ours: it records revision 0001/0002).
    """
    if connection.dialect.name != "postgresql":
        return
    connection.execute(text(f"CREATE SCHEMA IF NOT EXISTS {SERVICE_SCHEMA}"))
    # Nested IFs: PL/pgSQL plans a whole condition at once, so the SELECT would fail on a missing
    # public.alembic_version even behind the to_regclass check. The inner IF is only planned once reached.
    connection.execute(text(f"""
        DO $$ BEGIN
            IF to_regclass('public.alembic_version') IS NOT NULL
               AND to_regclass('{SERVICE_SCHEMA}.alembic_version') IS NULL THEN
                IF EXISTS (SELECT 1 FROM public.alembic_version WHERE version_num IN ('0001', '0002')) THEN
                    ALTER TABLE public.alembic_version SET SCHEMA {SERVICE_SCHEMA};
                END IF;
            END IF;
        END $$
    """))
    connection.commit()


def run_migrations_online():
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """

    # this callback is used to prevent an auto-migration from being generated
    # when there are no changes to the schema
    # reference: http://alembic.zzzcomputing.com/en/latest/cookbook.html
    def process_revision_directives(context, revision, directives):
        if getattr(config.cmd_opts, 'autogenerate', False):
            script = directives[0]
            if script.upgrade_ops.is_empty():
                directives[:] = []
                logger.info('No changes in schema detected.')

    conf_args = current_app.extensions['migrate'].configure_args
    if conf_args.get("process_revision_directives") is None:
        conf_args["process_revision_directives"] = process_revision_directives

    connectable = get_engine()

    with connectable.connect() as connection:
        prepare_service_schema(connection)
        context.configure(
            connection=connection,
            target_metadata=get_metadata(),
            **conf_args
        )

        with context.begin_transaction():
            context.run_migrations()

        refresh_views_at_newest_revision(connection)


def refresh_views_at_newest_revision(connection):
    """After `flask db upgrade` reaches the newest revision on PostgreSQL: create or update the views the retailer
    service reads, and its grants (supplier_service/retailers/shared_views.py).

    This runs on every such upgrade, not once as a numbered migration, so it doesn't matter which service migrated
    first: if the retailer service's tables appear later, the next `flask db upgrade` creates the view that needs them.
    It runs after the migrations have committed, in its own transaction, so a failure here never undoes a migration.
    `--sql` (offline) runs don't reach it: there, run the retailer service's sql/02_supplier_access.sql.
    """
    try:
        revision_argument = context.get_revision_argument()
    except KeyError:  # current, check, revision --autogenerate: commands that don't move the database
        revision_argument = None
    newest = ScriptDirectory.from_config(config).get_heads()
    current = context.get_context().get_current_heads()
    if not should_refresh(connection.dialect.name, revision_argument, current, newest):
        connection.rollback()  # only the version check ran
        return
    try:
        for level, message in refresh_shared_views(connection):
            logger.log(level, message)
        connection.commit()
    except Exception:
        connection.rollback()
        logger.error(
            "The migrations are applied, but the views the retailer service reads couldn't be created or updated "
            "(error below). Fix the cause, then run `flask db upgrade` again: it retries."
        )
        raise


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
