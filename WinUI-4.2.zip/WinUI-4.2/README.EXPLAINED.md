# The Supplier Service, in Plain Words

A non-technical tour of what this part of the project does, how a normal day flows through it, and what still
needs deciding. Technical words are explained the first time they appear, and collected in a glossary at the end.

---

## What is it?

The **Supplier Portal app** on a supplier's computer is the *shop counter*: the screens and buttons. The **supplier
service** (this folder) is the *back office* behind it. Every time someone clicks Save, Send or Search in the app,
the app sends a request over the internet to this service. The service checks the request is allowed, applies the
business rules, saves the result in the database, and sends back an answer.

The app never touches the database itself. All the rules (stock can't go below zero, a bill gets the next number,
GST is added) live here, in one place.

```
   Supplier (you)                                   Shop owner (retailer)
        │ uses                                             │ uses
        ▼                                                  ▼
  Supplier Portal app                                Retailer app
        │ sends requests over the internet                 │
        ▼                                                  ▼
  SUPPLIER SERVICE  ◄──────  one shared database  ──────►  RETAILER SERVICE
  (this project)           (an organised filing cabinet)    (a separate system)
```

---

## What it keeps track of

| In the app | What it means in everyday terms |
|---|---|
| **Catalogue** | Your list of products, sorted into categories (Beverages → Soft Drinks), each with a code, a unit (Bottle, Pack) and an optional photo. |
| **Stock** | For each product: how many are **on the shelf**, how many are **set aside** for orders not yet billed, and how many are **free to sell** (shelf minus set aside). |
| **Price groups** | Different price lists for different kinds of shops. Everyone starts in **Standard**; you might add "Gold" with lower prices for big buyers. |
| **Retailers** | The shops connected to you. You can put each in a price group, turn GST off for them, give them a sales area, or block them. |
| **Orders** | What a shop asked for. |
| **Invoices** | The bill you send for an order. |
| **Ledger** | Your *khata*: how much each shop owes you, and every order and payment behind that number. |
| **Circles** | Your sales areas, e.g. the circle "North Delhi" with the locations "Rohini" and "Pitampura". |
| **Dashboard** | The numbers on the home screen: products, retailers, pending orders, invoices sent, recent orders. |

---

## A day in the life of an order

1. **A shop places an order** for 10 bottles of Cola. The service *sets aside* those 10 bottles so they can't be
   promised to someone else. Your shelf still shows 50, but only 40 are free to sell.
2. **You open the order** (Edit Order). You can change quantities, add products the shop didn't order, or change a
   price for this one bill. This is saved as a *draft*: nothing leaves the shelf yet, and you can come back to it.
3. **Or you reject it.** The 10 bottles set aside are freed again, and the draft (if any) is thrown away.
4. **You send the invoice.** The service:
   - checks you really have the stock ("Cola: only 50 on hand." if you don't),
   - gives the bill the next number, like `INV-0001-202611-0001` (your supplier number, the month, then 0001, 0002…),
   - adds GST (18% by default) unless you've turned GST off for that shop,
   - takes the goods off the shelf and frees what was set aside.
5. **The bill goes into the khata.** The amount, GST included, is added to what that shop owes you.
6. **The shop pays** by cash, UPI, cheque or bank transfer. You record the payment and their balance goes down.
7. **Made a typo?** The *latest* payment can be corrected directly. Any older entry is *voided*: crossed out with a
   reason, still visible, but no longer counted. Then you enter it again correctly.
8. **The shop accepts the bill** on their side, and the order shows as *Fulfilled*. (Cancelling and "in transit"
   are also set from the shop's side.)

---

## The khata (ledger), in plain words

```
What a shop owes  =  what they owed when you started using the system   (opening balance)
                  +  orders you wrote down by hand                      (offline orders)
                  +  bills sent through the system, GST included        (online orders)
                  −  payments received
```

- A **negative** balance means the shop has paid you in advance.
- **Shops that aren't on the system yet** can be added by hand, with their own name and phone number. When they
  join, you **link** them: their old handwritten history and their new bills then share one balance.
- **Statement**: one shop's entries between two dates, with the running balance after each one.
- **Day book**: one day at a glance, for every shop: what they owed when the day started, their orders and payments
  that day, and what they owe at the end.
- **Recent payments**: a shop's last 10 payments (up to 50), newest first. Only the newest can be edited.
- **Dates use Indian time.** A bill sent at 12:30 am counts for the new day, even though servers keep time in UTC
  (world standard time, 5½ hours behind India), where it's still the day before.
- Nothing can be dated in the future, and mistakes are never erased: they are voided with a reason.

---

## How a price is chosen

When a shop buys a product (or you add one to their order), the service looks for a price in this order:

1. The shop's own price group, if it has a price for the product today.
2. Otherwise, the **Standard** price.
3. Otherwise there's no price, and you type one in.

Prices can have a start date and an end date, so you can set next month's price in advance.

---

## Signing in, in plain words

Think of a **hotel key card**. When you sign in, the service gives the app a card (a *token*) that opens the doors
for **8 hours**. The app shows it with every request. When it runs out, you sign in again.

The service also has a **renewal slip** system (a *refresh token*), so a future version of the app can quietly get a
new card without asking you to sign in. The app doesn't use it yet. Some safety rules come with it:

- Each renewal slip works only once. If an old, already-used slip is ever shown again, the service assumes it was
  copied and cancels that sign-in for safety.
- Changing your password cancels the renewal slips of every other computer you were signed in on.
- Signing out cancels the renewal slip at once.
- A key card can't be cancelled early: whatever happens, one already given out keeps working until its 8 hours are
  up. That's why, once the app uses renewal slips, the key cards can be made to last minutes instead of hours.

---

## Where the information lives

- **The database** (PostgreSQL) is one big, organised filing cabinet shared with the retailer system. This service
  has its own drawers (the `supplier` *schema*). The retailers' drawers (`retailer`) belong to the other system:
  this service reads them, and only ever changes one thing there, whether a shop is blocked or active.
- **Product photos** are files in a folder on the server. Each upload is kept twice: the original, and a small copy
  for lists (a *thumbnail*). Location details that phones hide inside photos are removed from the small copy.
  Photos can be PNG or JPEG, up to 2 MB.

---

## Safety rules built in

- **Each supplier only ever sees their own data.** Asking for someone else's order gets "not found".
- **Two people at once can't break the numbers.** If two requests change the same stock or the same bill at the
  same moment, one waits for the other.
- **Stock history always adds up.** Every change to the shelf is recorded with its reason (opening stock, a manual
  adjustment, or the invoice that shipped it).
- **Money is calculated exactly**, never as rough decimals, and rounded to the nearest paisa (half a paisa rounds up).
- **Stock you've promised can't be removed by hand.** A manual adjustment can only take away stock that is free.

---

## Running it on your own computer

You need Python and a PostgreSQL database running. The developer guide ([README.md](README.md)) shows one way to
start a database. Then, in a terminal, from the `supplier-service` folder:

```powershell
python -m venv .venv            # a private box for this project's Python libraries
.venv\Scripts\Activate.ps1      # step into that box
pip install -e ".[dev]"         # install the libraries the service needs
copy .env.example .env          # your settings file: put a long random JWT_SECRET_KEY in it
flask db upgrade                # build the database tables
flask seed-demo                 # optional: sample data and a demo login (only ever on your own computer)
python run.py                   # start the service at http://127.0.0.1:5000
```

**Is it working?** Open http://127.0.0.1:5000/health in a browser. You should see `{"status": "ok"}`, which means the
service is running and can reach the database.

**Demo login** (after `flask seed-demo`): `demo@supplier.com` / `Password@123`.

**Trying the app without this service:** set `"UseMockBackend": true` in the app's `appsettings.json`. The app then
uses built-in pretend data and doesn't need the service at all.

---

## The tests, in plain words

Tests are small programs that use the service the way the app would and check the answers. **651** of them pass.

- Together they run **every line** of the service's code at least once.
- To prove they really catch problems, mistakes were deliberately planted in the code. The tests caught every one
  that changed how the service behaves.
- One test is marked "expected to fail": it describes a known problem (some phone photos are rejected, see below)
  and will start passing once that's fixed.

To run them: `pytest` in the `supplier-service` folder. Green means all good.

---

## Not finished yet, and why it matters

| What | Why it matters |
|---|---|
| **How orders arrive from the shops' system** isn't built into this service yet. | It must be agreed with the retailer team, and the stock set aside, before going live. |
| **Photos are stored on one computer.** | Fine for one server. Before running on more than one, or to be safe against losing that machine, they should move to cloud storage. |
| **No limit on repeated wrong passwords.** | Someone could keep guessing. A limit should be added in front of the service (see the production guide). |
| **The app doesn't use renewal slips yet.** | That's why sign-ins last 8 hours instead of being renewed quietly. |
| **Some phone photos are rejected.** | Many phones save JPEGs with extra pictures inside (for example "Ultra HDR"). The service doesn't recognise these as JPEGs yet. |

---

## Messages you might see

| Message | What it means |
|---|---|
| Your session has expired. Please sign in again. | Your 8-hour key card ran out (or isn't valid). Sign in again. |
| Invalid email or password. | Wrong sign-in details. |
| Cola: only 50 on hand. | You tried to bill more Cola than is on the shelf. |
| Cannot remove 5; only 3 available (excluding reserved stock). | Some of that stock is promised to orders, so it can't be taken off by hand. |
| Only pending orders can be edited. (or rejected, or invoiced) | The order has already moved on: it was billed, rejected or cancelled. |
| Only the last payment can be edited. | Older payments can't be changed; void them and enter them again. |
| The date can't be in the future. | Ledger entries can be dated today at the latest. |
| This retailer already has an opening balance. Void it to enter a different one. | Each shop has one starting balance. |
| The Standard price group can't be deactivated: retailers without a price group use it. | Standard is everyone's fallback, so it always stays. |
| Move the retailers in this group to another price group before deactivating it. | Shops are still using that price list. |
| This change conflicts with existing data. Refresh and try again. | Someone else changed the same thing at the same moment. |
| The file is not a valid PNG or JPEG image. | The photo is damaged or another type. It can also be the phone-photo problem above. |
| Image must be 2 MB or smaller. | The photo file is too big. |

---

## Words you'll hear

| Word | Meaning |
|---|---|
| **API / endpoint** | The set of "doors" the app can knock on, each for one job (e.g. "send this invoice"). An endpoint is one door. |
| **Database** | Where everything is saved permanently. Here: PostgreSQL. |
| **Schema** | A set of drawers inside the database. This service has `supplier`; the retailer system has `retailer`. |
| **Migration** | A numbered set of instructions that changes the database's layout safely, e.g. "add a table for sign-ins". There are 13 so far. |
| **Token** | The 8-hour key card the app shows with every request. |
| **Refresh token** | The renewal slip for getting a new key card without signing in again. |
| **Reserved stock** | Stock set aside for orders that haven't been billed yet. |
| **Available stock** | On the shelf minus reserved: what you can still promise. |
| **Draft invoice** | Your planned bill for an order (from Edit Order), not sent yet. |
| **Void** | Cross out a ledger entry with a reason. It stays visible but no longer counts. |
| **GST** | Goods and Services Tax, 18% by default, which can be turned off per shop. |
| **Business day** | A day in Indian time, used for ledger dates. |
| **Price group** | A price list for a set of shops. **Standard** is the default for everyone. |
| **Circle / location** | Your sales area (e.g. North Delhi) and a place within it (e.g. Rohini). |
| **Online / offline retailer** | A shop on the platform, or one you keep track of by hand. |
| **Thumbnail** | A small copy of a photo, used in lists so they load quickly. |
| **Server / reverse proxy / HTTPS** | The computer the service runs on; the gatekeeper in front of it; and the secure (padlock) connection to it. |
| **Health check** | The `/health` address that answers "ok" when the service and database are working. |
| **Test** | An automatic check that the service still behaves as expected. |

---

## Where to read more

- [README.md](README.md): for developers running and changing the service.
- [README.PRODUCTION.md](README.PRODUCTION.md): for whoever installs it on the live server.
- [ARCHITECTURE.md](ARCHITECTURE.md): diagrams of how it is built and how each piece of work flows through it.
