"""WSGI entry point, e.g. `waitress-serve --port 5000 wsgi:app` or `gunicorn wsgi:app`."""

from dotenv import load_dotenv

load_dotenv()

from supplier_service import create_app  # noqa: E402  (after the environment is loaded)

app = create_app()
