"""ledger accounts: a location tag for offline retailers

Revision ID: 0011
Revises: 0010
Create Date: 2026-11-04 23:00:00

Online accounts show their retailer's tag (retailer_settings.location_tag), so only offline ones use this.
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0011'
down_revision = '0010'
branch_labels = None
depends_on = None


def _schema() -> str | None:
    # 0003 moved the tables into the supplier schema on PostgreSQL only.
    return "supplier" if op.get_context().dialect.name == "postgresql" else None


def upgrade():
    with op.batch_alter_table('ledger_accounts', schema=_schema()) as batch_op:
        batch_op.add_column(sa.Column('location_tag', sa.String(length=50), nullable=True))


def downgrade():
    with op.batch_alter_table('ledger_accounts', schema=_schema()) as batch_op:
        batch_op.drop_column('location_tag')
