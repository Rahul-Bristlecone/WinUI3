"""move the service's tables into the supplier schema

Revision ID: 0003
Revises: 0002
Create Date: 2026-11-03 20:00:00

ALTER TABLE ... SET SCHEMA keeps the rows, keys, indexes and owned sequences. Views that read these
tables (public.retailer_products, public.retailer_supplier_directory) reference them by id, so they
keep working and stay in public, where the retailer side expects them.

Other roles (e.g. the retailer service inserting orders) keep their table privileges through the move
but need USAGE on the new schema, so it is granted to every role that holds privileges on these tables.
Anything that names these tables unqualified must now use the supplier schema (or put it on its search_path).
"""
from alembic import op

revision = '0003'
down_revision = '0002'
branch_labels = None
depends_on = None

SCHEMA = "supplier"
TABLES = [
    "suppliers", "categories", "products", "inventory", "inventory_transactions",
    "price_groups", "product_prices", "retailer_price_groups",
    "orders", "order_items", "invoices", "invoice_lines",
]


def _is_postgresql() -> bool:
    return op.get_context().dialect.name == "postgresql"


def upgrade():
    if not _is_postgresql():
        return  # schemas are PostgreSQL-only; the other databases here are throwaway test databases
    op.execute(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}")
    for table in TABLES:
        op.execute(f"ALTER TABLE public.{table} SET SCHEMA {SCHEMA}")
    tables = ", ".join(f"'{SCHEMA}.{table}'::regclass" for table in TABLES)
    op.execute(f"""
        DO $migration$ DECLARE grantee oid; BEGIN
            FOR grantee IN
                SELECT DISTINCT a.grantee FROM pg_class c, aclexplode(c.relacl) a
                WHERE c.oid = ANY (ARRAY[{tables}]) AND a.grantee <> 0 AND a.grantee <> c.relowner
            LOOP
                EXECUTE 'GRANT USAGE ON SCHEMA {SCHEMA} TO ' || quote_ident(pg_get_userbyid(grantee));
            END LOOP;
        END $migration$
    """)


def downgrade():
    if not _is_postgresql():
        return
    for table in reversed(TABLES):
        op.execute(f"ALTER TABLE {SCHEMA}.{table} SET SCHEMA public")
