"""price groups get a rate (%)

Revision ID: 0005
Revises: 0004
Create Date: 2026-11-04 12:00:00

Existing groups start at 0%.
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0005'
down_revision = '0004'
branch_labels = None
depends_on = None


def _schema() -> str | None:
    # 0003 moved the tables into the supplier schema on PostgreSQL only.
    return "supplier" if op.get_context().dialect.name == "postgresql" else None


def upgrade():
    with op.batch_alter_table('price_groups', schema=_schema()) as batch_op:
        batch_op.add_column(sa.Column('rate', sa.Numeric(precision=5, scale=2), server_default='0', nullable=False))


def downgrade():
    with op.batch_alter_table('price_groups', schema=_schema()) as batch_op:
        batch_op.drop_column('rate')
