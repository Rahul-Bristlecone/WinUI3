"""retailer settings: GST applicable per retailer

Revision ID: 0006
Revises: 0005
Create Date: 2026-11-04 14:00:00

A supplier's own settings for a retailer. No rows yet, so every retailer keeps GST until the supplier
turns it off.
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0006'
down_revision = '0005'
branch_labels = None
depends_on = None


def _schema() -> str | None:
    # 0003 moved the tables into the supplier schema on PostgreSQL only.
    return "supplier" if op.get_context().dialect.name == "postgresql" else None


def upgrade():
    schema = _schema()
    suppliers_id = f"{schema}.suppliers.id" if schema else "suppliers.id"
    op.create_table('retailer_settings',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('supplier_id', sa.Integer(), nullable=False),
    sa.Column('retailer_id', sa.Integer(), nullable=False),
    sa.Column('gst_applicable', sa.Boolean(), server_default=sa.true(), nullable=False),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['supplier_id'], [suppliers_id], name=op.f('fk_retailer_settings_supplier_id_suppliers')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_retailer_settings')),
    sa.UniqueConstraint('supplier_id', 'retailer_id', name='uq_retailer_settings'),
    schema=schema,
    )
    with op.batch_alter_table('retailer_settings', schema=schema) as batch_op:
        batch_op.create_index(batch_op.f('ix_retailer_settings_retailer_id'), ['retailer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_retailer_settings_supplier_id'), ['supplier_id'], unique=False)


def downgrade():
    op.drop_table('retailer_settings', schema=_schema())
