"""products lose their own price: prices live in price groups

Revision ID: 0008
Revises: 0007
Create Date: 2026-11-04 18:00:00

Before the column goes, a product price that was entered (above zero) becomes the product's price in
its supplier's Standard group, where that group has no price for it yet: open ended from today.
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0008'
down_revision = '0007'
branch_labels = None
depends_on = None


def _is_postgresql() -> bool:
    return op.get_context().dialect.name == "postgresql"


def _schema() -> str | None:
    # 0003 moved the tables into the supplier schema on PostgreSQL only.
    return "supplier" if _is_postgresql() else None


def _table(name: str) -> str:
    return f"supplier.{name}" if _is_postgresql() else name


def upgrade():
    products, groups, prices = _table("products"), _table("price_groups"), _table("product_prices")
    # Timestamps are stored as UTC; effectivity starts at midnight (UTC) today, so the price applies at once.
    if _is_postgresql():
        now, today = "(now() AT TIME ZONE 'UTC')", "date_trunc('day', now() AT TIME ZONE 'UTC')"
    else:
        now, today = "CURRENT_TIMESTAMP", "datetime('now', 'start of day')"
    op.execute(f"""
        INSERT INTO {prices} (price_group_id, product_id, unit_price, effective_from, effective_to, created_at, updated_at)
        SELECT g.id, p.id, p.price, {today}, NULL, {now}, {now}
        FROM {products} p
        JOIN {groups} g ON g.supplier_id = p.supplier_id AND g.is_default
        WHERE p.price > 0
          AND NOT EXISTS (SELECT 1 FROM {prices} pp WHERE pp.price_group_id = g.id AND pp.product_id = p.id)
    """)
    with op.batch_alter_table('products', schema=_schema()) as batch_op:
        batch_op.drop_column('price')


def downgrade():
    # The prices copied into Standard stay there; the restored column starts at 0.
    with op.batch_alter_table('products', schema=_schema()) as batch_op:
        batch_op.add_column(sa.Column('price', sa.Numeric(precision=10, scale=2), server_default='0', nullable=False))
