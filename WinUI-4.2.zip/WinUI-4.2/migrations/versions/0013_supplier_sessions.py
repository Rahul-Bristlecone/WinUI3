"""supplier_sessions: sign-in sessions behind refresh tokens

Revision ID: 0013
Revises: 0012
Create Date: 2026-11-05 12:00:00

One row per sign-in (see supplier_service/auth/sessions.py). Tokens issued before this have no session: they keep
working until they expire, and then the user signs in again.
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0013'
down_revision = '0012'
branch_labels = None
depends_on = None


def _schema() -> str | None:
    # 0003 moved the tables into the supplier schema on PostgreSQL only.
    return "supplier" if op.get_context().dialect.name == "postgresql" else None


def upgrade():
    schema = _schema()
    prefix = f"{schema}." if schema else ""
    op.create_table('supplier_sessions',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('supplier_id', sa.Integer(), nullable=False),
    sa.Column('public_id', sa.String(length=32), nullable=False),
    sa.Column('generation', sa.Integer(), nullable=False),
    sa.Column('token_issued_at', sa.DateTime(), nullable=False),
    sa.Column('expires_at', sa.DateTime(), nullable=False),
    sa.Column('revoked_at', sa.DateTime(), nullable=True),
    sa.Column('revoked_reason', sa.String(length=20), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['supplier_id'], [f'{prefix}suppliers.id'], name=op.f('fk_supplier_sessions_supplier_id_suppliers')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_supplier_sessions')),
    sa.UniqueConstraint('public_id', name=op.f('uq_supplier_sessions_public_id')),
    schema=schema,
    )
    with op.batch_alter_table('supplier_sessions', schema=schema) as batch_op:
        batch_op.create_index(batch_op.f('ix_supplier_sessions_supplier_id'), ['supplier_id'], unique=False)


def downgrade():
    op.drop_table('supplier_sessions', schema=_schema())
