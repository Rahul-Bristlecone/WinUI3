"""every supplier has a Standard price group; price groups lose their rate

Revision ID: 0007
Revises: 0006
Create Date: 2026-11-04 16:00:00

Each supplier gets one default ("Standard") price group: its group named Standard becomes the default
(and is reactivated, as the default can't be inactive); suppliers without one get a new group. Retailers
without an assigned group now use it, both in this service and in public.retailer_products, where they
used to get the supplier's first active group.
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0007'
down_revision = '0006'
branch_labels = None
depends_on = None


def _is_postgresql() -> bool:
    return op.get_context().dialect.name == "postgresql"


def _schema() -> str | None:
    # 0003 moved the tables into the supplier schema on PostgreSQL only.
    return "supplier" if _is_postgresql() else None


def _table(name: str) -> str:
    return f"supplier.{name}" if _is_postgresql() else name


# public.retailer_products as 0002/0003 left it, with the unassigned retailer's group as the only variable.
_RETAILER_PRODUCTS = """
 SELECT sc.retailer_id,
    p.id AS product_id,
    p.supplier_id,
    p.product_code,
    p.product_name,
    p.description,
    c.category_name,
    p.unit_of_measure,
    pp.unit_price AS price,
    COALESCE(i.available_quantity, 0) AS available_qty,
    p.image_filename,
    p.is_active AND COALESCE(c.is_active, true) AND sc.status::text = 'Active'::text AS is_active
   FROM retailer.supplier_connections sc
     JOIN supplier.products p ON p.supplier_id = sc.supplier_id
     LEFT JOIN supplier.retailer_price_groups rpg ON rpg.supplier_id = sc.supplier_id AND rpg.retailer_id = sc.retailer_id
     LEFT JOIN supplier.categories c ON c.id = p.category_id
     LEFT JOIN supplier.inventory i ON i.product_id = p.id
     LEFT JOIN supplier.product_prices pp ON pp.price_group_id = COALESCE(rpg.price_group_id, {default_group})
       AND pp.product_id = p.id AND pp.effective_from <= (now() AT TIME ZONE 'UTC'::text)
       AND (pp.effective_to IS NULL OR pp.effective_to >= date_trunc('day'::text, (now() AT TIME ZONE 'UTC'::text)))
"""
_STANDARD_GROUP = "(SELECT g.id FROM supplier.price_groups g WHERE g.supplier_id = sc.supplier_id AND g.is_default LIMIT 1)"
_FIRST_ACTIVE_GROUP = (
    "(SELECT g.id FROM supplier.price_groups g WHERE g.supplier_id = sc.supplier_id AND g.is_active ORDER BY g.id LIMIT 1)"
)


def _replace_retailer_products(default_group: str) -> None:
    """Only where the view exists (it belongs to the shared PostgreSQL deployment, not this service's tests)."""
    if not _is_postgresql():
        return
    select_sql = _RETAILER_PRODUCTS.format(default_group=default_group)
    op.execute(
        "DO $migration$ BEGIN "
        "IF to_regclass('public.retailer_products') IS NOT NULL THEN "
        f"EXECUTE $view$CREATE OR REPLACE VIEW public.retailer_products AS {select_sql}$view$; "
        "END IF; END $migration$"
    )


def upgrade():
    with op.batch_alter_table('price_groups', schema=_schema()) as batch_op:
        batch_op.add_column(sa.Column('is_default', sa.Boolean(), server_default=sa.false(), nullable=False))
        batch_op.drop_column('rate')

    groups, suppliers = _table("price_groups"), _table("suppliers")
    now = "(now() AT TIME ZONE 'UTC')" if _is_postgresql() else "CURRENT_TIMESTAMP"  # timestamps are stored as UTC
    op.execute(f"""
        UPDATE {groups} SET is_default = TRUE, is_active = TRUE
        WHERE id IN (SELECT MIN(id) FROM {groups} WHERE lower(group_name) = 'standard' GROUP BY supplier_id)
    """)
    op.execute(f"""
        INSERT INTO {groups} (supplier_id, group_name, description, is_active, is_default, created_at, updated_at)
        SELECT s.id, 'Standard', 'Default prices for every retailer', TRUE, TRUE, {now}, {now}
        FROM {suppliers} s
        WHERE NOT EXISTS (SELECT 1 FROM {groups} g WHERE g.supplier_id = s.id AND g.is_default)
    """)

    _replace_retailer_products(_STANDARD_GROUP)


def downgrade():
    # The Standard groups created by upgrade() stay: they may have prices and retailers by now.
    _replace_retailer_products(_FIRST_ACTIVE_GROUP)
    with op.batch_alter_table('price_groups', schema=_schema()) as batch_op:
        batch_op.add_column(sa.Column('rate', sa.Numeric(precision=5, scale=2), server_default='0', nullable=False))
        batch_op.drop_column('is_default')
