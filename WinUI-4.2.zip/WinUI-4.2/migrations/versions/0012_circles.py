"""circles: State → Circle → Location replaces free-text location tags

Revision ID: 0012
Revises: 0011
Create Date: 2026-11-05 10:00:00

Each supplier's tags become locations (one per tag, ignoring case) in a circle named "General" in Delhi, and the
tagged retailers and offline accounts are assigned to them. Downgrading turns locations back into tags; a
circle-only assignment has no tag, so it is lost.
"""
from datetime import datetime, timezone

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0012'
down_revision = '0011'
branch_labels = None
depends_on = None

ASSIGNED = ('retailer_settings', 'ledger_accounts')


def _schema() -> str | None:
    # 0003 moved the tables into the supplier schema on PostgreSQL only.
    return "supplier" if op.get_context().dialect.name == "postgresql" else None


def _tables(schema):
    circles = sa.table('circles', sa.column('id'), sa.column('supplier_id'), sa.column('name'), sa.column('state'),
                       sa.column('created_at'), sa.column('updated_at'), schema=schema)
    locations = sa.table('circle_locations', sa.column('id'), sa.column('supplier_id'), sa.column('circle_id'),
                         sa.column('name'), sa.column('created_at'), sa.column('updated_at'), schema=schema)
    assigned = {
        name: sa.table(name, sa.column('supplier_id'), sa.column('retailer_id'), sa.column('location_tag'),
                       sa.column('circle_id'), sa.column('location_id'), schema=schema)
        for name in ASSIGNED
    }
    return circles, locations, assigned


def _tagged(name, table):
    # A ledger account's own tag counts only while it's offline (an online one shows its retailer's).
    return table.c.retailer_id.is_(None) if name == 'ledger_accounts' else sa.true()


def upgrade():
    schema = _schema()
    prefix = f"{schema}." if schema else ""
    op.create_table('circles',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('supplier_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=60), nullable=False),
    sa.Column('state', sa.String(length=60), nullable=False),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['supplier_id'], [f'{prefix}suppliers.id'], name=op.f('fk_circles_supplier_id_suppliers')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_circles')),
    schema=schema,
    )
    with op.batch_alter_table('circles', schema=schema) as batch_op:
        batch_op.create_index(batch_op.f('ix_circles_supplier_id'), ['supplier_id'], unique=False)

    op.create_table('circle_locations',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('supplier_id', sa.Integer(), nullable=False),
    sa.Column('circle_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=50), nullable=False),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['circle_id'], [f'{prefix}circles.id'], name=op.f('fk_circle_locations_circle_id_circles')),
    sa.ForeignKeyConstraint(['supplier_id'], [f'{prefix}suppliers.id'], name=op.f('fk_circle_locations_supplier_id_suppliers')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_circle_locations')),
    schema=schema,
    )
    with op.batch_alter_table('circle_locations', schema=schema) as batch_op:
        batch_op.create_index(batch_op.f('ix_circle_locations_circle_id'), ['circle_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_circle_locations_supplier_id'), ['supplier_id'], unique=False)

    for name in ASSIGNED:
        with op.batch_alter_table(name, schema=schema) as batch_op:
            batch_op.add_column(sa.Column('circle_id', sa.Integer(), nullable=True))
            batch_op.add_column(sa.Column('location_id', sa.Integer(), nullable=True))
            batch_op.create_index(batch_op.f(f'ix_{name}_circle_id'), ['circle_id'], unique=False)
            batch_op.create_index(batch_op.f(f'ix_{name}_location_id'), ['location_id'], unique=False)
            batch_op.create_foreign_key(batch_op.f(f'fk_{name}_circle_id_circles'), 'circles',
                                        ['circle_id'], ['id'], referent_schema=schema)
            batch_op.create_foreign_key(batch_op.f(f'fk_{name}_location_id_circle_locations'), 'circle_locations',
                                        ['location_id'], ['id'], referent_schema=schema)

    _tags_to_locations(schema)

    for name in ASSIGNED:
        with op.batch_alter_table(name, schema=schema) as batch_op:
            batch_op.drop_column('location_tag')


def _tags_to_locations(schema):
    bind = op.get_bind()
    circles, locations, assigned = _tables(schema)
    now = datetime.now(timezone.utc).replace(tzinfo=None)  # naive UTC, like BaseModel's timestamps

    # supplier -> lower(tag) -> spelling; spellings already agree (the API kept one per supplier).
    tags: dict[int, dict[str, str]] = {}
    for name, table in assigned.items():
        rows = bind.execute(
            sa.select(table.c.supplier_id, table.c.location_tag)
            .where(table.c.location_tag.is_not(None), _tagged(name, table))
            .distinct()
        )
        for supplier_id, tag in rows:
            tags.setdefault(supplier_id, {}).setdefault(tag.lower(), tag)

    for supplier_id, spellings in sorted(tags.items()):
        bind.execute(circles.insert().values(supplier_id=supplier_id, name='General', state='Delhi',
                                             created_at=now, updated_at=now))
        circle_id = bind.scalar(sa.select(circles.c.id).where(circles.c.supplier_id == supplier_id))
        for key, spelling in sorted(spellings.items()):
            bind.execute(locations.insert().values(supplier_id=supplier_id, circle_id=circle_id, name=spelling,
                                                   created_at=now, updated_at=now))
            location_id = bind.scalar(
                sa.select(locations.c.id).where(locations.c.supplier_id == supplier_id, locations.c.name == spelling)
            )
            for name, table in assigned.items():
                bind.execute(
                    table.update()
                    .where(table.c.supplier_id == supplier_id, sa.func.lower(table.c.location_tag) == key,
                           _tagged(name, table))
                    .values(circle_id=circle_id, location_id=location_id)
                )


def downgrade():
    schema = _schema()
    for name in ASSIGNED:
        with op.batch_alter_table(name, schema=schema) as batch_op:
            batch_op.add_column(sa.Column('location_tag', sa.String(length=50), nullable=True))

    _, locations, assigned = _tables(schema)
    for table in assigned.values():
        location_name = sa.select(locations.c.name).where(locations.c.id == table.c.location_id).scalar_subquery()
        op.get_bind().execute(table.update().where(table.c.location_id.is_not(None)).values(location_tag=location_name))

    for name in ASSIGNED:
        with op.batch_alter_table(name, schema=schema) as batch_op:
            batch_op.drop_constraint(batch_op.f(f'fk_{name}_location_id_circle_locations'), type_='foreignkey')
            batch_op.drop_constraint(batch_op.f(f'fk_{name}_circle_id_circles'), type_='foreignkey')
            batch_op.drop_index(batch_op.f(f'ix_{name}_location_id'))
            batch_op.drop_index(batch_op.f(f'ix_{name}_circle_id'))
            batch_op.drop_column('location_id')
            batch_op.drop_column('circle_id')
    op.drop_table('circle_locations', schema=schema)
    op.drop_table('circles', schema=schema)
