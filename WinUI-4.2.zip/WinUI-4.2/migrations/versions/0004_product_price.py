"""products get a base price

Revision ID: 0004
Revises: 0003
Create Date: 2026-11-04 10:00:00

Existing products start at 0. Price groups still set what each retailer pays (the retailer_products
view reads product_prices, not this column).
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0004'
down_revision = '0003'
branch_labels = None
depends_on = None


def _schema() -> str | None:
    # 0003 moved the tables into the supplier schema on PostgreSQL only.
    return "supplier" if op.get_context().dialect.name == "postgresql" else None


def upgrade():
    with op.batch_alter_table('products', schema=_schema()) as batch_op:
        batch_op.add_column(sa.Column('price', sa.Numeric(precision=10, scale=2), server_default='0', nullable=False))


def downgrade():
    with op.batch_alter_table('products', schema=_schema()) as batch_op:
        batch_op.drop_column('price')
