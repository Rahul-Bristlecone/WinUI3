"""retailer settings: the supplier's location tag per retailer

Revision ID: 0010
Revises: 0009
Create Date: 2026-11-04 22:00:00

Every retailer starts untagged.
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0010'
down_revision = '0009'
branch_labels = None
depends_on = None


def _schema() -> str | None:
    # 0003 moved the tables into the supplier schema on PostgreSQL only.
    return "supplier" if op.get_context().dialect.name == "postgresql" else None


def upgrade():
    with op.batch_alter_table('retailer_settings', schema=_schema()) as batch_op:
        batch_op.add_column(sa.Column('location_tag', sa.String(length=50), nullable=True))


def downgrade():
    with op.batch_alter_table('retailer_settings', schema=_schema()) as batch_op:
        batch_op.drop_column('location_tag')
