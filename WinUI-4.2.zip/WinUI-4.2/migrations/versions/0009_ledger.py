"""ledger: retailer accounts (online and offline) and the entries the supplier records

Revision ID: 0009
Revises: 0008
Create Date: 2026-11-04 20:00:00

Online orders aren't copied in: the ledger reads them from sent invoices. Online retailers' accounts are
created the first time the ledger is opened, so nothing is backfilled here.
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0009'
down_revision = '0008'
branch_labels = None
depends_on = None


def _schema() -> str | None:
    # 0003 moved the tables into the supplier schema on PostgreSQL only.
    return "supplier" if op.get_context().dialect.name == "postgresql" else None


def upgrade():
    schema = _schema()
    prefix = f"{schema}." if schema else ""
    op.create_table('ledger_accounts',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('supplier_id', sa.Integer(), nullable=False),
    sa.Column('retailer_id', sa.Integer(), nullable=True),
    sa.Column('name', sa.String(length=120), nullable=True),
    sa.Column('contact_person', sa.String(length=120), nullable=True),
    sa.Column('phone', sa.String(length=20), nullable=True),
    sa.Column('address', sa.String(length=500), nullable=True),
    sa.Column('notes', sa.Text(), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['supplier_id'], [f'{prefix}suppliers.id'], name=op.f('fk_ledger_accounts_supplier_id_suppliers')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_ledger_accounts')),
    sa.UniqueConstraint('supplier_id', 'retailer_id', name='uq_ledger_account_retailer'),
    schema=schema,
    )
    with op.batch_alter_table('ledger_accounts', schema=schema) as batch_op:
        batch_op.create_index(batch_op.f('ix_ledger_accounts_retailer_id'), ['retailer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_ledger_accounts_supplier_id'), ['supplier_id'], unique=False)

    op.create_table('ledger_entries',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('account_id', sa.Integer(), nullable=False),
    sa.Column('entry_type', sa.String(length=20), nullable=False),
    sa.Column('entry_date', sa.Date(), nullable=False),
    sa.Column('amount', sa.Numeric(precision=12, scale=2), nullable=False),
    sa.Column('reference', sa.String(length=64), nullable=True),
    sa.Column('payment_mode', sa.String(length=20), nullable=True),
    sa.Column('collected_by', sa.String(length=120), nullable=True),
    sa.Column('notes', sa.Text(), nullable=True),
    sa.Column('voided_at', sa.DateTime(), nullable=True),
    sa.Column('void_reason', sa.Text(), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['account_id'], [f'{prefix}ledger_accounts.id'], name=op.f('fk_ledger_entries_account_id_ledger_accounts')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_ledger_entries')),
    schema=schema,
    )
    with op.batch_alter_table('ledger_entries', schema=schema) as batch_op:
        batch_op.create_index(batch_op.f('ix_ledger_entries_account_id'), ['account_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_ledger_entries_entry_date'), ['entry_date'], unique=False)


def downgrade():
    schema = _schema()
    op.drop_table('ledger_entries', schema=schema)
    op.drop_table('ledger_accounts', schema=schema)
