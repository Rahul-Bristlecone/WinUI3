"""retailer price groups replace retailer connections

Revision ID: 0002
Revises: 0001
Create Date: 2026-11-03 19:09:13.450839

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0002'
down_revision = '0001'
branch_labels = None
depends_on = None

# The retailer side reads the catalogue through the public.retailer_products view. It was built on
# retailer_connections, which this migration replaces, so the view is repointed (same columns and
# types) before the table is dropped. Only touched when the view exists (PostgreSQL deployments).
_VIEW_COLUMNS = """
    {retailer_id} AS retailer_id,
    p.id AS product_id,
    p.supplier_id,
    p.product_code,
    p.product_name,
    p.description,
    c.category_name,
    p.unit_of_measure,
    pp.unit_price AS price,
    COALESCE(i.available_quantity, 0) AS available_qty,
    p.image_filename,
    (p.is_active AND COALESCE(c.is_active, true) AND ({status})::text = 'Active'::text) AS is_active
"""
_PRICE_WINDOW = """
    AND pp.product_id = p.id
    AND pp.effective_from <= (now() AT TIME ZONE 'UTC')
    AND (pp.effective_to IS NULL OR pp.effective_to >= date_trunc('day', now() AT TIME ZONE 'UTC'))
"""
_JOINS = """
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN inventory i ON i.product_id = p.id
"""

# Retailers come from the retailer service; unassigned ones use the supplier's first active price group.
RETAILER_PRODUCTS_NEW = (
    "SELECT" + _VIEW_COLUMNS.format(retailer_id="sc.retailer_id", status="sc.status") + """
    FROM retailer.supplier_connections sc
    JOIN products p ON p.supplier_id = sc.supplier_id
    LEFT JOIN retailer_price_groups rpg ON rpg.supplier_id = sc.supplier_id AND rpg.retailer_id = sc.retailer_id"""
    + _JOINS + """
    LEFT JOIN product_prices pp ON pp.price_group_id = COALESCE(
        rpg.price_group_id,
        (SELECT g.id FROM price_groups g WHERE g.supplier_id = sc.supplier_id AND g.is_active ORDER BY g.id LIMIT 1)
    )""" + _PRICE_WINDOW
)

RETAILER_PRODUCTS_OLD = (
    "SELECT" + _VIEW_COLUMNS.format(retailer_id="rc.retailer_id", status="rc.status") + """
    FROM retailer_connections rc
    JOIN products p ON p.supplier_id = rc.supplier_id"""
    + _JOINS + """
    LEFT JOIN product_prices pp ON pp.price_group_id = rc.price_group_id""" + _PRICE_WINDOW
)


def _replace_retailer_products(select_sql: str) -> None:
    if op.get_context().dialect.name != "postgresql":
        return
    op.execute(
        "DO $migration$ BEGIN "
        "IF to_regclass('public.retailer_products') IS NOT NULL THEN "
        f"EXECUTE $view$CREATE OR REPLACE VIEW retailer_products AS {select_sql}$view$; "
        "END IF; END $migration$"
    )


def upgrade():
    op.create_table('retailer_price_groups',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('supplier_id', sa.Integer(), nullable=False),
    sa.Column('retailer_id', sa.Integer(), nullable=False),
    sa.Column('price_group_id', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['price_group_id'], ['price_groups.id'], name=op.f('fk_retailer_price_groups_price_group_id_price_groups')),
    sa.ForeignKeyConstraint(['supplier_id'], ['suppliers.id'], name=op.f('fk_retailer_price_groups_supplier_id_suppliers')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_retailer_price_groups')),
    sa.UniqueConstraint('supplier_id', 'retailer_id', name='uq_retailer_price_group')
    )
    with op.batch_alter_table('retailer_price_groups', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_retailer_price_groups_price_group_id'), ['price_group_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_retailer_price_groups_retailer_id'), ['retailer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_retailer_price_groups_supplier_id'), ['supplier_id'], unique=False)

    # Keep any price-group assignments made on the old snapshot table (its retailer_id is the platform
    # retailer id, same as retailer.retailers.id). The snapshot's contact details are dropped: the
    # retailer service's tables are now the source.
    op.execute(
        "INSERT INTO retailer_price_groups (supplier_id, retailer_id, price_group_id, created_at, updated_at) "
        "SELECT supplier_id, retailer_id, price_group_id, created_at, updated_at FROM retailer_connections"
    )

    _replace_retailer_products(RETAILER_PRODUCTS_NEW)

    with op.batch_alter_table('retailer_connections', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_retailer_connections_price_group_id'))
        batch_op.drop_index(batch_op.f('ix_retailer_connections_retailer_id'))
        batch_op.drop_index(batch_op.f('ix_retailer_connections_supplier_id'))

    op.drop_table('retailer_connections')


def downgrade():
    op.create_table('retailer_connections',
    sa.Column('id', sa.INTEGER(), nullable=False),
    sa.Column('supplier_id', sa.INTEGER(), nullable=False),
    sa.Column('retailer_id', sa.INTEGER(), nullable=False),
    sa.Column('retailer_code', sa.VARCHAR(length=32), nullable=False),
    sa.Column('retailer_name', sa.VARCHAR(length=255), nullable=False),
    sa.Column('email', sa.VARCHAR(length=255), nullable=True),
    sa.Column('phone', sa.VARCHAR(length=50), nullable=True),
    sa.Column('address', sa.TEXT(), nullable=True),
    sa.Column('city', sa.VARCHAR(length=120), nullable=True),
    sa.Column('gst_number', sa.VARCHAR(length=50), nullable=True),
    sa.Column('price_group_id', sa.INTEGER(), nullable=False),
    sa.Column('status', sa.VARCHAR(length=20), nullable=False),
    sa.Column('connected_at', sa.DATETIME(), nullable=False),
    sa.Column('created_at', sa.DATETIME(), nullable=False),
    sa.Column('updated_at', sa.DATETIME(), nullable=False),
    sa.ForeignKeyConstraint(['price_group_id'], ['price_groups.id'], name=op.f('fk_retailer_connections_price_group_id_price_groups')),
    sa.ForeignKeyConstraint(['supplier_id'], ['suppliers.id'], name=op.f('fk_retailer_connections_supplier_id_suppliers')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_retailer_connections')),
    sa.UniqueConstraint('supplier_id', 'retailer_id', name=op.f('uq_supplier_retailer'))
    )
    with op.batch_alter_table('retailer_connections', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_retailer_connections_supplier_id'), ['supplier_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_retailer_connections_retailer_id'), ['retailer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_retailer_connections_price_group_id'), ['price_group_id'], unique=False)

    # The recreated retailer_connections is empty (its snapshot columns can't be rebuilt), so the
    # restored view lists nothing until retailers are re-added there.
    _replace_retailer_products(RETAILER_PRODUCTS_OLD)

    with op.batch_alter_table('retailer_price_groups', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_retailer_price_groups_supplier_id'))
        batch_op.drop_index(batch_op.f('ix_retailer_price_groups_retailer_id'))
        batch_op.drop_index(batch_op.f('ix_retailer_price_groups_price_group_id'))

    op.drop_table('retailer_price_groups')
