# Supplier Service: Production Release Guide

How to deploy, configure, upgrade and run the supplier service in production. For local development see
[README.md](README.md); for how the service is built and how requests flow through it see
[ARCHITECTURE.md](ARCHITECTURE.md).

| | |
|---|---|
| Package | `supplier-service` 0.1.0 (`pyproject.toml`) |
| Database revision | `0013` (head): `flask db current` should print `0013 (head)` after an upgrade |
| Runtime | Python 3.11+ (developed on 3.13), PostgreSQL, a WSGI server behind an HTTPS reverse proxy |
| Clients | Supplier Portal desktop app (`../SupplierPortal`) |
| Tests | 651 passing + 1 expected failure (as of 6 Nov 2026); every line and branch of `supplier_service/` is run by a test |

---

## 1. Resolve before the first production release

These are open items, not configuration. Each one needs a decision or a change before real suppliers use the system.

| # | Item | Why it matters | What to do |
|---|---|---|---|
| 1 | **Order intake** | No endpoint creates orders. `orders/service.py:create_order` records an order *and reserves its stock*, but only the demo seed calls it. If the retailer side inserts rows into `supplier.orders` directly, stock is never reserved. | Agree with the retailer service team how orders arrive, and make that path call `create_order` (an endpoint or a queue consumer). |
| 2 | **Product image storage** | Images are files on the server's disk (`UPLOAD_FOLDER/products`). That only works with one server, has no CDN, and is lost with the machine. `IMAGE_STORAGE` supports only `local`. | Add an Azure Blob (or S3) backend in `catalogue/storage.py` with a CDN in front. Nothing else changes (database column, API, desktop app). Until then: one server, and back up the folder. |
| 3 | **Login rate limiting** | The service has none, so `POST /api/auth/login` can be brute-forced. | Rate-limit `/api/auth/login`, `/api/auth/register` and `/api/auth/refresh` at the reverse proxy or API gateway. |
| 4 | **Access token lifetime** | The desktop app doesn't use refresh tokens yet: it signs the user out when the access token expires. | Keep `JWT_EXPIRES_HOURS=8` and leave `JWT_ACCESS_EXPIRES_MINUTES` unset until the app refreshes. Accept that a leaked access token stays valid for up to 8 hours. |
| 5 | **Phone photos rejected** | Many phones save JPEGs that carry extra pictures (MPO, e.g. "Ultra HDR"). Pillow reads them as `MPO`, and the upload check rejects them as "not a valid PNG or JPEG image". | Decide whether to accept them (fix `_checked_thumbnail` in `catalogue/images.py`). A strict `xfail` test, `test_a_jpeg_carrying_extra_pictures_is_accepted`, tracks it. |
| 6 | **`requirements.txt` is stale** | It lists packages the service doesn't use (`Flask-JWT-Extended`, `psycopg2-binary`) and misses ones it needs (`pydantic`, `pyjwt`, `pillow`, `psycopg` 3). | Install from `pyproject.toml` (`pip install .`), never from `requirements.txt`. Delete or regenerate that file. |

---

## 2. What you are deploying

```
Desktop app ──HTTPS──▶ reverse proxy (TLS, limits) ──HTTP──▶ supplier service (waitress / gunicorn)
                                                                 │            │
                                                                 ▼            ▼
                                                      PostgreSQL (shared)   product image files
                                                      supplier · retailer · public schemas
```

- **One Python process (or a few workers)** serving the Flask app `wsgi:app`. It is stateless apart from product image
  files, so more workers need no sticky sessions.
- **A PostgreSQL database shared with the retailer service.** This service owns the `supplier` schema. It reads the
  retailer service's `retailer` schema and writes one column there (`supplier_connections.status`, for block/activate).
- **A folder of product images** (`UPLOAD_FOLDER/products`), served by the service itself at `/media/products/<file>`.

Deploy the whole `supplier-service` folder: `supplier_service/` (the code), `migrations/` (database changes),
`wsgi.py` (server entry point), `pyproject.toml` (dependencies). `tests/` is needed only to run the tests.

---

## 3. Requirements

| Component | Requirement |
|---|---|
| Python | 3.11 or newer (developed and tested on 3.13) |
| PostgreSQL | The database the retailer service uses; its `retailer` schema must exist. Local development uses PostgreSQL 17. |
| WSGI server | Windows: `waitress`. Linux: `gunicorn`. Neither is a dependency of the package; install one. |
| Reverse proxy | Terminates HTTPS; must allow request bodies of at least 3 MB (image uploads). |
| Disk | Space for product images until image storage moves to the cloud (each upload ≤ 2 MB, plus a small thumbnail). |

---

## 4. Configuration

All settings are environment variables. `wsgi.py` also reads a `.env` file in the working folder, but variables
already set in the environment win, so prefer real environment variables or your platform's secret store.

### Settings

| Variable | Required | Default | Production guidance |
|---|---|---|---|
| `DATABASE_URL` | **Yes** | `postgresql://supplier:supplier@localhost:5432/supplier_service` | The shared database. `postgres://` and `postgresql://` both work; the psycopg 3 driver is always used. |
| `JWT_SECRET_KEY` | **Yes** | none (startup fails) | At least 32 random characters: `python -c "import secrets; print(secrets.token_urlsafe(48))"`. Same value on every instance. Changing it signs everyone out. Keep it in a secret store. |
| `JWT_EXPIRES_HOURS` | Yes, for now | unset | `8`. Access token lifetime while the desktop app doesn't refresh (see §1, item 4). |
| `JWT_ACCESS_EXPIRES_MINUTES` | No | unset (15 minutes if both are unset) | Leave unset until the desktop app refreshes. It takes precedence over `JWT_EXPIRES_HOURS`. |
| `REFRESH_TOKEN_IDLE_DAYS` | No | `7` | A sign-in ends if its refresh token isn't used for this long. |
| `REFRESH_TOKEN_MAX_DAYS` | No | `30` | A sign-in never lasts longer than this. |
| `GST_RATE` | No | `0.18` | GST added to invoices (unless turned off for a retailer). |
| `BUSINESS_UTC_OFFSET` | No | `+05:30` | The supplier's business day for ledger dates, as `+HH:MM` / `-HH:MM`. A bad value stops startup. |
| `PUBLIC_BASE_URL` | **Yes, behind a proxy** | unset | The public HTTPS origin, e.g. `https://supplier-api.example.com`. Image URLs are built from it. Unset, they use the address the service sees (e.g. `http://127.0.0.1:5000`), which clients can't load. |
| `UPLOAD_FOLDER` | Recommended | `<service folder>/uploads` | A folder outside the deployment, so releases don't replace it. Images go in its `products` subfolder. |
| `IMAGE_STORAGE` | No | `local` | Only `local` exists today (§1, item 2). |
| `HOST`, `PORT`, `FLASK_DEBUG` | **Never in production** | | Used only by `python run.py`, the development server. |

### Fixed limits (in `config.py`, not configurable)

| Limit | Value |
|---|---|
| Largest request body | 3 MB (larger requests get 413) |
| Largest product image | 2 MB, and at most 25 megapixels once decoded |
| Thumbnail size | 256 px on the longer side (JPEG) |
| Refresh race grace period | 30 seconds (two refreshes with the same token at once both succeed) |
| Database connections | SQLAlchemy defaults: a pool of 5 per process plus up to 10 overflow, checked before use (`pool_pre_ping`) |

---

## 5. Database

### Schemas

| Schema | Owner | This service |
|---|---|---|
| `supplier` | this service | Creates and migrates every table here (plus `alembic_version`). |
| `retailer` | retailer service | Reads `retailers`, `supplier_connections`, `invoice_acceptances`, `order_deliveries`. Updates `supplier_connections.status`. Never creates, alters or drops anything. |
| `public` | shared | Views the retailer side reads (`retailer_products`, `retailer_supplier_directory`). Migrations 0002 and 0007 redefine `retailer_products` if it exists. |

### Roles (recommended)

Use one role to run migrations (owns the `supplier` schema; must own `public.retailer_products` if that view
exists) and a separate, smaller role for the running service. Example for the runtime role, with names to adjust:

```sql
GRANT USAGE ON SCHEMA supplier TO supplier_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA supplier TO supplier_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA supplier TO supplier_app;

GRANT USAGE ON SCHEMA retailer TO supplier_app;
GRANT SELECT ON retailer.retailers, retailer.supplier_connections,
                retailer.invoice_acceptances, retailer.order_deliveries TO supplier_app;
GRANT UPDATE (status, updated_at) ON retailer.supplier_connections TO supplier_app;  -- block / activate
```

Grants on "all tables" only cover tables that exist. Re-run them after a release whose migration adds tables, or
set `ALTER DEFAULT PRIVILEGES` for the migration role.

### Migrations

Run from the `supplier-service` folder, with `DATABASE_URL` pointing at the migration role. `JWT_SECRET_KEY` must
be set too: these commands start the app, which refuses to start without it.

```powershell
flask --app supplier_service db upgrade     # applies every pending migration; safe to run when there are none
flask --app supplier_service db current     # expect: 0013 (head)
```

On PostgreSQL the first run creates the `supplier` schema and keeps Alembic's version table in it.

> **Never run `flask seed-demo` against production.** It creates a demo supplier with a published password
> (`demo@supplier.com` / `Password@123`) and 14 fake retailers in the retailer service's schema.

---

## 6. Install and run

### Windows (waitress)

```powershell
cd supplier-service
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install .
pip install waitress

waitress-serve --listen=127.0.0.1:5000 --threads=8 wsgi:app
```

### Linux (gunicorn)

```bash
cd supplier-service
python3 -m venv .venv && . .venv/bin/activate
pip install . gunicorn

gunicorn --workers 4 --bind 127.0.0.1:5000 wsgi:app
```

Run the server from the `supplier-service` folder (where `wsgi.py` is), under a service manager that starts it at
boot and restarts it if it stops: for example a Windows service wrapper such as NSSM, or systemd on Linux.

Do **not** use `python run.py` or `flask run` in production. They start Flask's development server, and with
`FLASK_DEBUG=1` its interactive debugger, which lets anyone who can reach it run code on the server.

---

## 7. Reverse proxy and HTTPS

The service speaks plain HTTP and should listen on `127.0.0.1` only. Put a reverse proxy in front of it (IIS with
ARR, nginx, Azure App Service / Front Door, …) that:

- **Terminates HTTPS** and forwards to `http://127.0.0.1:5000`.
- **Allows request bodies of at least 3 MB.** Defaults are often lower (nginx: 1 MB, so set `client_max_body_size 3m;`).
- **Rate-limits sign-in**: `/api/auth/login`, `/api/auth/register`, `/api/auth/refresh`.
- **Writes access logs.** The service itself logs only warnings and errors, not each request.

Set `PUBLIC_BASE_URL` to the proxy's public origin, so image URLs point at it.

Paths that need no sign-in: `/health`, `/media/products/*`, `/api/auth/login`, `/api/auth/register`,
`/api/auth/refresh`, `/api/auth/logout`. Everything else under `/api` needs `Authorization: Bearer <token>`.

`/media/products/*` responses carry a one-year cache header. File names are new for every upload, so a proxy or
CDN can cache them safely.

---

## 8. Point the desktop app at production

In `SupplierPortal/appsettings.json` (copied next to the app's executable):

```json
{ "Api": { "SupplierServiceBaseUrl": "https://supplier-api.example.com/", "TimeoutSeconds": 30, "UseMockBackend": false } }
```

Keep the trailing `/`. The `SUPPLIER_PORTAL_API_URL` environment variable, if set to a valid URL, overrides the
file. The app's Settings page shows which backend it is using.

---

## 9. Release checklist

1. **Test the build** on the release commit:
   ```powershell
   pip install ".[dev]"
   pytest                     # expect: all passed, 1 xfailed
   ```
   Optionally also against an *empty* PostgreSQL database: set `TEST_DATABASE_URL` and run `pytest` again. The
   tests create and drop every table, so pytest refuses a database that has any.
2. **Back up** the database and the image folder (§11).
3. **Deploy** the new `supplier-service` folder. Keep `UPLOAD_FOLDER` and the environment settings outside it.
4. **Install** dependencies: `pip install .` (and the WSGI server, if it's a new environment).
5. **Stop** the service. This avoids old code running against a newer database.
6. **Migrate**: `flask --app supplier_service db upgrade`, then `db current` shows `0013 (head)`.
7. **Start** the service.
8. **Smoke test**:
   - `GET https://<host>/health` returns `200 {"status": "ok"}` (this also checks the database connection).
   - Sign in from the desktop app; the dashboard loads.
   - Open a product that has an image; the picture loads (if it doesn't, check `PUBLIC_BASE_URL`).
9. **Watch the logs** for the first hour (§11).

### Rollback

- **Code**: redeploy the previous folder and restart.
- **Database**: the safest path is restoring the backup from step 2. Every migration also has a downgrade
  (`flask --app supplier_service db downgrade <revision>`), but a downgrade can drop data that the newer version
  stored. For example, going back below `0013` drops `supplier_sessions`, which signs everyone out.

---

## 10. Security checklist

- [ ] `JWT_SECRET_KEY`: random, at least 32 characters, from a secret store, the same on every instance.
- [ ] HTTPS only. The desktop app's URL starts with `https://`.
- [ ] The service listens on `127.0.0.1` (or a private network) only; the proxy is the only way in.
- [ ] Sign-in endpoints are rate-limited at the proxy.
- [ ] The development server and `FLASK_DEBUG` are never used.
- [ ] `flask seed-demo` has not been run; the demo account doesn't exist.
- [ ] The runtime database role has only the grants in §5.
- [ ] Backups of the database and the image folder are scheduled and a restore has been tried.

Behaviour to be aware of:

- **Access tokens can't be revoked.** Signing out, a password change or a revoked session stops *refresh*, but an
  access token already issued keeps working until it expires (8 hours with today's setting).
- **A copied refresh token signs everyone out of that session.** Using a refresh token that has already been
  replaced (outside the 30-second grace period) revokes the session. Both the copy's holder and the real user must
  sign in again. A warning is logged.
- **Product images are public by URL.** The media route needs no sign-in because the app's image control can't send
  a token. File names contain a random 32-character id, so they can't be guessed.
- **Every query is scoped to the signed-in supplier.** Another supplier's ids answer 404, not 403.

---

## 11. Operations

### Health check

`GET /health` returns `{"status": "ok"}` after running `select 1` on the database. Point the load balancer or
uptime monitor at it. If the database is unreachable it fails with HTTP 500.

### Logs

The service writes Python `logging` warnings to standard error. Capture the WSGI server's output. Messages to
watch for:

| Message | Meaning |
|---|---|
| `Refresh token reused: session … revoked.` | A replaced refresh token was used. Possibly a copied token, possibly a client bug. |
| `Integrity error: …` | Two requests changed the same data at once. The second got 409 "This change conflicts with existing data". |
| `Could not delete product image …` / `Could not create thumbnail …` | A file operation failed. The request still succeeded; a stray file may be left behind. |

### Backups

- **Database**: the whole shared database, coordinated with the retailer service team, since orders and invoices
  refer to retailer ids in the `retailer` schema.
- **Images**: the `UPLOAD_FOLDER/products` folder, with the same schedule. A database restored without its image
  files shows products whose pictures don't load.

### Scaling

- More threads or workers on one server: no changes needed.
- More than one server: needs shared image storage first (§1, item 2), and the same `JWT_SECRET_KEY` everywhere.
- Each worker process keeps its own pool of up to 15 database connections. Size PostgreSQL's `max_connections`
  for all workers on all servers, plus the retailer service.

### Rotating `JWT_SECRET_KEY`

Change it on every instance and restart. Every access token and refresh token stops working, so all users must
sign in again. Do it outside working hours.

---

## 12. Known limitations

- Orders can't be created through this service (§1, item 1).
- Product images live on local disk only (§1, item 2).
- No rate limiting on sign-in (§1, item 3).
- No endpoint to list a supplier's sign-ins or end one from another device. A password change ends all the others.
- Order statuses `In-Transit`, `Fulfilled` and `Cancelled` are set by the retailer side, not here.
- Invoice status `Rejected` (set by the retailer side) isn't in the desktop app's status list yet.
- Stock is whole numbers. The app's form accepts decimals, and the service rejects them.
