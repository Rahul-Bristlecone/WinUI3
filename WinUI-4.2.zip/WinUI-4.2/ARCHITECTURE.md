# Supplier Service: Architecture and Flows

How the supplier service is put together, and what happens inside it for each piece of business: signing in,
orders, invoices, stock, prices, the ledger and product images. Diagrams are [Mermaid](https://mermaid.js.org/)
(rendered by GitHub, Azure DevOps and most Markdown viewers).

Related: [README.md](README.md) (local development, design notes) ·
[README.PRODUCTION.md](README.PRODUCTION.md) (deployment) ·
[README.EXPLAINED.md](README.EXPLAINED.md) (plain-language overview).

**Contents:**
1. [System context](#1-system-context)
2. [Inside the service](#2-inside-the-service)
3. [Request lifecycle](#3-request-lifecycle)
4. [Data model](#4-data-model)
5. [Flows](#5-flows)
6. [Cross-cutting rules](#6-cross-cutting-rules)
7. [Testing](#7-testing)
8. [Endpoint map](#8-endpoint-map)
9. [Where to change things](#9-where-to-change-things)

---

## 1. System context

```mermaid
flowchart LR
    subgraph sup["Supplier side"]
        app["Supplier Portal desktop app<br/>WinUI 3 / .NET"]
    end
    subgraph ret["Retailer side (other system)"]
        rapp["Retailer apps"] --> rsvc["Retailer service"]
    end
    app -- "HTTPS, JSON under /api" --> proxy["Reverse proxy<br/>TLS, body limit, rate limits"]
    app -- "product image URLs" --> proxy
    proxy --> svc["Supplier service<br/>Flask app on waitress / gunicorn"]
    svc --> db[("PostgreSQL<br/>supplier · retailer · public schemas")]
    rsvc --> db
    svc --> files[("Product image files<br/>UPLOAD_FOLDER/products")]
```

- **The desktop app** is the only client. It talks JSON over HTTPS and sends a bearer token with every request.
- **The supplier service** (this repository folder) holds all the supplier-side business rules.
- **The retailer service** is a separate system sharing the same database. It owns the `retailer` schema: retailer
  accounts, their connections to suppliers, invoice acceptances and delivery addresses. It reads the supplier's
  catalogue and prices through views in the `public` schema.
- **Product images** are files on disk today, behind a small storage interface (`catalogue/storage.py`), so they
  can move to blob storage plus a CDN without other changes.

What crosses the boundary between the two services, all in the shared database:

| Direction | Data | Where |
|---|---|---|
| Retailer → supplier | Retailer profiles, supplier connections (and their status) | `retailer.retailers`, `retailer.supplier_connections` |
| Retailer → supplier | Invoice accepted by the retailer | `retailer.invoice_acceptances` |
| Retailer → supplier | Delivery address chosen for an order | `retailer.order_deliveries` |
| Retailer → supplier | New orders | *Not defined yet:* `orders/service.py:create_order` is the entry point; there is no endpoint |
| Supplier → retailer | Block / activate a retailer | `retailer.supplier_connections.status` |
| Supplier → retailer | Catalogue, prices, stock as each retailer sees them | `public.retailer_products` view |

---

## 2. Inside the service

### Layers

```mermaid
flowchart TD
    http["HTTP request"] --> routes["routes.py (Flask blueprints)<br/>one per area: endpoints, query strings"]
    routes --> schemas["schemas.py<br/>pydantic request models · JSON serializers"]
    routes --> services["service.py<br/>business rules shared by routes"]
    services --> models["models.py<br/>SQLAlchemy tables"]
    routes --> models
    models --> pg[("PostgreSQL")]
    common["common/<br/>security · http helpers · errors · JSON · BaseModel"] -.-> routes
    common -.-> services
```

- **Routes** stay thin. They authenticate (a blueprint-wide `before_request`), parse the body, call service
  functions, commit, and serialize.
- **Schemas** turn camelCase JSON into typed objects (validation errors become a 400 with one readable message) and
  turn models into the JSON the desktop app expects.
- **Services** hold rules that more than one endpoint needs: stock movements, invoicing, pricing, ledger totals,
  sessions, circles.
- **Models** map tables. Every table has `created_at` / `updated_at` (UTC) from `common/base_model.py`.

### Modules

| Module | Tables it owns | What it does |
|---|---|---|
| `auth/` | `suppliers`, `supplier_sessions` | Register, sign in, refresh tokens (`sessions.py`), sign out, change password, profile |
| `catalogue/` | `categories`, `products` | Categories (nested), products, product images (`images.py`, `storage.py`), `/media` |
| `inventory/` | `inventory`, `inventory_transactions` | Stock levels; `service.py` is the only code that changes stock |
| `pricing/` | `price_groups`, `product_prices` | Price groups (Standard is built in), prices with effective dates, the price grid |
| `retailers/` | `retailer_price_groups`, `retailer_settings` | The supplier's retailers: price group, GST on/off, sales area, block/activate. Also maps the retailer schema's tables. |
| `orders/` | `orders`, `order_items` | Order list and detail, reject, Edit Order (product lookup, planned quantities) |
| `invoices/` | `invoices`, `invoice_lines` | Drafts and sending invoices: stock check, numbering, GST |
| `ledger/` | `ledger_accounts`, `ledger_entries` | What each retailer owes: entries, payments, statement, day book, summary |
| `circles/` | `circles`, `circle_locations` | Sales areas: State → Circle → Location |
| `dashboard/` | none | Counts and the 15 most recent orders (pending first) |
| `common/` | none | Auth helpers, request parsing and paging, error responses, JSON provider, base model |
| `extensions/` | none | `db` (default schema `supplier`), `migrate`, Alembic filters that keep migrations out of other schemas |
| `seed.py` | none | `flask seed-demo`: demo data for development only |

### Startup (`create_app`)

1. Read settings from the environment (`config.py`), apply overrides (tests use these).
2. Check settings: `JWT_SECRET_KEY` must be at least 32 characters; database URLs are switched to the psycopg 3
   driver; PostgreSQL sessions are pinned to UTC.
3. Install the JSON provider (money as numbers, dates as ISO strings).
4. Initialise SQLAlchemy and Flask-Migrate (with schema-aware Alembic options on PostgreSQL), import every model.
5. Register error handlers, then 11 blueprints (10 under `/api`, plus `/media`).
6. Add the `seed-demo` command and `GET /health`.

---

## 3. Request lifecycle

```mermaid
sequenceDiagram
    autonumber
    participant App as Desktop app
    participant Route as Route (blueprint)
    participant Auth as require_supplier
    participant Schema as Request schema
    participant Svc as Service functions
    participant DB as PostgreSQL
    App->>Route: PUT /api/... with Bearer token and JSON body
    Route->>Auth: before_request
    Auth->>DB: load the supplier named in the token
    Auth-->>Route: g.supplier, or 401 "Your session has expired"
    Route->>Schema: parse_body
    Schema-->>Route: typed request, or 400 with one message
    Route->>Svc: apply the business rules
    Svc->>DB: SELECT ... FOR UPDATE, INSERT, UPDATE
    Route->>DB: COMMIT
    Route-->>App: 200 JSON in camelCase
```

**Errors** always come back as `{ "message": "..." }`:

| Raised | Response |
|---|---|
| `ApiError(status, message)` | That status and message (400 rule broken, 404 not found or not yours, 409 conflict, …) |
| Validation error in a request body | 400, one message naming the field, e.g. `amount must be greater than 0.` |
| `IntegrityError` (two writers raced past a check) | 409 "This change conflicts with existing data. Refresh and try again.", with a rollback |
| Unknown URL / wrong method / body over 3 MB | 404 / 405 / 413 with a fixed message |
| Anything else | 500 "An unexpected error occurred." |

A request that fails doesn't commit, and its database session is discarded at the end of the request. So a rule that
fails halfway through leaves nothing behind. One deliberate exception: when a replaced refresh token is reused, the
session is revoked and committed before the 401.

**Wire format:** camelCase keys; enums as strings; paged lists as `{ items, totalCount, page, pageSize }` (page from 1,
page size 1–200, default 20); money as JSON numbers; instants as ISO-8601 UTC ending in `Z`; calendar dates (price
effectivity, ledger days) as `YYYY-MM-DDT00:00:00` with no offset.

---

## 4. Data model

```mermaid
erDiagram
    SUPPLIERS ||--o{ SUPPLIER_SESSIONS : "signs in"
    SUPPLIERS ||--o{ CATEGORIES : owns
    CATEGORIES ||--o{ CATEGORIES : "parent of"
    SUPPLIERS ||--o{ PRODUCTS : sells
    CATEGORIES ||--o{ PRODUCTS : groups
    PRODUCTS ||--o| INVENTORY : "stock level"
    PRODUCTS ||--o{ INVENTORY_TRANSACTIONS : "stock history"
    SUPPLIERS ||--o{ PRICE_GROUPS : defines
    PRICE_GROUPS ||--o{ PRODUCT_PRICES : contains
    PRODUCTS ||--o{ PRODUCT_PRICES : "priced in"
    SUPPLIERS ||--o{ ORDERS : receives
    ORDERS ||--|{ ORDER_ITEMS : lists
    ORDERS ||--o| INVOICES : "invoiced by"
    INVOICES ||--|{ INVOICE_LINES : lists
    SUPPLIERS ||--o{ LEDGER_ACCOUNTS : keeps
    LEDGER_ACCOUNTS ||--o{ LEDGER_ENTRIES : records
    SUPPLIERS ||--o{ CIRCLES : "sales areas"
    CIRCLES ||--o{ CIRCLE_LOCATIONS : contains
    SUPPLIERS ||--o{ RETAILER_PRICE_GROUPS : assigns
    SUPPLIERS ||--o{ RETAILER_SETTINGS : configures
    RETAILERS ||--o{ SUPPLIER_CONNECTIONS : "connects to suppliers"
```

`RETAILERS` and `SUPPLIER_CONNECTIONS` are in the retailer service's schema. The supplier schema refers to retailers by
id only (`orders.retailer_id`, `invoices.retailer_id`, `ledger_accounts.retailer_id`, `retailer_*.retailer_id`), with
no foreign keys across schemas.

| Schema | Owner | Contents |
|---|---|---|
| `supplier` | this service, via Alembic (`migrations/`, head `0013`) | every table above except the retailer ones, and `alembic_version` |
| `retailer` | retailer service | `retailers`, `supplier_connections`, `invoice_acceptances`, `order_deliveries`, … (mapped here, never migrated) |
| `public` | shared | views for the retailer side: `retailer_products`, `retailer_supplier_directory` |

Conventions:
- Timestamps are stored as UTC in `timestamp without time zone` columns. PostgreSQL sessions run in UTC, so
  database `now()` agrees with Python.
- Money is `NUMERIC(12, 2)` (prices `NUMERIC(10, 2)`); Python uses `Decimal` throughout.
- Stock quantities are integers.
- Each entity belongs to one supplier, directly (`supplier_id`) or through its parent (an order item through its order).

---

## 5. Flows

### 5.1 Signing in and staying signed in

```mermaid
sequenceDiagram
    autonumber
    participant App as Desktop app
    participant API as Supplier service
    participant S as supplier_sessions
    App->>API: POST /api/auth/login (email, password)
    API->>S: new session, generation 0
    API-->>App: access token (JWT) + refresh token "session.0.signature" + profile
    App->>API: any /api call with Bearer access token
    Note over API: checks signature, expiry and subject,<br/>and that the supplier still exists and is active
    App->>API: POST /api/auth/refresh (refresh token generation 0)
    API->>S: lock the row, generation 0 becomes 1
    API-->>App: new access token + refresh token "session.1.signature"
    App->>API: POST /api/auth/refresh with generation 0 again
    API->>S: stale generation outside the 30 s grace: revoke the session
    API-->>App: 401 "Your session has expired. Please sign in again."
```

- **Access token**: a JWT (HS256, signed with `JWT_SECRET_KEY`) carrying the supplier id, email, supplier code and
  session id. It isn't checked against the session, so it works until it expires even after sign-out.
- **Refresh token**: `<session public id>.<generation>.<HMAC-SHA256>`. The database stores only the current
  generation, no token. A sign-in lasts while it's refreshed at least every `REFRESH_TOKEN_IDLE_DAYS`, and at most
  `REFRESH_TOKEN_MAX_DAYS`.
- **Rotation and reuse**: each refresh returns a new refresh token, and the old one stops working. Presenting a replaced
  token counts as a copy and revokes the session. The exception: within 30 seconds of a rotation, the previous token
  gets the same new token back (two requests refreshing at once).
- **Sign-out** (`/api/auth/logout`) revokes the session. **Changing the password** revokes the supplier's other
  sessions. **Signing in** clears that supplier's ended sessions.
- **Today the desktop app never calls refresh**: it signs the user out when the access token expires, so production
  keeps an 8-hour access token (`JWT_EXPIRES_HOURS=8`).

### 5.2 An order's life

```mermaid
stateDiagram-v2
    state "Supplier Reject" as SupplierReject
    state "Invoice Sent" as InvoiceSent
    state "In-Transit" as InTransit
    [*] --> Pending: order recorded, stock reserved
    Pending --> SupplierReject: supplier rejects
    Pending --> InvoiceSent: supplier sends the invoice
    Pending --> Cancelled: retailer side
    Pending --> InTransit: retailer side
    InvoiceSent --> InTransit: retailer side
    InvoiceSent --> Fulfilled: retailer accepts the invoice
    InTransit --> Fulfilled: retailer side
    SupplierReject --> [*]
    Cancelled --> [*]
    Fulfilled --> [*]
```

Allowed moves are in `OrderStatus.ALLOWED_TRANSITIONS`. The supplier service makes only two of them: reject, and send
the invoice. The API shows statuses under the desktop app's names: `SupplierRejected`, `Invoiced`, `InTransit`,
`Pending`, `Fulfilled`, `Cancelled`.

**What each event does to stock** (`inventory/service.py`; every on-hand change is logged, so the log always adds up):

| Event | On hand | Reserved |
|---|---|---|
| Order recorded (`create_order`) | — | + ordered quantity |
| Edit Order (draft saved) | — | — |
| Supplier rejects | — | − ordered quantity |
| Invoice sent | − quantity shipped (including extra and added products) | − ordered quantity (the whole reservation) |
| Manual adjustment | ± quantity; removal limited to what isn't reserved | — |

Available = on hand − reserved. Rows are locked in product order (`SELECT … FOR UPDATE`), so two writers can't
deadlock.

### 5.3 From order to invoice (Edit Order, then Send)

```mermaid
sequenceDiagram
    autonumber
    participant App as Desktop app
    participant API as Supplier service
    participant DB as PostgreSQL
    App->>API: GET /api/orders/{id}/product-lookup?code=WATER
    API-->>App: product, the price this retailer pays (or null), stock on hand
    App->>API: PUT /api/orders/{id}/invoiced-quantities (lines)
    API->>DB: save as invoice "DRAFT-{orderId}", status Draft
    API-->>App: order detail with planned quantities and prices
    App->>API: POST /api/invoices (orderId, lines)
    API->>DB: lock stock rows, check on hand for every product shipped
    API->>DB: lock the supplier row, take the next number
    API->>DB: fill lines and totals, release reservation, remove shipped stock
    API-->>App: 201 invoice INV-0001-202611-0001
```

Rules (`invoices/service.py`):
- **Lines**: each is an order line (by id) or a product the supplier adds (by code). An order line may ship 0, the
  ordered quantity, or more ("over-shipping"). An added product needs at least 1 and must be an active product that
  isn't on the order already.
- **Prices**: a line may carry its own price for this invoice only (rounded half-up to paise, above 0, at most
  99,999,999.99). Otherwise it keeps the order's price; an added product takes the price the retailer pays (§5.4).
- **Draft**: lines not sent keep their earlier planned quantity and price. Added products are replaced by the latest
  request. Drafts never appear in invoice lists or counts, can't be opened as invoices, and are deleted if the order is
  rejected.
- **Send**: lines left out ship 0. Nothing ships beyond stock on hand ("Cola: only 50 on hand."). A product with no
  stock record counts as 0 on hand.
- **Number**: `INV-{supplierId:0000}-{yyyymm}-{sequence:0000}`; the sequence restarts each month per supplier. The
  supplier row is locked while the number is taken.
- **GST**: `GST_RATE` × subtotal, rounded half-up to paise, unless GST is off for that retailer. The setting is read
  when the invoice is filled, so a sent invoice keeps its tax. Invoices don't store their rate: `taxRate` is the
  configured one when it explains the stored tax, otherwise it's worked out from the amounts.

### 5.4 What a retailer pays

```mermaid
flowchart TD
    start["Price a product for a retailer"] --> assigned{"Retailer assigned<br/>to a price group?"}
    assigned -- yes --> groupPrice{"That group has a current<br/>price for the product?"}
    assigned -- no --> std{"Standard group has a<br/>current price?"}
    groupPrice -- yes --> useGroup["Use the group's price"]
    groupPrice -- no --> std
    std -- yes --> useStd["Use the Standard price"]
    std -- no --> none["No price: the supplier types one"]
```

"Current" means it started on or before now and hasn't ended before today. Every supplier gets a **Standard** group at
registration; it can't be deactivated. A group with retailers in it can't be deactivated either; move them first.
The same rule ("assigned group, else Standard") decides which group the retailer list shows and how the
`public.retailer_products` view prices the catalogue for the retailer side.

### 5.5 The ledger: what each retailer owes

**Balance** = opening balance + offline orders + online orders (sent invoices, GST included) − payments.
Voided entries don't count. A negative balance means the retailer paid in advance.

- **Accounts**: every connected or invoiced retailer gets an *online* account automatically the first time the ledger
  is listed (two requests creating it at once is harmless). The supplier adds *offline* retailers (not on the
  platform) with their own name and contact details. When an offline retailer onboards, **link** joins the two:
  the offline history and the online invoices share one balance, and the offline account's area moves to the
  retailer's settings if they have none.
- **Entries**: the supplier records an opening balance (one per account), offline orders and payments (with a payment
  mode). Entries are never deleted: a wrong one is **voided** with a reason and stays visible. No entry can be dated
  after today.
- **Days** are business days in `BUSINESS_UTC_OFFSET` (India by default). An invoice counts on the business day it
  was sent.

```mermaid
sequenceDiagram
    autonumber
    participant App as Desktop app
    participant API as Supplier service
    App->>API: GET /api/ledger/accounts/{id}/payments?limit=10
    API-->>App: newest payments that count, totalCount, canEdit only on the first
    App->>API: PUT /api/ledger/entries/{entryId} (date, amount, mode, details)
    Note over API: only payments, only the last one that counts,<br/>same rules as recording, date not after today
    API-->>App: the corrected entry
```

- **Recent payments**: newest first by business day, then by when they were recorded. Default 10, at most 50.
- **Editing**: only the retailer's last payment that counts can be corrected in place; its type can't change, and every
  field is replaced (fields left out are cleared). Anything else is voided and re-entered.
- **Statement**: entries between two dates (default: this month so far) with a running balance, starting from what
  was owed before the first date. Sent invoices appear as read-only lines.
- **Day book**: one business day (default today), per retailer: owed at the start, orders and payments that day,
  owed at the end. An opening balance dated that day counts as owed at the start.
- **Summary**: retailers and total due for the same search and filters as the account list; today's orders and
  collections for the whole business.

### 5.6 Product images

```mermaid
sequenceDiagram
    autonumber
    participant App as Desktop app
    participant API as Supplier service
    participant Store as Image storage
    App->>API: POST /api/products/{id}/image (multipart "file")
    Note over API: .png / .jpg / .jpeg, at most 2 MB, header matches,<br/>decodes fully, at most 25 megapixels
    API->>Store: save original "{productId}-{uuid}.png|jpg"
    API->>Store: save 256 px JPEG "{productId}-{uuid}-thumb.jpg"
    API->>API: product.image_filename = new name, commit
    API->>Store: delete the previous image and thumbnail (best effort)
    API-->>App: product with imageUrl and thumbnailUrl
    App->>API: GET /media/products/{file} (no token)
    API-->>App: file, cached for a year
```

- If the commit fails, the new files are deleted and the old image stays.
- The thumbnail honours camera rotation, flattens transparency onto white and drops metadata such as GPS.
- Images uploaded before thumbnails existed get theirs on first request.
- URLs are absolute: `PUBLIC_BASE_URL` behind a proxy, otherwise the request's host.
- Known issue: JPEGs carrying extra pictures (MPO, common from phones) are rejected (see README.PRODUCTION.md §1).

### 5.7 Sales areas (circles)

A supplier divides its market into **circles**, each in one Indian state or union territory (e.g. "North Delhi" in
Delhi), and **locations** within them.
Retailers, connected or offline, are assigned a circle and optionally a location. Location names are unique per supplier,
so naming an existing location in another circle's editor moves it there, with its retailers. A location or circle in
use can't be removed; move its retailers first. The retailer list, the ledger list and the ledger summary can filter
by circle and location.

---

## 6. Cross-cutting rules

| Concern | Rule | Where |
|---|---|---|
| Tenancy | Every query is filtered by the signed-in supplier. Another supplier's ids answer 404, so their existence isn't revealed. | `current_supplier()` in every route |
| Concurrency | Rows that a write depends on are locked: stock (in product order), the supplier row while numbering invoices, the order being invoiced or rejected, the session being refreshed, the payment being edited. Lost uniqueness races become 409. | `with_for_update` in services and routes |
| Time | Stored in UTC. The business day comes from `BUSINESS_UTC_OFFSET`. Calendar dates from the client keep the day picked, with no shift into UTC. | `ledger/service.py`, `common/http.py` |
| Money | `Decimal` end to end, rounded half-up to paise, sent as JSON numbers | `invoices/service.py`, `common/json_provider.py` |
| Statuses | The database keeps the schema's values; the API translates them to the desktop app's enum names | `orders/schemas.py`, `invoices/schemas.py` |
| Validation | One readable message per failed request, naming the field as the client sends it | `common/http.py:_describe` |
| Schema boundaries | Migrations never touch the `retailer` schema, and reflect only `supplier` | `extensions/database.py` |

---

## 7. Testing

```
tests/
  conftest.py            fresh app + database per test; register/login helpers (API tests)
  test_*.py              API tests: real HTTP calls through Flask's test client, one area per file
  unit/
    conftest.py          one shared app, fresh tables per test; `call` fixture (one request = one session)
    factories.py         rows built directly (no HTTP, no password hashing)
    test_*_service.py    business rules called directly
    test_*_routes.py     endpoint edge cases the API tests don't reach
```

- Runs on in-memory SQLite by default; `TEST_DATABASE_URL` runs it on an *empty* PostgreSQL database.
- As of 6 Nov 2026: 651 tests pass, plus one expected failure (the phone-JPEG issue, a strict `xfail`). Every line
  and branch of `supplier_service/` is run by at least one test. Injected bugs in the business rules were caught by
  the tests.

---

## 8. Endpoint map

🔓 = no sign-in needed. Everything else needs `Authorization: Bearer <access token>`.

| Area | Method and path | Purpose |
|---|---|---|
| Health | `GET /health` 🔓 | Database reachable |
| Auth | `POST /api/auth/register` 🔓 | New supplier, with its Standard price group |
| | `POST /api/auth/login` 🔓 | Tokens and profile |
| | `POST /api/auth/refresh` 🔓 | New token pair for a refresh token |
| | `POST /api/auth/logout` 🔓 | End the refresh token's session |
| | `POST /api/auth/change-password` | Also ends the other sessions |
| | `GET`, `PUT /api/supplier/profile` | Company profile |
| Dashboard | `GET /api/dashboard` | Counts and recent orders |
| Categories | `GET /api/categories` · `GET /api/categories/all` · `POST /api/categories` · `PUT /api/categories/{id}` · `POST /api/categories/{id}/deactivate` | Search and paging on the list |
| Products | `GET /api/products` · `POST /api/products` · `PUT /api/products/{id}` · `POST /api/products/{id}/deactivate` | List: `search`, `categoryId`, `status`, `sortBy` (name, category, uom, stock, status), `sortDir` |
| | `POST /api/products/{id}/image` · `DELETE /api/products/{id}/image` | Multipart field `file` |
| Media | `GET /media/products/{file}` 🔓 | Image files, cached for a year |
| Inventory | `GET /api/inventory` · `GET /api/inventory/summary` · `POST /api/inventory/{productId}/adjust` · `GET /api/inventory/{productId}/history` | Summary values stock at Standard prices |
| Pricing | `GET`, `POST /api/pricegroups` · `PUT /api/pricegroups/{id}` · `POST /api/pricegroups/{id}/deactivate` | Standard is listed first |
| | `GET /api/pricegroups/matrix` · `GET /api/pricegroups/{id}/prices` · `PUT`, `DELETE /api/pricegroups/{id}/prices/{productId}` | Grid of active products × groups; `effectiveFrom` defaults to today |
| Retailers | `GET /api/retailers` · `PUT /api/retailers/{id}/price-group` · `PUT /api/retailers/{id}/gst` · `PUT /api/retailers/{id}/area` · `POST /api/retailers/{id}/block` · `POST /api/retailers/{id}/activate` | List: `search`, `circleId`, `locationId` |
| Circles | `GET /api/circles/states` · `GET`, `POST /api/circles` · `PUT`, `DELETE /api/circles/{id}` | A circle with its locations |
| Orders | `GET /api/orders` · `GET /api/orders/{id}` · `POST /api/orders/{id}/reject` | List: `search`, `status`, `sortBy` (date, status), `sortDir` |
| | `GET /api/orders/{id}/product-lookup?code=` · `PUT /api/orders/{id}/invoiced-quantities` | Edit Order (saves the draft) |
| Invoices | `GET /api/invoices` · `GET /api/invoices/{id}` · `POST /api/invoices` | Sending turns the draft (if any) into the invoice |
| Ledger | `GET /api/ledger/accounts` · `GET /api/ledger/summary` | `search`, `circleId`, `locationId`, `type` (online, offline), `dues=true`; list also `sortBy` (name, balance, lastPayment) |
| | `GET /api/ledger/accounts/all` · `POST /api/ledger/accounts` · `PUT /api/ledger/accounts/{id}` · `POST /api/ledger/accounts/{id}/link` | Offline accounts, and linking one to its online retailer |
| | `GET /api/ledger/accounts/{id}/statement?from=&to=` · `GET /api/ledger/daybook?date=` | Running balance; one day per retailer |
| | `POST /api/ledger/accounts/{id}/entries` · `POST /api/ledger/entries/{id}/void` | Record and void entries |
| | `GET /api/ledger/accounts/{id}/payments?limit=` · `PUT /api/ledger/entries/{id}` | Recent payments; correct the last one |

---

## 9. Where to change things

| Change | Place |
|---|---|
| Move images to Azure Blob / S3 | Add a class next to `LocalImageStorage` in `catalogue/storage.py` and select it in `get_storage()` with `IMAGE_STORAGE`. Routes, the database and the app don't change. |
| Accept orders from the retailer side | Call `orders/service.py:create_order` from a new endpoint or consumer. It records the order and reserves stock. |
| A new stock movement | Go through `inventory/service.py:record_movement`, never update `inventory` directly, so the history stays complete. |
| A new table or column | A model in the area's `models.py`, then `flask db migrate` and review the generated file (schema `supplier` on PostgreSQL). |
| A new endpoint | The area's `routes.py`; request model and serializer in its `schemas.py`; scope every query to `current_supplier()`. |
| A new setting | `config.py`, `.env.example`, and the table in README.PRODUCTION.md §4. |
