"""common/security.py: issuing and checking bearer tokens."""

from datetime import datetime, timedelta, timezone

import jwt
import pytest

from supplier_service.common.errors import ApiError
from supplier_service.common.security import (
    SESSION_EXPIRED,
    auth_required,
    current_session_id,
    current_supplier,
    issue_token,
    require_supplier,
)

from .factories import make_supplier


def authenticate(app, authorization: str | None):
    headers = {} if authorization is None else {"Authorization": authorization}
    with app.test_request_context(headers=headers):
        require_supplier()
        return current_supplier()


def signed(app, claims: dict, *, key: str | None = None, algorithm: str = "HS256") -> str:
    return jwt.encode(claims, key or app.config["JWT_SECRET_KEY"], algorithm=algorithm)


def an_hour_from_now() -> datetime:
    return datetime.now(timezone.utc) + timedelta(hours=1)


# -- issue_token -----------------------------------------------------------------------------------


def test_the_token_identifies_the_supplier(app, supplier):
    token, _ = issue_token(supplier)
    claims = jwt.decode(token, app.config["JWT_SECRET_KEY"], algorithms=["HS256"])
    assert claims["sub"] == str(supplier.id)
    assert claims["email"] == supplier.email
    assert claims["supplierCode"] == supplier.supplier_code


def test_the_token_expires_after_the_configured_session_length(app, supplier, monkeypatch):
    monkeypatch.setitem(app.config, "JWT_EXPIRES", timedelta(hours=2))
    before = datetime.now(timezone.utc)
    token, expires_at = issue_token(supplier)

    claims = jwt.decode(token, app.config["JWT_SECRET_KEY"], algorithms=["HS256"])
    assert claims["exp"] - claims["iat"] == 2 * 60 * 60
    assert claims["exp"] == int(expires_at.timestamp())
    assert expires_at.tzinfo is not None
    assert timedelta(hours=2) <= expires_at - before < timedelta(hours=2, seconds=5)


def test_an_issued_token_is_accepted(app, supplier):
    token, _ = issue_token(supplier)
    assert authenticate(app, f"Bearer {token}").id == supplier.id


def test_the_token_carries_its_session(app, supplier):
    token, _ = issue_token(supplier, "abc123")
    assert jwt.decode(token, app.config["JWT_SECRET_KEY"], algorithms=["HS256"])["sid"] == "abc123"
    with app.test_request_context(headers={"Authorization": f"Bearer {token}"}):
        require_supplier()
        assert current_session_id() == "abc123"


def test_a_token_without_a_session_has_no_session_id(app, supplier):
    token, _ = issue_token(supplier)
    assert "sid" not in jwt.decode(token, app.config["JWT_SECRET_KEY"], algorithms=["HS256"])
    with app.test_request_context(headers={"Authorization": f"Bearer {token}"}):
        require_supplier()
        assert current_session_id() is None


# -- require_supplier ------------------------------------------------------------------------------


def test_the_bearer_scheme_is_case_insensitive(app, supplier):
    token, _ = issue_token(supplier)
    assert authenticate(app, f"bearer {token}").id == supplier.id


@pytest.mark.parametrize(
    "make_header",
    [
        pytest.param(lambda app, s: None, id="no header"),
        pytest.param(lambda app, s: "", id="empty header"),
        pytest.param(lambda app, s: "Bearer", id="no token"),
        pytest.param(lambda app, s: "Bearer ", id="blank token"),
        pytest.param(lambda app, s: f"Basic {issue_token(s)[0]}", id="wrong scheme"),
        pytest.param(lambda app, s: "Bearer not-a-jwt", id="not a jwt"),
        pytest.param(
            lambda app, s: "Bearer " + signed(app, {"sub": str(s.id), "exp": an_hour_from_now()}, key="k" * 40),
            id="signed with another key",
        ),
        pytest.param(
            lambda app, s: "Bearer " + signed(app, {"sub": str(s.id), "exp": datetime.now(timezone.utc) - timedelta(minutes=1)}),
            id="expired",
        ),
        pytest.param(lambda app, s: "Bearer " + signed(app, {"sub": str(s.id)}), id="no expiry"),
        pytest.param(lambda app, s: "Bearer " + signed(app, {"exp": an_hour_from_now()}), id="no subject"),
        pytest.param(lambda app, s: "Bearer " + signed(app, {"sub": "abc", "exp": an_hour_from_now()}), id="subject not an id"),
        pytest.param(lambda app, s: "Bearer " + signed(app, {"sub": "999", "exp": an_hour_from_now()}), id="unknown supplier"),
        pytest.param(
            lambda app, s: "Bearer " + signed(app, {"sub": str(s.id), "exp": an_hour_from_now()}, algorithm="HS512"),
            id="other algorithm",
            # The app's key is short for HS512; this token only needs to carry a different "alg".
            marks=pytest.mark.filterwarnings("ignore:The HMAC key is"),
        ),
    ],
)
def test_anything_but_a_valid_token_reads_as_an_expired_session(app, supplier, make_header):
    with pytest.raises(ApiError) as caught:
        authenticate(app, make_header(app, supplier))
    assert (caught.value.status, caught.value.message) == (401, SESSION_EXPIRED)


def test_a_deactivated_suppliers_token_stops_working(app):
    supplier = make_supplier(active=False)
    token, _ = issue_token(supplier)
    with pytest.raises(ApiError) as caught:
        authenticate(app, f"Bearer {token}")
    assert caught.value.status == 401


# -- auth_required ---------------------------------------------------------------------------------


def test_auth_required_runs_the_view_for_a_signed_in_supplier(app, supplier):
    @auth_required
    def view(order_id, *, page=1):
        return current_supplier().id, order_id, page

    token, _ = issue_token(supplier)
    with app.test_request_context(headers={"Authorization": f"Bearer {token}"}):
        assert view(7, page=2) == (supplier.id, 7, 2)
    assert view.__name__ == "view"  # Flask routes by endpoint name


def test_auth_required_stops_before_the_view_without_a_token(app):
    calls = []

    @auth_required
    def view():
        calls.append(1)

    with app.test_request_context(), pytest.raises(ApiError):
        view()
    assert calls == []
