"""A retailer's recent payments and correcting their last one (ledger/routes.py):

  GET /api/ledger/accounts/<id>/payments   the latest payments that count, newest first (limit, default 10, max 50)
  PUT /api/ledger/entries/<id>             corrects the retailer's last payment

The rules live in the route functions, so these tests call the endpoints (the `call` fixture in conftest.py), with
rows built directly in the database.
"""

from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

import pytest

from supplier_service.common.errors import NOT_FOUND
from supplier_service.extensions.database import db
from supplier_service.ledger import service as ledger_service
from supplier_service.ledger.models import EntryType, LedgerEntry
from supplier_service.ledger.service import last_payments, totals

from .factories import ledger_entry, offline_account

D = Decimal
TODAY = date(2026, 11, 5)
MISSING = object()  # a request field left out


def NOV(day: int) -> date:  # noqa: N802  (reads like a calendar)
    return date(2026, 11, day)


@pytest.fixture
def today(fixed_rates, monkeypatch):
    """The business day is 5 Nov 2026 in India; in UTC it is still 4 Nov (19:00)."""
    monkeypatch.setattr(ledger_service, "utcnow", lambda: datetime(2026, 11, 4, 19, 0, tzinfo=timezone.utc))
    return TODAY


@pytest.fixture
def shop(supplier):
    return offline_account(supplier)


def pay(account, amount, day, *, mode="Cash", **fields) -> LedgerEntry:
    return ledger_entry(account, EntryType.PAYMENT, amount, day, payment_mode=mode, **fields)


def many_payments(account, count: int) -> None:
    """`count` cash payments of 1, 2, 3, ... on consecutive days from 1 Sep 2026 (the biggest is the newest)."""
    db.session.add_all(
        LedgerEntry(account_id=account.id, entry_type=EntryType.PAYMENT, payment_mode="Cash", amount=D(n + 1),
                    entry_date=date(2026, 9, 1) + timedelta(days=n))
        for n in range(count)
    )
    db.session.commit()


def reloaded(entry: LedgerEntry) -> LedgerEntry:
    return db.session.get(LedgerEntry, entry.id, populate_existing=True)


# -- GET /ledger/accounts/<id>/payments ------------------------------------------------------------


def payments(call, account, query="", **kw) -> dict:
    response = call("GET", f"/api/ledger/accounts/{account.id}/payments{query}", **kw)
    assert response.status_code == 200, response.json
    return response.json


def test_newest_first_by_business_day_then_by_when_recorded(call, shop):
    oldest_day = pay(shop, 1, NOV(1), created_at=datetime(2026, 11, 5, 12, 0))  # recorded last, but for an older day
    early = pay(shop, 2, NOV(3), created_at=datetime(2026, 11, 3, 8, 0))
    tied_first = pay(shop, 3, NOV(3), created_at=datetime(2026, 11, 3, 9, 0))
    tied_second = pay(shop, 4, NOV(3), created_at=datetime(2026, 11, 3, 9, 0))  # same instant: the higher id wins
    entered_late = pay(shop, 5, NOV(3), created_at=datetime(2026, 11, 3, 7, 0))  # highest id, but recorded earliest

    listed = payments(call, shop)
    assert [p["id"] for p in listed["payments"]] == [
        tied_second.id, tied_first.id, early.id, entered_late.id, oldest_day.id,
    ]
    assert listed["totalCount"] == 5


def test_only_this_accounts_payments_that_count_are_listed(call, supplier, other_supplier, shop):
    ledger_entry(shop, EntryType.OPENING_BALANCE, 500, NOV(1))
    ledger_entry(shop, EntryType.OFFLINE_ORDER, 900, NOV(2))
    first = pay(shop, 100, NOV(2))
    pay(shop, 999, NOV(4), voided=True)
    second = pay(shop, 200, NOV(3))
    pay(offline_account(supplier, "Another Shop"), 50, NOV(4))
    pay(offline_account(other_supplier, "Not Ours"), 70, NOV(4))

    listed = payments(call, shop)
    assert [p["id"] for p in listed["payments"]] == [second.id, first.id]
    assert listed["totalCount"] == 2


def test_the_count_covers_every_payment_not_just_the_ten_shown(call, shop):
    many_payments(shop, 12)
    listed = payments(call, shop)
    assert [p["credit"] for p in listed["payments"]] == [12, 11, 10, 9, 8, 7, 6, 5, 4, 3]
    assert listed["totalCount"] == 12


@pytest.mark.parametrize(
    "query, shown",
    [("", 10), ("?limit=3", 3), ("?limit=50", 50), ("?limit=51", 50), ("?limit=500", 50),
     ("?limit=0", 1), ("?limit=-4", 1), ("?limit=lots", 10)],
)
def test_limit_defaults_to_ten_and_stays_between_one_and_fifty(call, shop, query, shown):
    many_payments(shop, 55)
    listed = payments(call, shop, query)
    assert len(listed["payments"]) == shown
    assert listed["payments"][0]["credit"] == 55  # always from the newest
    assert listed["totalCount"] == 55


def test_only_the_newest_payment_can_be_edited(call, shop):
    many_payments(shop, 3)
    assert [p["canEdit"] for p in payments(call, shop)["payments"]] == [True, False, False]
    assert [p["canEdit"] for p in payments(call, shop, "?limit=1")["payments"]] == [True]


def test_a_listed_payment_carries_its_details_and_when_it_was_recorded(call, shop):
    payment = pay(shop, "250.50", NOV(3), mode="Upi", reference="UPI-1", collected_by="Ravi", notes="Part payment",
                  created_at=datetime(2026, 11, 3, 4, 30))

    assert payments(call, shop)["payments"] == [{
        "id": payment.id, "kind": "Payment", "date": "2026-11-03T00:00:00",
        "description": "Payment (UPI), collected by Ravi", "reference": "UPI-1", "paymentMode": "Upi",
        "collectedBy": "Ravi", "notes": "Part payment", "debit": 0, "credit": 250.5,
        "balance": None, "isVoided": False, "voidReason": "", "invoiceId": None, "canVoid": True,
        "canEdit": True, "recordedAt": "2026-11-03T04:30:00Z",
    }]


def test_an_account_without_payments_lists_none(call, shop):
    ledger_entry(shop, EntryType.OFFLINE_ORDER, 900, NOV(2))
    assert payments(call, shop) == {"payments": [], "totalCount": 0}


def test_another_suppliers_or_an_unknown_account_is_not_found(call, other_supplier, shop):
    pay(shop, 100, NOV(2))
    theirs = call("GET", f"/api/ledger/accounts/{shop.id}/payments", as_=other_supplier)
    unknown = call("GET", "/api/ledger/accounts/9999/payments")
    assert (theirs.status_code, theirs.json) == (404, {"message": NOT_FOUND})
    assert unknown.status_code == 404


def test_listing_payments_needs_a_signed_in_supplier(call, shop):
    assert call("GET", f"/api/ledger/accounts/{shop.id}/payments", signed_in=False).status_code == 401


# -- PUT /ledger/entries/<id> ----------------------------------------------------------------------


def correction(**changes) -> dict:
    body = {"date": "2026-11-04", "amount": 350, "paymentMode": "Upi", "reference": "UPI-77", "collectedBy": "Ravi",
            "notes": "Recounted"}
    body.update(changes)
    return {key: value for key, value in body.items() if value is not MISSING}


def edit(call, entry, body, **kw):
    return call("PUT", f"/api/ledger/entries/{entry.id}", body, **kw)


@pytest.fixture
def last(shop, today) -> LedgerEntry:
    """The shop's last payment (300 cash on 3 Nov), after an older one."""
    pay(shop, 100, NOV(1))
    return pay(shop, 300, NOV(3), reference="R-1", collected_by="Mohan", notes="Counted at the shop")


def unchanged(entry: LedgerEntry) -> bool:
    entry = reloaded(entry)
    return (entry.amount, entry.entry_date, entry.payment_mode, entry.reference, entry.collected_by, entry.notes) == (
        D("300.00"), NOV(3), "Cash", "R-1", "Mohan", "Counted at the shop",
    )


def test_the_last_payment_takes_the_corrected_details(call, last):
    response = edit(call, last, correction(amount=350.005))

    assert response.status_code == 200, response.json
    assert response.json == {
        "id": last.id, "kind": "Payment", "date": "2026-11-04T00:00:00",
        "description": "Payment (UPI), collected by Ravi", "reference": "UPI-77", "paymentMode": "Upi",
        "collectedBy": "Ravi", "notes": "Recounted", "debit": 0, "credit": 350.01,  # rounded half up to paise
        "balance": None, "isVoided": False, "voidReason": "", "invoiceId": None, "canVoid": True,
    }
    saved = reloaded(last)
    assert (saved.entry_type, saved.amount, saved.entry_date, saved.payment_mode) == (
        EntryType.PAYMENT, D("350.01"), NOV(4), "Upi",
    )
    assert (saved.reference, saved.collected_by, saved.notes, saved.voided_at) == ("UPI-77", "Ravi", "Recounted", None)


def test_details_left_out_or_blank_are_cleared(call, last):
    response = edit(call, last, correction(reference="   ", collectedBy=MISSING, notes=""))

    assert response.status_code == 200, response.json
    assert (response.json["reference"], response.json["collectedBy"], response.json["notes"]) == ("", "", "")
    assert response.json["description"] == "Payment (UPI)"
    saved = reloaded(last)
    assert (saved.reference, saved.collected_by, saved.notes) == (None, None, None)


def test_a_payment_stays_a_payment(call, last):
    response = edit(call, last, correction(type="OfflineOrder", kind="OfflineOrder", entryType="OfflineOrder"))
    assert (response.status_code, response.json["kind"], response.json["debit"], response.json["credit"]) == (
        200, "Payment", 0, 350,
    )
    assert reloaded(last).entry_type == EntryType.PAYMENT


def test_balances_follow_the_corrected_payment(call, supplier, shop, last):
    ledger_entry(shop, EntryType.OFFLINE_ORDER, 1000, NOV(1))
    assert edit(call, last, correction(amount=350, date="2026-11-04")).status_code == 200

    account = totals(supplier.id)[shop.id]
    assert (account.payments, account.net) == (D(450), D(550))  # 100 + 350 paid against 1000
    assert last_payments(supplier.id)[shop.id] == (NOV(4), D(350))


def test_today_is_the_business_day_not_the_utc_day(call, last, today):
    # At 19:00 UTC on 4 Nov it is already 5 Nov in India, so the 5th is today and the 6th is in the future.
    assert edit(call, last, correction(date=today.isoformat())).status_code == 200
    tomorrow = edit(call, last, correction(date=(today + timedelta(days=1)).isoformat()))
    assert (tomorrow.status_code, tomorrow.json) == (400, {"message": "The date can't be in the future."})


@pytest.fixture
def book(shop, today) -> dict:
    """Entries of every kind; the last payment that counts is `last` (the voided one is newer)."""
    created = lambda hour: datetime(2026, 11, 3, hour, 0)  # noqa: E731
    return {
        "opening": ledger_entry(shop, EntryType.OPENING_BALANCE, 500, date(2026, 10, 30)),
        "order": ledger_entry(shop, EntryType.OFFLINE_ORDER, 1000, NOV(1)),
        "older": pay(shop, 100, NOV(2)),
        "same_day_earlier": pay(shop, 120, NOV(3), created_at=created(8)),
        "last": pay(shop, 150, NOV(3), created_at=created(9)),
        "voided_newer": pay(shop, 999, NOV(4), voided=True),
    }


@pytest.mark.parametrize(
    "target, message",
    [
        ("older", "Only the last payment can be edited."),
        ("same_day_earlier", "Only the last payment can be edited."),
        ("voided_newer", "Only the last payment can be edited."),
        ("opening", "Only payments can be edited."),
        ("order", "Only payments can be edited."),
    ],
)
def test_only_the_last_payment_that_counts_can_be_edited(call, book, target, message):
    entry = book[target]
    before = (reloaded(entry).amount, reloaded(entry).entry_date)

    response = edit(call, entry, correction())

    assert (response.status_code, response.json) == (400, {"message": message})
    assert (reloaded(entry).amount, reloaded(entry).entry_date) == before


def test_a_voided_newer_payment_does_not_stop_the_last_one_being_edited(call, book):
    assert edit(call, book["last"], correction()).status_code == 200


def test_the_last_payment_is_per_account(call, supplier, shop, today):
    mine = pay(shop, 100, NOV(1))
    pay(offline_account(supplier, "Another Shop"), 50, NOV(4))  # a newer payment, but another retailer's
    assert edit(call, mine, correction()).status_code == 200


@pytest.mark.parametrize(
    "changes, message",
    [
        ({"amount": 0}, "amount must be greater than 0."),
        ({"amount": -5}, "amount must be greater than 0."),
        ({"amount": 0.004}, "Amount must be greater than zero."),  # rounds to 0.00
        ({"amount": MISSING}, "amount is required."),
        ({"date": MISSING}, "date is required."),
        ({"date": "05/11/2026"}, "Enter a valid date."),
        ({"date": "2026-11-06"}, "The date can't be in the future."),  # checked after the amount is set
        ({"paymentMode": MISSING}, "paymentMode is required."),
        ({"reference": "R" * 65}, "reference can be at most 64 characters."),
        ({"collectedBy": "C" * 121}, "collectedBy can be at most 120 characters."),
        ({"notes": "N" * 1001}, "notes can be at most 1000 characters."),
    ],
)
def test_an_invalid_correction_is_explained_and_changes_nothing(call, last, changes, message):
    response = edit(call, last, correction(**changes))
    assert (response.status_code, response.json) == (400, {"message": message})
    assert unchanged(last)


@pytest.mark.parametrize(
    "changes, field",
    [({"amount": "10000000000.00"}, "amount"), ({"paymentMode": "Barter"}, "paymentMode"),
     ({"paymentMode": None}, "paymentMode"), ({"date": None}, "date")],
)
def test_out_of_range_values_name_the_field(call, last, changes, field):
    response = edit(call, last, correction(**changes))
    assert response.status_code == 400
    assert response.json["message"].startswith(f"{field}: ")
    assert unchanged(last)


def test_the_body_must_be_a_json_object(call, last):
    response = edit(call, last, [correction()])
    assert (response.status_code, response.json) == (400, {"message": "The request body must be a JSON object."})
    assert unchanged(last)


def test_another_suppliers_or_an_unknown_entry_is_not_found(call, other_supplier, last):
    theirs = edit(call, last, correction(), as_=other_supplier)
    unknown = call("PUT", "/api/ledger/entries/9999", correction())
    assert (theirs.status_code, theirs.json) == (404, {"message": NOT_FOUND})
    assert unknown.status_code == 404
    assert unchanged(last)


def test_editing_needs_a_signed_in_supplier(call, last):
    assert edit(call, last, correction(), signed_in=False).status_code == 401
    assert unchanged(last)
