"""Inventory and price-group endpoints (inventory/routes.py, pricing/routes.py) the API tests don't reach: searching
stock, adjusting a product that has no stock record yet, unknown price groups, an empty price grid and searching a
group's prices."""

from datetime import datetime

import pytest
from sqlalchemy import select

from supplier_service.common.errors import NOT_FOUND
from supplier_service.extensions.database import db
from supplier_service.inventory.models import InventoryTransaction, ReferenceType

from .factories import inventory_of, make_group, make_product, set_price, standard_group

# -- inventory -------------------------------------------------------------------------------------


def test_stock_can_be_searched_by_product_name_or_code(call, supplier, other_supplier):
    make_product(supplier, "COLA", name="Cola 500ml")
    make_product(supplier, "CHIPS", name="Potato Chips")
    make_product(supplier, "WATER", name="Mineral Water")
    make_product(other_supplier, "COLA2", name="Their Cola")

    def codes(term):
        return [i["productCode"] for i in call("GET", f"/api/inventory?search={term}").json["items"]]

    assert codes("chip") == ["CHIPS"]  # by name
    assert codes("wat") == ["WATER"]  # by code and name
    assert codes("COLA") == ["COLA"]  # never another supplier's
    assert codes("500") == ["COLA"]
    assert codes("nothing") == []


def test_adding_stock_to_a_product_without_a_stock_record_creates_one(call, supplier):
    item = make_product(supplier, "SHELF", stock=None)

    response = call("POST", f"/api/inventory/{item.id}/adjust", {"type": "StockAdded", "quantity": 5, "remarks": "Found"})

    assert response.status_code == 200, response.json
    assert (response.json["onHand"], response.json["reserved"], response.json["available"]) == (5, 0, 5)
    assert inventory_of(item).on_hand_quantity == 5
    [movement] = db.session.scalars(select(InventoryTransaction).filter_by(product_id=item.id))
    assert (movement.quantity, movement.reference_type, movement.remarks) == (5, ReferenceType.ADJUSTMENT, "Found")


def test_nothing_can_be_removed_from_a_product_without_a_stock_record(call, supplier):
    item = make_product(supplier, "SHELF", stock=None)

    response = call("POST", f"/api/inventory/{item.id}/adjust", {"type": "StockRemoved", "quantity": 1})

    assert (response.status_code, response.json) == (
        400, {"message": "Cannot remove 1; only 0 available (excluding reserved stock)."},
    )
    assert inventory_of(item) is None  # the empty record the request started isn't kept


# -- price groups ----------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "method, path, body",
    [
        ("PUT", "/api/pricegroups/{id}", {"name": "Renamed", "status": "Active"}),
        ("POST", "/api/pricegroups/{id}/deactivate", None),
        ("GET", "/api/pricegroups/{id}/prices", None),
        ("DELETE", "/api/pricegroups/{id}/prices/{product}", None),
    ],
)
def test_another_suppliers_or_an_unknown_price_group_is_not_found(call, supplier, other_supplier, method, path, body):
    product = make_product(supplier)
    theirs = make_group(other_supplier, "Their VIPs")
    for group_id in (theirs.id, 9999):
        response = call(method, path.format(id=group_id, product=product.id), body)
        assert (response.status_code, response.json) == (404, {"message": NOT_FOUND})
    assert db.session.get(type(theirs), theirs.id, populate_existing=True).group_name == "Their VIPs"


@pytest.mark.parametrize("query", ["", "?search=cola"])
def test_the_price_grid_is_empty_without_active_products(call, supplier, query):
    make_product(supplier, "OLD", active=False)
    assert call("GET", f"/api/pricegroups/matrix{query}").json == {"items": [], "totalCount": 0, "page": 1, "pageSize": 20}


def test_a_groups_prices_can_be_searched(call, supplier):
    group = standard_group(supplier)
    cola = make_product(supplier, "COLA", name="Cola 500ml")
    make_product(supplier, "CHIPS", name="Potato Chips")
    set_price(group, cola, "12.50", effective_from=datetime(2026, 10, 1))

    def search(term):
        return call("GET", f"/api/pricegroups/{group.id}/prices?search={term}").json

    found = search("cola")
    assert found["totalCount"] == 1
    assert found["items"] == [{
        "productId": cola.id, "productCode": "COLA", "productName": "Cola 500ml", "price": 12.5,
        "effectiveFrom": "2026-10-01T00:00:00", "effectiveTo": None,
    }]
    assert [(i["productCode"], i["price"]) for i in search("potato")["items"]] == [("CHIPS", None)]  # not priced yet
    assert search("nothing")["items"] == []
