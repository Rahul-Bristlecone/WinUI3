"""Catalogue endpoints (catalogue/routes.py) the API tests don't reach: editing categories and products, filtering
products by category, and image-upload failures. Rows are built directly; `call` is in conftest.py."""

from io import BytesIO

import pytest
from PIL import Image
from sqlalchemy.exc import IntegrityError

from supplier_service.catalogue.models import Category, Product
from supplier_service.catalogue.storage import get_storage
from supplier_service.common.errors import NOT_FOUND
from supplier_service.extensions.database import db

from .factories import inventory_of, make_category, make_product


def reloaded(model, row):
    return db.session.get(model, row.id, populate_existing=True)


def png(color="red") -> bytes:
    out = BytesIO()
    Image.new("RGB", (40, 30), color).save(out, "PNG")
    return out.getvalue()


# -- categories ------------------------------------------------------------------------------------


def test_a_category_can_be_renamed_moved_and_deactivated(call, supplier):
    drinks = make_category(supplier, "Drinks")
    juice = make_category(supplier, "Juice")

    response = call("PUT", f"/api/categories/{juice.id}",
                    {"name": "  Fruit Juices ", "parentCategoryId": drinks.id, "status": "Inactive"})

    assert response.status_code == 200, response.json
    assert response.json == {"id": juice.id, "name": "Fruit Juices", "parentCategoryId": drinks.id,
                             "parentCategoryName": "Drinks", "status": "Inactive"}
    saved = reloaded(Category, juice)
    assert (saved.category_name, saved.parent_category_id, saved.is_active) == ("Fruit Juices", drinks.id, False)


def test_a_subcategory_can_move_back_to_the_top(call, supplier):
    juice = make_category(supplier, "Juice", parent=make_category(supplier, "Drinks"))
    response = call("PUT", f"/api/categories/{juice.id}", {"name": "Juice", "parentCategoryId": None})
    assert (response.status_code, response.json["parentCategoryId"], response.json["parentCategoryName"]) == (200, None, None)


def test_a_category_keeps_its_own_name_but_cannot_take_anothers(call, supplier):
    juice = make_category(supplier, "Juice")
    make_category(supplier, "Snacks")

    assert call("PUT", f"/api/categories/{juice.id}", {"name": "JUICE"}).status_code == 200  # its own, in new case
    clash = call("PUT", f"/api/categories/{juice.id}", {"name": "snacks"})
    assert (clash.status_code, clash.json) == (409, {"message": "A category with this name already exists."})
    assert reloaded(Category, juice).category_name == "JUICE"


def test_the_parent_must_be_one_of_the_suppliers_categories(call, supplier, other_supplier):
    juice = make_category(supplier, "Juice")
    theirs = make_category(other_supplier, "Drinks")
    for parent_id in (9999, theirs.id):
        response = call("PUT", f"/api/categories/{juice.id}", {"name": "Juice", "parentCategoryId": parent_id})
        assert (response.status_code, response.json) == (400, {"message": "Parent category not found."})


@pytest.mark.parametrize("parent", ["itself", "grandchild"])
def test_a_category_cannot_sit_under_itself_or_below(call, supplier, parent):
    drinks = make_category(supplier, "Drinks")
    juice = make_category(supplier, "Juice", parent=drinks)
    fresh = make_category(supplier, "Fresh Juice", parent=juice)
    target = drinks if parent == "itself" else fresh

    response = call("PUT", f"/api/categories/{drinks.id}", {"name": "Drinks", "parentCategoryId": target.id})
    assert (response.status_code, response.json) == (
        400, {"message": "A category cannot be its own parent or sit under one of its subcategories."},
    )
    assert reloaded(Category, drinks).parent_category_id is None


@pytest.mark.parametrize("method, path, body", [
    ("PUT", "/api/categories/{id}", {"name": "Mine now"}),
    ("POST", "/api/categories/{id}/deactivate", None),
])
def test_another_suppliers_or_an_unknown_category_is_not_found(call, other_supplier, method, path, body):
    theirs = make_category(other_supplier, "Drinks")
    for category_id in (theirs.id, 9999):
        response = call(method, path.format(id=category_id), body)
        assert (response.status_code, response.json) == (404, {"message": NOT_FOUND})
    assert reloaded(Category, theirs).category_name == "Drinks"


def test_categories_are_listed_by_name_without_a_search(call, supplier, other_supplier):
    for name in ("Snacks", "Beverages", "Dairy"):
        make_category(supplier, name)
    make_category(other_supplier, "Not Ours")

    page = call("GET", "/api/categories").json
    assert [c["name"] for c in page["items"]] == ["Beverages", "Dairy", "Snacks"]
    assert page["totalCount"] == 3


# -- products --------------------------------------------------------------------------------------


@pytest.fixture
def cola(supplier):
    return make_product(supplier, "COLA", name="Cola", stock=40, category=make_category(supplier, "Drinks"),
                        barcode="8901000000017")


def product_body(**changes) -> dict:
    return {"productCode": "COLA", "name": "Cola", "categoryId": None, "unitOfMeasure": "pcs",
            "barcode": "8901000000017", "status": "Active"} | changes


def test_a_product_can_be_edited(call, supplier, cola):
    snacks = make_category(supplier, "Snacks")
    response = call("PUT", f"/api/products/{cola.id}", product_body(
        productCode="cola-500", name="Cola 500 ml", description="Chilled", categoryId=snacks.id,
        unitOfMeasure="Bottle", barcode="8901000000024", status="Inactive", initialStock=999,
    ))

    assert response.status_code == 200, response.json
    assert response.json == {
        "id": cola.id, "productCode": "COLA-500", "name": "Cola 500 ml", "description": "Chilled",
        "categoryId": snacks.id, "categoryName": "Snacks", "unitOfMeasure": "Bottle", "barcode": "8901000000024",
        "currentStock": 40, "status": "Inactive", "imageUrl": None, "thumbnailUrl": None,
    }
    saved = reloaded(Product, cola)
    assert (saved.product_code, saved.category_id, saved.is_active) == ("COLA-500", snacks.id, False)
    assert inventory_of(cola).on_hand_quantity == 40  # initialStock only counts when the product is created


def test_saving_a_product_unchanged_keeps_its_own_code_and_barcode(call, cola):
    response = call("PUT", f"/api/products/{cola.id}", product_body(categoryId=cola.category_id, productCode="cola"))
    assert response.status_code == 200, response.json


def test_an_edit_cannot_take_another_products_code_or_barcode(call, supplier, cola):
    make_product(supplier, "WATER", barcode="8901000000031")
    url, category = f"/api/products/{cola.id}", cola.category_id

    code = call("PUT", url, product_body(categoryId=category, productCode="water"))
    barcode = call("PUT", url, product_body(categoryId=category, barcode="8901000000031"))
    assert (code.status_code, code.json) == (409, {"message": "Product code 'WATER' already exists."})
    assert (barcode.status_code, barcode.json) == (409, {"message": "Barcode '8901000000031' is already in use."})
    assert (reloaded(Product, cola).product_code, reloaded(Product, cola).barcode) == ("COLA", "8901000000017")


def test_an_edited_product_needs_one_of_the_suppliers_categories(call, other_supplier, cola):
    theirs = make_category(other_supplier, "Drinks")
    response = call("PUT", f"/api/products/{cola.id}", product_body(categoryId=theirs.id))
    assert (response.status_code, response.json) == (400, {"message": "Category not found."})


def test_editing_an_unknown_product_is_not_found(call, cola):
    response = call("PUT", "/api/products/9999", product_body(categoryId=cola.category_id))
    assert response.status_code == 404


def test_products_can_be_filtered_by_category(call, supplier, cola):
    snacks = make_category(supplier, "Snacks")
    make_product(supplier, "CHIPS", category=snacks)
    make_product(supplier, "LOOSE")  # no category

    def codes(query):
        return [p["productCode"] for p in call("GET", f"/api/products?{query}").json["items"]]

    assert codes(f"categoryId={snacks.id}") == ["CHIPS"]
    assert codes(f"categoryId={cola.category_id}") == ["COLA"]
    assert codes("categoryId=9999") == []
    assert codes("") == ["CHIPS", "COLA", "LOOSE"]


# -- image upload ----------------------------------------------------------------------------------


def stored_files() -> list[str]:
    folder = get_storage().folder
    return sorted(p.name for p in folder.iterdir()) if folder.exists() else []


@pytest.mark.parametrize("data", [{}, {"other": (BytesIO(b"x"), "photo.png")}, {"file": (BytesIO(png()), "")}],
                         ids=["no file", "wrong field", "no file name"])
def test_an_upload_needs_a_file(call, cola, data):
    response = call("POST", f"/api/products/{cola.id}/image", data=data, content_type="multipart/form-data")
    assert (response.status_code, response.json) == (400, {"message": "An image file is required (multipart field 'file')."})
    assert stored_files() == []


def test_a_failed_save_removes_the_new_files_and_keeps_the_old_image(call, cola, monkeypatch):
    url = f"/api/products/{cola.id}/image"
    assert call("POST", url, data={"file": (BytesIO(png()), "first.png")}).status_code == 200
    old_name, old_files = reloaded(Product, cola).image_filename, stored_files()
    assert len(old_files) == 2  # the original and its thumbnail

    def lost_race():
        raise IntegrityError("UPDATE products", {}, Exception("another request changed this product"))

    monkeypatch.setattr(db.session, "commit", lost_race)
    response = call("POST", url, data={"file": (BytesIO(png("blue")), "second.png")})

    assert response.status_code == 409
    assert stored_files() == old_files  # the second upload's files were removed again
    assert reloaded(Product, cola).image_filename == old_name
