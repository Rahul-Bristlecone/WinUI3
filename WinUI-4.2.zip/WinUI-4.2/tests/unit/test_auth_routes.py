"""Auth endpoints (auth/routes.py) the API tests don't reach: a deactivated supplier signing in, a new password equal
to the current one, and supplier codes for a third (or later) same-day registration."""

from datetime import datetime, timezone

import pytest
from sqlalchemy import func, select

from supplier_service.auth import models as auth_models
from supplier_service.auth.models import Supplier, SupplierSession
from supplier_service.auth.routes import _unique_supplier_code
from supplier_service.extensions.database import db

from .factories import make_supplier

PASSWORD = "Password@123"


def with_password(supplier: Supplier, *, active: bool = True) -> Supplier:
    supplier.set_password(PASSWORD)
    supplier.is_active = active
    db.session.commit()
    return supplier


def sessions_started() -> int:
    return db.session.scalar(select(func.count(SupplierSession.id)))


def test_a_deactivated_supplier_cannot_sign_in(call, supplier):
    with_password(supplier, active=False)

    response = call("POST", "/api/auth/login", {"email": supplier.email, "password": PASSWORD}, signed_in=False)

    assert (response.status_code, response.json) == (403, {"message": "This supplier account has been deactivated."})
    assert sessions_started() == 0


def test_a_wrong_password_does_not_reveal_that_an_account_is_deactivated(call, supplier):
    with_password(supplier, active=False)
    response = call("POST", "/api/auth/login", {"email": supplier.email, "password": "Wrong@1234"}, signed_in=False)
    assert (response.status_code, response.json) == (401, {"message": "Invalid email or password."})


def test_a_new_password_must_differ_from_the_current_one(call, supplier):
    with_password(supplier)

    response = call("POST", "/api/auth/change-password", {"currentPassword": PASSWORD, "newPassword": PASSWORD})

    assert (response.status_code, response.json) == (400, {"message": "New password must differ from the current password."})
    assert db.session.get(Supplier, supplier.id, populate_existing=True).check_password(PASSWORD)


# -- supplier codes --------------------------------------------------------------------------------

BASE = "GDP-ACME-20261103"


@pytest.fixture
def on_3_november(monkeypatch):
    class FixedClock(datetime):
        @classmethod
        def now(cls, tz=None):
            return datetime(2026, 11, 3, 12, 0, tzinfo=timezone.utc).astimezone(tz)

    monkeypatch.setattr(auth_models, "datetime", FixedClock)


def test_the_first_registration_of_the_day_gets_the_plain_code(app, on_3_november):
    make_supplier(code="GDP-ACME-20261102")  # yesterday's doesn't count
    assert _unique_supplier_code("Acme Traders") == BASE


def test_later_same_day_registrations_count_up(app, on_3_november):
    make_supplier(code=BASE)
    make_supplier(code=f"{BASE}-2")
    # "Acme Corp" shares the ACME prefix, so it shares the day's sequence.
    assert _unique_supplier_code("Acme Corp") == f"{BASE}-3"


def test_a_free_suffix_is_reused(app, on_3_november):
    make_supplier(code=BASE)
    make_supplier(code=f"{BASE}-3")
    assert _unique_supplier_code("acme") == f"{BASE}-2"
