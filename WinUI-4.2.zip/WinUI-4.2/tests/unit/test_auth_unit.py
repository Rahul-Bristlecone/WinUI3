"""auth/models.py (supplier codes, passwords) and auth/schemas.py (registration and profile rules)."""

from datetime import datetime, timezone

import pytest

from supplier_service import models  # noqa: F401  (configures every mapper before models are built)
from supplier_service.auth import models as auth_models
from supplier_service.auth.models import Supplier
from supplier_service.auth.schemas import (
    PASSWORD_MESSAGE,
    ChangePasswordRequest,
    LoginRequest,
    ProfileRequest,
    RegisterRequest,
    profile_json,
)

from .factories import validation_message

# -- supplier codes --------------------------------------------------------------------------------


@pytest.fixture
def on_3_november(monkeypatch):
    class FixedClock(datetime):
        @classmethod
        def now(cls, tz=None):
            return datetime(2026, 11, 3, 23, 59, tzinfo=timezone.utc).astimezone(tz)

    monkeypatch.setattr(auth_models, "datetime", FixedClock)


@pytest.mark.parametrize(
    "company, code",
    [
        ("Acme Traders", "GDP-ACME-20261103"),
        ("zeta corp", "GDP-ZETA-20261103"),
        ("3M India", "GDP-3MIN-20261103"),
        ("A.B. & Co", "GDP-ABCO-20261103"),
        ("Q", "GDP-QXXX-20261103"),
        ("J&K", "GDP-JKXX-20261103"),
        ("", "GDP-GDP-20261103"),
        ("  !!! ", "GDP-GDP-20261103"),
        (None, "GDP-GDP-20261103"),
    ],
)
def test_supplier_codes_use_the_first_four_letters_and_the_utc_day(on_3_november, company, code):
    assert Supplier.generate_supplier_code(company) == code


def test_supplier_codes_fit_their_column_with_room_for_a_suffix(on_3_november):
    # Registration appends "-2", "-3", ... to same-day repeats; the column is String(32).
    assert len(Supplier.generate_supplier_code("A Very Long Company Name Pvt Ltd") + "-999") <= 32


# -- passwords -------------------------------------------------------------------------------------


def test_passwords_are_stored_hashed_and_checked():
    supplier = Supplier()
    supplier.set_password("Password@123")
    assert "Password@123" not in supplier.password_hash
    assert supplier.check_password("Password@123")
    assert not supplier.check_password("password@123")
    assert not supplier.check_password("")


# -- registration and profile ----------------------------------------------------------------------


def registration(**changes) -> dict:
    payload = {
        "companyName": "Acme Traders", "contactPerson": "Asha Verma", "email": "asha@example.com",
        "password": "Password1", "phone": "+91 98765 43210", "address": "42 Industrial Estate", "city": "Pune",
        "state": "Maharashtra", "country": "India", "postalCode": "411001", "gstNumber": None,
    }
    return payload | changes


def test_a_valid_registration_is_tidied():
    body = RegisterRequest.model_validate(registration(
        companyName="  Acme Traders ", email="Asha@Example.COM", gstNumber="27abcde1234f1z5",
    ))
    assert body.company_name == "Acme Traders"
    assert body.email == "asha@example.com"
    assert body.gst_number == "27ABCDE1234F1Z5"


@pytest.mark.parametrize("password", ["password1", "PASSWORD1", "Password", "Pass1", "Pa ss1"])
def test_passwords_need_eight_characters_with_upper_lower_and_digit(password):
    assert validation_message(RegisterRequest, registration(password=password)) == PASSWORD_MESSAGE


def test_password_length_is_capped():
    assert validation_message(RegisterRequest, registration(password="Aa1" * 50)) == (
        "password can be at most 128 characters."
    )


@pytest.mark.parametrize("email", ["asha", "asha@example", "asha @example.com", "@example.com"])
def test_registration_needs_a_valid_email(email):
    assert validation_message(RegisterRequest, registration(email=email)) == "Enter a valid email address."


@pytest.mark.parametrize("gst", [None, "", "   "])
def test_gst_number_is_optional(gst):
    assert RegisterRequest.model_validate(registration(gstNumber=gst)).gst_number is None


@pytest.mark.parametrize("gst", ["27ABCDE1234F1Z", "27ABCDE1234F0Z5", "AAABCDE1234F1Z5", "27ABCDE1234F1X5"])
def test_gst_numbers_must_be_a_valid_gstin(gst):
    assert validation_message(RegisterRequest, registration(gstNumber=gst)) == (
        "Enter a valid 15-character GSTIN (e.g. 27ABCDE1234F1Z5)."
    )


@pytest.mark.parametrize("phone, valid", [("+91 (22) 1234-5678", True), ("1234567", True), ("123456", False),
                                          ("call me", False), ("+91 98765 43210 ext 5", False)])
def test_phone_numbers(phone, valid):
    if valid:
        assert ProfileRequest.model_validate(registration(phone=phone)).phone == phone
    else:
        assert validation_message(ProfileRequest, registration(phone=phone)) == "Enter a valid phone number."


@pytest.mark.parametrize("postal, valid", [("411001", True), ("SW1A 1AA", True), ("K1A-0B1", True),
                                           ("41", False), ("411001-12345", False), ("4110#1", False)])
def test_postal_codes(postal, valid):
    if valid:
        assert ProfileRequest.model_validate(registration(postalCode=postal)).postal_code == postal
    else:
        assert validation_message(ProfileRequest, registration(postalCode=postal)) == "Enter a valid postal code."


@pytest.mark.parametrize("field", ["companyName", "contactPerson", "phone", "address", "city", "state", "country", "postalCode"])
def test_profile_fields_are_required(field):
    assert validation_message(ProfileRequest, registration(**{field: "   "})) == f"{field} is required."


def test_apply_to_copies_the_profile_onto_the_supplier():
    supplier = Supplier(email="asha@example.com")
    ProfileRequest.model_validate(registration(city="Mumbai", gstNumber="27abcde1234f1z5")).apply_to(supplier)
    assert (supplier.company_name, supplier.city, supplier.gst_number) == ("Acme Traders", "Mumbai", "27ABCDE1234F1Z5")
    assert supplier.email == "asha@example.com"  # the profile can't change the sign-in email


def test_profile_json_sends_a_missing_gst_number_as_empty():
    supplier = Supplier(id=4, supplier_code="GDP-ACME-20261103", email="a@example.com", gst_number=None)
    payload = profile_json(supplier)
    assert payload["gstNumber"] == ""
    assert payload["supplierCode"] == "GDP-ACME-20261103"
    assert "password" not in str(payload).lower()


# -- sign in and password change -------------------------------------------------------------------


def test_login_email_is_trimmed_and_lower_cased_but_not_format_checked():
    assert LoginRequest.model_validate({"email": "  Asha@Example.COM ", "password": "x"}).email == "asha@example.com"
    assert LoginRequest.model_validate({"email": "legacy-user", "password": "x"}).email == "legacy-user"


def test_login_needs_both_fields():
    assert validation_message(LoginRequest, {"password": "x"}) == "email is required."
    assert validation_message(LoginRequest, {"email": "a@b.co", "password": ""}) == "password is required."


def test_a_new_password_must_follow_the_rules():
    assert validation_message(ChangePasswordRequest, {"currentPassword": "Old12345", "newPassword": "weak"}) == (
        PASSWORD_MESSAGE
    )
    assert validation_message(ChangePasswordRequest, {"currentPassword": "", "newPassword": "Password1"}) == (
        "currentPassword is required."
    )
