"""auth/sessions.py: sign-in sessions, refresh token rotation, reuse detection and revocation."""

from datetime import timedelta

import pytest

from supplier_service.auth import sessions
from supplier_service.auth.models import SupplierSession
from supplier_service.auth.sessions import (
    REVOKED_PASSWORD_CHANGE,
    REVOKED_REUSE,
    REVOKED_SIGN_OUT,
    end_session,
    refresh_session,
    refresh_token,
    revoke_other_sessions,
    start_session,
)
from supplier_service.common.errors import ApiError
from supplier_service.common.security import SESSION_EXPIRED
from supplier_service.extensions.database import db

from .factories import make_supplier


@pytest.fixture
def session_lengths(app, monkeypatch):
    """Pins the session settings, whatever the environment says."""
    monkeypatch.setitem(app.config, "REFRESH_IDLE", timedelta(days=7))
    monkeypatch.setitem(app.config, "REFRESH_MAX", timedelta(days=30))
    monkeypatch.setitem(app.config, "REFRESH_REUSE_GRACE", timedelta(seconds=30))


def signed_in(supplier) -> SupplierSession:
    session = start_session(supplier)
    db.session.commit()
    return session


def reloaded(session: SupplierSession) -> SupplierSession:
    """The row as committed (drops anything only in this session's memory)."""
    db.session.rollback()
    db.session.expire_all()
    return db.session.get(SupplierSession, session.id)


def shift(session: SupplierSession, **delta) -> None:
    """Moves the session's timestamps into the past, as if `delta` had gone by."""
    gone = timedelta(**delta)
    session.created_at -= gone
    session.token_issued_at -= gone
    session.expires_at -= gone
    db.session.commit()


def rejected(token: str) -> ApiError:
    with pytest.raises(ApiError) as caught:
        refresh_session(token)
    assert (caught.value.status, caught.value.message) == (401, SESSION_EXPIRED)
    return caught.value


# -- start_session ---------------------------------------------------------------------------------


def test_a_new_session_lasts_the_idle_period(session_lengths, supplier):
    session = signed_in(supplier)
    assert session.generation == 0
    assert session.expires_at - session.created_at == timedelta(days=7)
    assert session.token_issued_at == session.created_at
    assert session.revoked_at is None


def test_the_idle_period_is_capped_by_the_maximum(app, session_lengths, supplier, monkeypatch):
    monkeypatch.setitem(app.config, "REFRESH_MAX", timedelta(days=2))
    session = signed_in(supplier)
    assert session.expires_at - session.created_at == timedelta(days=2)


def test_sessions_have_random_public_ids(session_lengths, supplier):
    first, second = signed_in(supplier), signed_in(supplier)
    assert first.public_id != second.public_id
    assert len(first.public_id) >= 22  # 128 random bits


def test_signing_in_deletes_the_suppliers_ended_sessions(session_lengths, supplier, other_supplier):
    live, revoked, expired = signed_in(supplier), signed_in(supplier), signed_in(supplier)
    others_revoked = signed_in(other_supplier)
    end_session(refresh_token(revoked))
    end_session(refresh_token(others_revoked))
    db.session.commit()
    shift(expired, days=8)
    kept, deleted = {live.id, others_revoked.id}, {revoked.id, expired.id}

    signed_in(supplier)
    remaining = set(db.session.scalars(db.select(SupplierSession.id)))
    assert kept <= remaining and not deleted & remaining


# -- refresh tokens --------------------------------------------------------------------------------


def test_a_refresh_token_names_the_session_and_generation(session_lengths, supplier):
    session = signed_in(supplier)
    public_id, generation, signature = refresh_token(session).split(".")
    assert (public_id, generation) == (session.public_id, "0")
    assert len(signature) == 43  # HMAC-SHA256, base64url without padding


@pytest.mark.parametrize(
    "tamper",
    [
        pytest.param(lambda t: "", id="empty"),
        pytest.param(lambda t: "not-a-token", id="garbage"),
        pytest.param(lambda t: t[:-1] + ("A" if t[-1] != "A" else "B"), id="signature changed"),
        pytest.param(lambda t: t.replace(".0.", ".1.", 1), id="generation changed"),
        pytest.param(lambda t: "x" + t, id="public id changed"),
        pytest.param(lambda t: t + ".extra", id="extra part"),
        pytest.param(lambda t: t.replace(".0.", ".٠.", 1), id="non-ascii digit"),
    ],
)
def test_a_token_that_was_not_issued_as_is_is_rejected(session_lengths, supplier, tamper):
    session = signed_in(supplier)
    rejected(tamper(refresh_token(session)))
    assert reloaded(session).revoked_at is None  # forgeries can't revoke anyone's session


def test_a_token_signed_with_another_key_is_rejected(app, session_lengths, supplier, monkeypatch):
    session = signed_in(supplier)
    token = refresh_token(session)
    monkeypatch.setitem(app.config, "JWT_SECRET_KEY", "another-secret-key-0123456789-abcdefghij")
    rejected(token)


# -- refresh_session -------------------------------------------------------------------------------


def test_refreshing_rotates_the_token_and_extends_the_session(session_lengths, supplier):
    session = signed_in(supplier)
    shift(session, days=3)
    old_token = refresh_token(session)

    rotated = refresh_session(old_token)
    db.session.commit()
    assert rotated.id == session.id
    assert rotated.generation == 1
    assert refresh_token(rotated) != old_token
    assert rotated.expires_at - rotated.token_issued_at == timedelta(days=7)  # idle period starts again


def test_refreshing_never_extends_past_the_maximum(session_lengths, supplier):
    session = signed_in(supplier)
    session.created_at -= timedelta(days=27)  # signed in 27 days ago, refreshed regularly since
    db.session.commit()
    rotated = refresh_session(refresh_token(session))
    assert rotated.expires_at == rotated.created_at + timedelta(days=30)


def test_the_newest_token_keeps_working(session_lengths, supplier):
    session = signed_in(supplier)
    for generation in range(1, 4):
        session = refresh_session(refresh_token(session))
        db.session.commit()
        assert session.generation == generation


def test_an_expired_session_cannot_be_refreshed(session_lengths, supplier):
    session = signed_in(supplier)
    shift(session, days=7)
    rejected(refresh_token(session))


def test_a_revoked_session_cannot_be_refreshed(session_lengths, supplier):
    session = signed_in(supplier)
    end_session(refresh_token(session))
    db.session.commit()
    rejected(refresh_token(session))


def test_a_deactivated_supplier_cannot_refresh(session_lengths):
    supplier = make_supplier()
    session = signed_in(supplier)
    supplier.is_active = False
    db.session.commit()
    rejected(refresh_token(session))


def test_a_token_for_a_deleted_session_is_rejected(session_lengths, supplier):
    session = signed_in(supplier)
    token = refresh_token(session)
    db.session.delete(session)
    db.session.commit()
    rejected(token)


def test_a_racing_refresh_gets_the_same_new_token(session_lengths, supplier):
    session = signed_in(supplier)
    token = refresh_token(session)
    first = refresh_token(refresh_session(token))
    db.session.commit()

    second = refresh_session(token)  # same token again, within the grace period
    db.session.commit()
    assert refresh_token(second) == first
    assert second.generation == 1 and second.revoked_at is None


def test_reusing_a_replaced_token_revokes_the_session(session_lengths, supplier):
    session = signed_in(supplier)
    stale = refresh_token(session)
    newest = refresh_token(refresh_session(stale))
    db.session.commit()
    shift(session, seconds=31)  # past the grace period

    rejected(stale)
    row = reloaded(session)  # committed even though the request failed
    assert row.revoked_reason == REVOKED_REUSE and row.revoked_at is not None
    rejected(newest)  # whoever held the newest token is signed out too


def test_an_older_generation_is_reuse_even_within_the_grace_period(session_lengths, supplier):
    session = signed_in(supplier)
    oldest = refresh_token(session)
    session = refresh_session(oldest)
    session = refresh_session(refresh_token(session))
    db.session.commit()
    assert session.generation == 2

    rejected(oldest)
    assert reloaded(session).revoked_reason == REVOKED_REUSE


def test_reuse_is_logged(session_lengths, supplier, caplog):
    session = signed_in(supplier)
    stale = refresh_token(session)
    refresh_session(stale)
    db.session.commit()
    shift(session, minutes=1)
    rejected(stale)
    assert f"session {session.id} of supplier {supplier.id} revoked" in caplog.text


# -- end_session -----------------------------------------------------------------------------------


def test_signing_out_revokes_the_session(session_lengths, supplier):
    session = signed_in(supplier)
    end_session(refresh_token(session))
    db.session.commit()
    row = reloaded(session)
    assert row.revoked_reason == REVOKED_SIGN_OUT and row.revoked_at is not None


def test_signing_out_works_with_any_generation_of_the_token(session_lengths, supplier):
    session = signed_in(supplier)
    stale = refresh_token(session)
    refresh_session(stale)
    db.session.commit()
    end_session(stale)
    db.session.commit()
    assert reloaded(session).revoked_reason == REVOKED_SIGN_OUT


def test_signing_out_of_a_revoked_session_keeps_its_reason(session_lengths, supplier):
    session = signed_in(supplier)
    revoke_other_sessions(supplier, keep=None, reason=REVOKED_PASSWORD_CHANGE)
    db.session.commit()
    end_session(refresh_token(session))
    db.session.commit()
    assert reloaded(session).revoked_reason == REVOKED_PASSWORD_CHANGE


def test_signing_out_with_an_invalid_token_does_nothing(session_lengths, supplier):
    session = signed_in(supplier)
    end_session("not-a-token")
    end_session(refresh_token(session).rpartition(".")[0] + "." + "A" * 43)  # right shape, wrong signature
    db.session.commit()
    assert reloaded(session).revoked_at is None


# -- revoke_other_sessions -------------------------------------------------------------------------


def test_revoking_other_sessions_keeps_the_given_one(session_lengths, supplier, other_supplier):
    current, other = signed_in(supplier), signed_in(supplier)
    someone_else = signed_in(other_supplier)

    revoke_other_sessions(supplier, keep=current.public_id, reason=REVOKED_PASSWORD_CHANGE)
    db.session.commit()
    assert reloaded(current).revoked_at is None
    assert reloaded(other).revoked_reason == REVOKED_PASSWORD_CHANGE
    assert reloaded(someone_else).revoked_at is None


def test_revoking_with_nothing_to_keep_revokes_every_session(session_lengths, supplier):
    first, second = signed_in(supplier), signed_in(supplier)
    revoke_other_sessions(supplier, keep=None, reason=REVOKED_PASSWORD_CHANGE)
    db.session.commit()
    assert reloaded(first).revoked_at is not None and reloaded(second).revoked_at is not None


def test_timestamps_are_naive_utc(session_lengths, supplier):
    # The columns are "timestamp without time zone"; mixing aware and naive values would fail comparisons.
    session = signed_in(supplier)
    assert session.created_at.tzinfo is None and session.expires_at.tzinfo is None
    assert sessions._now().tzinfo is None
