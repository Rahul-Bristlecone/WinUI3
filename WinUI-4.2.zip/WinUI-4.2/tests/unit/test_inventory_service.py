"""inventory/service.py: every change to stock, and the invariant that the transaction log sums to on-hand."""

from sqlalchemy import select

from supplier_service.extensions.database import db
from supplier_service.inventory.models import InventoryTransaction, ReferenceType, TransactionType
from supplier_service.inventory.service import lock_inventory, new_inventory, record_movement, release, reserve

from .factories import inventory_of, make_product


def quantities(inventory) -> tuple[int, int, int]:
    return inventory.on_hand_quantity, inventory.reserved_quantity, inventory.available_quantity


def logged_balance(product) -> int:
    """On-hand stock according to the transaction log."""
    rows = db.session.scalars(select(InventoryTransaction).filter_by(product_id=product.id))
    return sum(t.quantity if t.transaction_type == TransactionType.STOCK_ADDED else -t.quantity for t in rows)


def test_new_inventory_starts_empty():
    inventory = new_inventory(5)
    assert inventory.product_id == 5
    assert quantities(inventory) == (0, 0, 0)


def test_adding_stock_raises_on_hand_and_available(supplier):
    product = make_product(supplier, stock=10)
    inventory = inventory_of(product)

    transaction = record_movement(
        inventory, TransactionType.STOCK_ADDED, 5, reference_type=ReferenceType.ADJUSTMENT,
        reference_id="ADJ-1", remarks="Recount",
    )
    db.session.commit()

    assert quantities(inventory) == (15, 0, 15)
    assert (transaction.product_id, transaction.transaction_type, transaction.quantity) == (
        product.id, TransactionType.STOCK_ADDED, 5,
    )
    assert (transaction.reference_type, transaction.reference_id, transaction.remarks) == ("adjustment", "ADJ-1", "Recount")
    assert transaction.id is not None  # added to the session by record_movement


def test_removing_stock_logs_a_positive_quantity(supplier):
    product = make_product(supplier, stock=10)
    inventory = inventory_of(product)

    transaction = record_movement(inventory, TransactionType.STOCK_REMOVED, 4, reference_type=ReferenceType.INVOICE)
    db.session.commit()

    assert quantities(inventory) == (6, 0, 6)
    assert transaction.quantity == 4  # the type carries the direction


def test_available_stock_excludes_reservations(supplier):
    inventory = inventory_of(make_product(supplier, stock=10))
    reserve(inventory, 3)
    assert quantities(inventory) == (10, 3, 7)

    record_movement(inventory, TransactionType.STOCK_ADDED, 5, reference_type=ReferenceType.ADJUSTMENT)
    assert quantities(inventory) == (15, 3, 12)

    reserve(inventory, 12)
    assert quantities(inventory) == (15, 15, 0)


def test_releasing_more_than_is_reserved_stops_at_zero(supplier):
    inventory = inventory_of(make_product(supplier, stock=10))
    reserve(inventory, 3)
    release(inventory, 2)
    assert quantities(inventory) == (10, 1, 9)
    release(inventory, 5)
    assert quantities(inventory) == (10, 0, 10)


def test_the_transaction_log_always_adds_up_to_on_hand(supplier):
    product = make_product(supplier, stock=40)
    inventory = inventory_of(product)
    for transaction_type, quantity in [
        (TransactionType.STOCK_REMOVED, 15), (TransactionType.STOCK_ADDED, 7), (TransactionType.STOCK_REMOVED, 2),
    ]:
        record_movement(inventory, transaction_type, quantity, reference_type=ReferenceType.ADJUSTMENT)
    reserve(inventory, 5)  # reservations aren't movements
    db.session.commit()

    assert inventory.on_hand_quantity == 30
    assert logged_balance(product) == 30


# -- lock_inventory --------------------------------------------------------------------------------


def test_lock_inventory_with_no_products_is_empty(app):
    assert lock_inventory([]) == {}
    assert lock_inventory(iter(())) == {}


def test_lock_inventory_maps_product_ids_in_product_order(supplier):
    cola, chips, water = (make_product(supplier, code) for code in ("COLA", "CHIPS", "WATER"))
    no_stock_row = make_product(supplier, "NOINV", stock=None)

    locked = lock_inventory(p.id for p in (water, cola, water, no_stock_row, chips))

    assert list(locked) == sorted([cola.id, chips.id, water.id])  # deduplicated; products without a row are left out
    assert all(locked[pid].product_id == pid for pid in locked)


def test_lock_inventory_ignores_unknown_ids(supplier):
    cola = make_product(supplier)
    assert list(lock_inventory([cola.id, 9999])) == [cola.id]
