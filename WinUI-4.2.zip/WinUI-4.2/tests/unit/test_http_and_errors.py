"""common/http.py (request parsing, paging, wire formatting) and common/errors.py (error responses)."""

import logging
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

import pytest
from flask import abort, request
from pydantic import Field, ValidationError
from sqlalchemy import func, select

from conftest import _prepare_database  # tests/conftest.py
from supplier_service import create_app
from supplier_service.auth.models import Supplier
from supplier_service.catalogue.models import Product
from supplier_service.common.errors import NOT_FOUND, ApiError, not_found
from supplier_service.common.http import (
    CalendarDate,
    OptionalText,
    Quantity,
    RequestSchema,
    Text,
    _describe,
    contains,
    iso_calendar_date,
    iso_timestamp,
    paginate,
    paginate_list,
    parse_body,
    query_date,
    record_status,
    search_term,
    sort_descending,
)
from supplier_service.extensions.database import db

from .factories import JWT_SECRET, make_product

IST = timezone(timedelta(hours=5, minutes=30))


class Sample(RequestSchema):
    name: Text = Field(min_length=1, max_length=5)
    page_size: int = 20
    note: OptionalText = None
    quantity: Quantity = 0
    day: CalendarDate | None = None
    amount: Decimal = Field(default=Decimal("1"), gt=0)
    code: Text = Field(default="AB", min_length=2)


def describe(payload: dict, schema=Sample) -> str:
    with pytest.raises(ValidationError) as caught:
        schema.model_validate(payload)
    return _describe(caught.value)


# -- request schemas -------------------------------------------------------------------------------


def test_request_fields_are_camel_case_on_the_wire_and_snake_case_in_python():
    assert Sample.model_validate({"name": "a", "pageSize": 50}).page_size == 50
    assert Sample.model_validate({"name": "a", "page_size": 50}).page_size == 50


def test_unknown_request_fields_are_ignored():
    assert not hasattr(Sample.model_validate({"name": "a", "isAdmin": True}), "is_admin")


def test_text_is_trimmed_and_blank_optional_text_is_none():
    body = Sample.model_validate({"name": "  Cola  ", "note": "   "})
    assert body.name == "Cola" and body.note is None
    assert Sample.model_validate({"name": "a", "note": "  hi "}).note == "hi"


@pytest.mark.parametrize("value", [5, 5.0, "5", "5.00", Decimal("5")])
def test_quantities_accept_whole_numbers_in_any_form(value):
    quantity = Sample.model_validate({"name": "a", "quantity": value}).quantity
    assert quantity == 5 and type(quantity) is int


@pytest.mark.parametrize("value", [5.5, "2.25", Decimal("0.1")])
def test_quantities_reject_fractions(value):
    assert describe({"name": "a", "quantity": value}) == "Quantity must be a whole number."


@pytest.mark.parametrize(
    "value, expected",
    [
        ("2026-11-04", date(2026, 11, 4)),
        # The client's local midnight must not slide into the previous day by converting to UTC.
        ("2026-11-04T00:00:00+05:30", date(2026, 11, 4)),
        ("2026-11-04T23:30:00-05:00", date(2026, 11, 4)),
        (datetime(2026, 11, 4, 23, 0), date(2026, 11, 4)),
        (date(2026, 11, 4), date(2026, 11, 4)),
    ],
)
def test_calendar_dates_keep_the_day_the_client_picked(value, expected):
    assert Sample.model_validate({"name": "a", "day": value}).day == expected


def test_an_unreadable_calendar_date_is_explained():
    assert describe({"name": "a", "day": "04/11/2026"}) == "Enter a valid date."


# -- validation messages ---------------------------------------------------------------------------


def test_missing_and_blank_required_fields_read_as_required():
    assert describe({}) == "name is required."
    assert describe({"name": "   "}) == "name is required."


def test_messages_name_fields_as_the_client_sends_them():
    assert describe({"name": "a", "pageSize": "lots"}).startswith("pageSize: ")


def test_too_long_text_names_the_limit():
    assert describe({"name": "abcdef"}) == "name can be at most 5 characters."


def test_a_lower_bound_names_the_limit():
    assert describe({"name": "a", "amount": 0}) == "amount must be greater than 0."


def test_a_minimum_length_above_one_is_not_reported_as_required():
    assert describe({"name": "a", "code": "A"}) == "code: String should have at least 2 characters."


def test_nested_fields_are_named_by_path():
    class Line(RequestSchema):
        invoiced_quantity: int

    class Lines(RequestSchema):
        lines: list[Line]

    assert describe({"lines": [{"invoicedQuantity": 1}, {}]}, Lines) == "lines.1.invoicedQuantity is required."


# -- parse_body ------------------------------------------------------------------------------------


def test_parse_body_validates_the_json_body(shared_app):
    with shared_app.test_request_context(json={"name": " Cola ", "pageSize": 10}):
        body = parse_body(Sample)
    assert (body.name, body.page_size) == ("Cola", 10)


@pytest.mark.parametrize("payload", [[1, 2], "text", 42])
def test_parse_body_requires_a_json_object(shared_app, payload):
    with shared_app.test_request_context(json=payload), pytest.raises(ApiError) as caught:
        parse_body(Sample)
    assert (caught.value.status, caught.value.message) == (400, "The request body must be a JSON object.")


def test_a_missing_or_malformed_body_is_validated_as_empty(shared_app):
    for kwargs in ({}, {"data": "{not json", "content_type": "application/json"}):
        with shared_app.test_request_context(method="POST", **kwargs), pytest.raises(ApiError) as caught:
            parse_body(Sample)
        assert (caught.value.status, caught.value.message) == (400, "name is required.")


# -- query strings ---------------------------------------------------------------------------------


@pytest.mark.parametrize("query, expected", [("?search=%20cola%20", "cola"), ("?search=%20%20", None), ("", None)])
def test_search_term_is_trimmed_and_blank_means_no_search(shared_app, query, expected):
    with shared_app.test_request_context(f"/{query}"):
        assert search_term() == expected


def test_contains_escapes_like_wildcards():
    assert contains("cola") == "%cola%"
    assert contains("50%_off\\") == "%50\\%\\_off\\\\%"


def test_contains_matches_wildcards_literally_in_a_query(supplier):
    make_product(supplier, "P1", name="50% off pack")
    make_product(supplier, "P2", name="500 off pack")
    make_product(supplier, "P3", name="snack_bar")
    make_product(supplier, "P4", name="snackXbar")

    def names(term):
        stmt = select(Product.product_name).where(Product.product_name.ilike(contains(term), escape="\\"))
        return sorted(db.session.scalars(stmt))

    assert names("50%") == ["50% off pack"]
    assert names("k_b") == ["snack_bar"]
    assert names("PACK") == ["50% off pack", "500 off pack"]


@pytest.mark.parametrize(
    "query, default, expected",
    [("?sortDir=desc", False, True), ("?sortDir=asc", True, False), ("", False, False), ("", True, True)],
)
def test_sort_direction_falls_back_to_the_default(shared_app, query, default, expected):
    with shared_app.test_request_context(f"/{query}"):
        assert sort_descending(default) is expected


@pytest.mark.parametrize(
    "query, expected",
    [("?from=2026-11-04", date(2026, 11, 4)), ("?from=2026-11-04T23:30:00%2B05:30", date(2026, 11, 4)),
     ("?from=%20", None), ("", None)],
)
def test_query_dates(shared_app, query, expected):
    with shared_app.test_request_context(f"/{query}"):
        assert query_date("from") == expected


def test_an_unreadable_query_date_is_a_bad_request(shared_app):
    with shared_app.test_request_context("/?to=yesterday"), pytest.raises(ApiError) as caught:
        query_date("to")
    assert (caught.value.status, caught.value.message) == (400, "to: enter a valid date.")


# -- paging ----------------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "query, page, size",
    [
        ("", 1, 20),
        ("?page=3&pageSize=10", 3, 10),
        ("?page=0&pageSize=0", 1, 1),
        ("?page=-4&pageSize=-5", 1, 1),
        ("?pageSize=1000", 1, 200),
        ("?page=two&pageSize=many", 1, 20),
    ],
)
def test_page_and_size_are_clamped(shared_app, query, page, size):
    with shared_app.test_request_context(f"/{query}"):
        result = paginate_list(list(range(5)))
    assert (result["page"], result["pageSize"]) == (page, size)


def test_paginate_list_slices_the_requested_page(shared_app):
    with shared_app.test_request_context("/?page=3&pageSize=20"):
        assert paginate_list(list(range(45))) == {"items": [40, 41, 42, 43, 44], "totalCount": 45, "page": 3, "pageSize": 20}
    with shared_app.test_request_context("/?page=9&pageSize=20"):
        assert paginate_list(list(range(45)))["items"] == []


def test_paginate_counts_every_row_and_returns_one_page(app, supplier):
    for n in range(1, 6):
        make_product(supplier, f"P{n}", stock=None)
    stmt = select(Product).order_by(Product.product_code.desc())
    with app.test_request_context("/?page=2&pageSize=2"):
        result = paginate(stmt, lambda p: p.product_code)
    assert result == {"items": ["P3", "P2"], "totalCount": 5, "page": 2, "pageSize": 2}


def test_paginate_can_return_whole_rows(app, supplier):
    make_product(supplier, "P1", stock=None)
    stmt = select(Product.product_code, func.length(Product.product_code))
    with app.test_request_context("/"):
        result = paginate(stmt, lambda row: tuple(row), scalars=False)
    assert result["items"] == [("P1", 2)] and result["totalCount"] == 1


# -- response values -------------------------------------------------------------------------------


def test_timestamps_are_written_as_utc_with_a_z():
    assert iso_timestamp(None) is None
    # Naive values come back from the database and are UTC.
    assert iso_timestamp(datetime(2026, 11, 5, 8, 30)) == "2026-11-05T08:30:00Z"
    assert iso_timestamp(datetime(2026, 11, 5, 14, 0, tzinfo=IST)) == "2026-11-05T08:30:00Z"
    assert iso_timestamp(datetime(2026, 11, 5, 8, 30, 0, 123456, tzinfo=timezone.utc)) == "2026-11-05T08:30:00.123456Z"


def test_calendar_dates_are_written_as_midnight_without_an_offset():
    assert iso_calendar_date(None) is None
    assert iso_calendar_date(date(2026, 11, 5)) == "2026-11-05T00:00:00"
    assert iso_calendar_date(datetime(2026, 11, 5, 23, 59)) == "2026-11-05T00:00:00"


def test_record_status():
    assert record_status(True) == "Active"
    assert record_status(False) == "Inactive"


# -- error responses -------------------------------------------------------------------------------


def test_api_error_carries_its_status_and_message():
    error = ApiError(409, "Taken.")
    assert (error.status, error.message, str(error)) == (409, "Taken.", "Taken.")
    assert (not_found().status, not_found().message) == (404, NOT_FOUND)
    assert not_found("No such order.").message == "No such order."


@pytest.fixture(scope="module")
def error_app():
    """The real app plus a few routes that fail on purpose. Its own app (on SQLite), because routes can't be
    added to the shared one once it has served a request."""
    app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite://", "JWT_SECRET_KEY": JWT_SECRET})

    def api_error():
        raise ApiError(418, "I'm a teapot.")

    def missing():
        raise not_found()

    def bad_request():
        abort(400, "Custom description.")

    def crash():
        abort(500)

    def read_body():
        return {"size": len(request.get_data())}

    def duplicate_email():
        for code in ("GDP-A", "GDP-B"):
            db.session.add(Supplier(
                supplier_code=code, company_name="Dup", contact_person="X", email="dup@example.com", phone="1234567",
                address="a", city="c", state="s", country="India", postal_code="411001", password_hash="x",
            ))
        db.session.commit()

    for view in (api_error, missing, bad_request, crash, duplicate_email):
        app.add_url_rule(f"/_test/{view.__name__}", view_func=view)
    app.add_url_rule("/_test/read_body", view_func=read_body, methods=["POST"])
    with app.app_context():
        _prepare_database()
        db.create_all()
    return app


@pytest.fixture
def error_client(error_app):
    with error_app.app_context():
        yield error_app.test_client()
        db.session.remove()


@pytest.mark.parametrize(
    "path, status, message",
    [
        ("/_test/api_error", 418, "I'm a teapot."),
        ("/_test/missing", 404, NOT_FOUND),
        ("/_test/bad_request", 400, "Custom description."),
        ("/_test/crash", 500, "An unexpected error occurred."),
        ("/no/such/endpoint", 404, "Unknown endpoint."),
    ],
)
def test_errors_are_rendered_as_a_message(error_client, path, status, message):
    response = error_client.get(path)
    assert (response.status_code, response.json) == (status, {"message": message})


def test_a_wrong_method_is_explained(error_client):
    response = error_client.delete("/_test/api_error")
    assert (response.status_code, response.json) == (405, {"message": "This endpoint does not support that method."})


def test_an_oversized_request_is_refused(error_app, error_client, monkeypatch):
    monkeypatch.setitem(error_app.config, "MAX_CONTENT_LENGTH", 10)
    response = error_client.post("/_test/read_body", data=b"x" * 100)
    assert (response.status_code, response.json) == (413, {"message": "The request is too large."})


def test_a_lost_uniqueness_race_is_a_conflict_and_the_session_recovers(error_client, caplog):
    with caplog.at_level(logging.WARNING, logger="supplier_service.common.errors"):
        response = error_client.get("/_test/duplicate_email")
    assert response.status_code == 409
    assert response.json == {"message": "This change conflicts with existing data. Refresh and try again."}
    assert "Integrity error" in caplog.text
    # Rolled back: the session is usable and nothing was saved.
    assert db.session.scalar(select(func.count(Supplier.id))) == 0
