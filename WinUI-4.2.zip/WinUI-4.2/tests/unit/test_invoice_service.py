"""invoices/service.py (drafts, sending, numbering, tax) and invoices/schemas.py (request rules, wire format)."""

from datetime import datetime, timezone
from decimal import Decimal

import pytest
from sqlalchemy import select

from supplier_service.catalogue.models import Product
from supplier_service.common.errors import ApiError
from supplier_service.extensions.database import db
from supplier_service.inventory.models import InventoryTransaction, ReferenceType, TransactionType
from supplier_service.invoices import service as invoice_service
from supplier_service.invoices.models import Invoice, InvoiceStatus
from supplier_service.invoices.schemas import CreateInvoiceRequest, InvoiceLineInput, invoice_json
from supplier_service.invoices.service import (
    _typed_price,
    addable_product,
    added_lines,
    invoiced_prices,
    invoiced_quantities,
    save_draft,
    send_invoice,
    tax_rate,
)
from supplier_service.orders.models import OrderStatus
from supplier_service.orders.service import reject_order
from supplier_service.retailers.service import settings_for

from .factories import (
    inventory_of,
    make_group,
    make_order,
    make_product,
    make_retailer,
    make_supplier,
    set_price,
    standard_group,
    validation_message,
)

D = Decimal


@pytest.fixture
def products(supplier):
    return {
        "cola": make_product(supplier, "COLA", stock=50),
        "chips": make_product(supplier, "CHIPS", stock=30),
        "water": make_product(supplier, "WATER", stock=40),  # not on the order
    }


@pytest.fixture
def order(supplier, products, fixed_rates):
    """Pending, from retailer 1 (Standard group): 10 x Cola @ 12.50 and 5 x Chips @ 4.00 (145.00)."""
    make_retailer(supplier)
    return make_order(supplier, [(products["cola"], 10, "12.50"), (products["chips"], 5, "4.00")])


@pytest.fixture
def clock(monkeypatch):
    """Sets the time the invoice service sees."""

    def set_to(*args):
        monkeypatch.setattr(invoice_service, "utcnow", lambda: datetime(*args, tzinfo=timezone.utc))

    return set_to


def item_id(order, product) -> int:
    return next(i.id for i in order.items if i.product_id == product.id)


def ordered(order, product, quantity, price=None) -> InvoiceLineInput:
    return InvoiceLineInput(
        order_line_id=item_id(order, product), invoiced_quantity=quantity, unit_price=None if price is None else D(price)
    )


def added(code, quantity, price=None) -> InvoiceLineInput:
    return InvoiceLineInput(product_code=code, invoiced_quantity=quantity, unit_price=None if price is None else D(price))


def lines_by_code(invoice) -> dict[str, tuple[int, int, Decimal, Decimal]]:
    """code → (ordered, invoiced, unit price, line total)"""
    return {
        line.product_code: (line.ordered_quantity, line.invoiced_quantity, line.unit_price, line.line_total)
        for line in invoice.lines
    }


def stock_of(product) -> tuple[int, int]:
    inventory = inventory_of(product)
    return inventory.on_hand_quantity, inventory.reserved_quantity


# -- tax_rate --------------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "subtotal, tax, expected",
    [
        ("100.00", "18.00", "0.18"),
        ("145.00", "26.10", "0.18"),
        ("100.05", "18.00", "0.18"),  # 18.009 rounds to 18.01: a paisa of rounding still reads as the configured rate
        ("0.00", "0.00", "0.18"),
        ("100.00", "18.02", "0.1802"),  # more than a paisa off: derived from the stored amounts
        ("145.00", "0.00", "0.0000"),  # GST was off for the retailer
        ("145.00", "7.25", "0.0500"),
    ],
)
def test_tax_rate(app, fixed_rates, subtotal, tax, expected):
    rate = tax_rate(Invoice(subtotal=D(subtotal), tax_amount=D(tax)))
    assert rate == D(expected)


def test_an_old_invoice_keeps_its_rate_after_the_configured_rate_changes(app, monkeypatch):
    monkeypatch.setitem(app.config, "GST_RATE", D("0.12"))
    assert tax_rate(Invoice(subtotal=D("100.00"), tax_amount=D("18.00"))) == D("0.1800")


# -- typed prices ----------------------------------------------------------------------------------


@pytest.mark.parametrize("typed, kept", [(None, None), ("10.005", "10.01"), ("10.004", "10.00"), ("99999999.99", "99999999.99")])
def test_a_typed_price_is_rounded_to_paise(typed, kept):
    price = _typed_price(Product(product_name="Cola"), None if typed is None else D(typed))
    assert price == (None if kept is None else D(kept))


@pytest.mark.parametrize(
    "typed, message",
    [
        ("100000000", "Cola: the price can be at most 99,999,999.99."),
        ("0", "Cola: enter a price above 0."),
        ("0.004", "Cola: enter a price above 0."),  # rounds to 0.00
        ("-5", "Cola: enter a price above 0."),
    ],
)
def test_typed_prices_must_be_positive_and_fit_the_column(typed, message):
    with pytest.raises(ApiError) as caught:
        _typed_price(Product(product_name="Cola"), D(typed))
    assert (caught.value.status, caught.value.message) == (400, message)


# -- invoiced quantities and prices ----------------------------------------------------------------


def test_nothing_is_planned_on_a_new_order(order):
    assert set(invoiced_quantities(order).values()) == {None}
    assert set(invoiced_prices(order).values()) == {None}
    assert added_lines(order) == []


def test_a_draft_reports_its_planned_quantities_prices_and_added_products(order, products):
    set_price(standard_group(order.supplier), products["water"], "20.00")
    save_draft(order, [ordered(order, products["cola"], 7, "11.00"), added("WATER", 2)])
    db.session.commit()

    cola, chips = item_id(order, products["cola"]), item_id(order, products["chips"])
    assert invoiced_quantities(order) == {cola: 7, chips: 5}  # chips: not changed, so as ordered
    assert invoiced_prices(order) == {cola: D("11.00"), chips: D("4.00")}
    assert [(line.product_code, line.invoiced_quantity) for line in added_lines(order)] == [("WATER", 2)]


def test_a_sent_invoice_reports_lines_it_left_out_as_zero(order, products):
    send_invoice(order, [ordered(order, products["cola"], 4)])
    db.session.commit()

    cola, chips = item_id(order, products["cola"]), item_id(order, products["chips"])
    assert invoiced_quantities(order) == {cola: 4, chips: 0}
    assert invoiced_prices(order) == {cola: D("12.50"), chips: None}


def test_a_rejected_order_reports_nothing_invoiced(order, products):
    save_draft(order, [ordered(order, products["cola"], 7)])
    reject_order(order, None)
    db.session.commit()

    assert set(invoiced_quantities(order).values()) == {0}
    assert set(invoiced_prices(order).values()) == {None}
    assert added_lines(order) == []


# -- save_draft ------------------------------------------------------------------------------------


def test_a_draft_is_priced_like_the_invoice_but_has_no_number(order, products):
    invoice = save_draft(order, [ordered(order, products["cola"], 7)])
    db.session.commit()

    assert (invoice.status, invoice.invoice_number) == (InvoiceStatus.DRAFT, f"DRAFT-{order.id}")
    assert lines_by_code(invoice) == {
        "COLA": (10, 7, D("12.50"), D("87.50")),
        "CHIPS": (5, 5, D("4.00"), D("20.00")),
    }
    assert (invoice.subtotal, invoice.tax_amount, invoice.grand_total) == (D("107.50"), D("19.35"), D("126.85"))


def test_saving_again_keeps_earlier_changes_to_lines_not_sent(order, products):
    first = save_draft(order, [ordered(order, products["cola"], 7, "11.00")])
    db.session.commit()
    second = save_draft(order, [ordered(order, products["chips"], 2)])
    db.session.commit()

    assert second.id == first.id
    assert lines_by_code(second)["COLA"][1:3] == (7, D("11.00"))
    assert lines_by_code(second)["CHIPS"][1] == 2


def test_each_save_replaces_the_added_products(order, products):
    set_price(standard_group(order.supplier), products["water"], "20.00")
    save_draft(order, [added("WATER", 2)])
    db.session.commit()
    save_draft(order, [ordered(order, products["cola"], 3)])
    db.session.commit()
    assert "WATER" not in lines_by_code(order.invoice)


def test_a_draft_leaves_stock_alone(order, products):
    save_draft(order, [ordered(order, products["cola"], 1)])
    db.session.commit()
    assert stock_of(products["cola"]) == (50, 10)


def test_a_draft_needs_something_to_invoice(order, products):
    lines = [ordered(order, products["cola"], 0), ordered(order, products["chips"], 0)]
    with pytest.raises(ApiError) as caught:
        save_draft(order, lines)
    assert caught.value.message == "At least one line must have an invoiced quantity. Reject the order instead."


def test_a_draft_can_invoice_only_added_products(order, products):
    lines = [ordered(order, products["cola"], 0), ordered(order, products["chips"], 0), added("WATER", 1, "20")]
    assert lines_by_code(save_draft(order, lines))["WATER"] == (0, 1, D("20.00"), D("20.00"))


def test_only_pending_orders_can_be_edited(order, products):
    reject_order(order, None)
    with pytest.raises(ApiError) as caught:
        save_draft(order, [ordered(order, products["cola"], 1)])
    assert caught.value.message == "Only pending orders can be edited."


# -- line validation (shared by save_draft and send_invoice) ---------------------------------------


@pytest.mark.parametrize(
    "make_lines, message",
    [
        pytest.param(
            lambda o, p: [InvoiceLineInput(order_line_id=999, invoiced_quantity=1)],
            "Order line 999 is not part of this order.", id="unknown order line",
        ),
        pytest.param(lambda o, p: [added("nope", 1, "5")], "No active product with code NOPE.", id="unknown code"),
        pytest.param(lambda o, p: [added("OLD", 1, "5")], "No active product with code OLD.", id="inactive product"),
        pytest.param(lambda o, p: [added("THEIRS", 1, "5")], "No active product with code THEIRS.", id="other supplier's"),
        pytest.param(lambda o, p: [added("cola", 1, "5")], "COLA is already on this order.", id="already ordered"),
        pytest.param(
            lambda o, p: [added("WATER", 1, "5"), added("water", 2, "5")], "WATER is listed twice.", id="listed twice",
        ),
        pytest.param(
            lambda o, p: [added("WATER", 0, "5")], "WATER: an added product needs a quantity of at least 1.", id="zero added",
        ),
        pytest.param(
            lambda o, p: [added("WATER", 1)],
            "WATER has no price for this retailer. Enter a price, or set one in Price Groups.", id="no price anywhere",
        ),
        pytest.param(
            lambda o, p: [ordered(o, p["cola"], 1, "100000000")], "Cola: the price can be at most 99,999,999.99.",
            id="price too high",
        ),
    ],
)
@pytest.mark.parametrize("action", [save_draft, send_invoice], ids=["draft", "send"])
def test_invalid_lines_are_explained(order, products, other_supplier, action, make_lines, message):
    make_product(order.supplier, "OLD", active=False)
    make_product(other_supplier, "THEIRS")
    with pytest.raises(ApiError) as caught:
        action(order, make_lines(order, products))
    assert (caught.value.status, caught.value.message) == (400, message)
    assert order.status == OrderStatus.PENDING and order.invoice is None


def test_addable_product_can_report_a_missing_product_as_not_found(order):
    with pytest.raises(ApiError) as caught:
        addable_product(order, "NOPE", missing_status=404)
    assert caught.value.status == 404


def test_an_added_product_is_found_ignoring_case_and_spaces(order, products):
    assert addable_product(order, "  water ").id == products["water"].id


def test_an_added_product_takes_the_standard_price_by_default(order, products):
    set_price(standard_group(order.supplier), products["water"], "20.00")
    assert lines_by_code(save_draft(order, [added("WATER", 2)]))["WATER"] == (0, 2, D("20.00"), D("40.00"))


def test_an_added_product_takes_the_retailers_group_price(supplier, products, fixed_rates):
    wholesale = make_group(supplier)
    make_retailer(supplier, 2, group=wholesale)
    set_price(standard_group(supplier), products["water"], "20.00")
    set_price(wholesale, products["water"], "18.00")
    order = make_order(supplier, [(products["cola"], 1, "12.50")], retailer_id=2)

    assert lines_by_code(save_draft(order, [added("WATER", 1)]))["WATER"][2] == D("18.00")


def test_a_typed_price_wins_over_the_group_and_order_price(order, products):
    set_price(standard_group(order.supplier), products["water"], "20.00")
    draft = save_draft(order, [added("WATER", 1, "19.495"), ordered(order, products["cola"], 10, "11.495")])
    assert lines_by_code(draft)["WATER"][2] == D("19.50")
    assert lines_by_code(draft)["COLA"][2:] == (D("11.50"), D("115.00"))


# -- send_invoice ----------------------------------------------------------------------------------


def test_sending_invoices_the_order_and_ships_the_stock(order, products, clock):
    clock(2026, 11, 5, 9, 0)
    invoice = send_invoice(order, [ordered(order, products["cola"], 10), ordered(order, products["chips"], 5)])
    db.session.commit()

    number = f"INV-{order.supplier_id:04d}-202611-0001"
    assert (invoice.invoice_number, invoice.status) == (number, InvoiceStatus.SENT)
    assert invoice.invoice_date == datetime(2026, 11, 5, 9, 0)
    assert (invoice.subtotal, invoice.tax_amount, invoice.grand_total) == (D("145.00"), D("26.10"), D("171.10"))
    assert (order.status, order.invoice_number, order.invoiced_qty) == (OrderStatus.INVOICE_SENT, number, 15)
    assert stock_of(products["cola"]) == (40, 0)
    assert stock_of(products["chips"]) == (25, 0)

    movement = db.session.scalar(select(InventoryTransaction).filter_by(product_id=products["cola"].id, reference_id=number))
    assert (movement.transaction_type, movement.quantity, movement.reference_type) == (
        TransactionType.STOCK_REMOVED, 10, ReferenceType.INVOICE,
    )
    assert "ORD-0001" in movement.remarks


def test_a_partial_invoice_releases_the_whole_reservation(order, products):
    invoice = send_invoice(order, [ordered(order, products["cola"], 4)])
    db.session.commit()

    assert set(lines_by_code(invoice)) == {"COLA"}  # lines not invoiced are left off a sent invoice
    assert stock_of(products["cola"]) == (46, 0)
    assert stock_of(products["chips"]) == (30, 0)
    assert order.invoiced_qty == 4


def test_more_than_was_ordered_can_be_shipped(order, products):
    invoice = send_invoice(order, [ordered(order, products["cola"], 12)])
    db.session.commit()
    assert lines_by_code(invoice)["COLA"][:2] == (10, 12)
    assert stock_of(products["cola"]) == (38, 0)


def test_added_products_ship_too(order, products):
    invoice = send_invoice(order, [ordered(order, products["cola"], 1), added("WATER", 3, "20")])
    db.session.commit()
    assert lines_by_code(invoice)["WATER"] == (0, 3, D("20.00"), D("60.00"))
    assert stock_of(products["water"]) == (37, 0)
    assert order.invoiced_qty == 4


@pytest.mark.parametrize(
    "make_lines, message",
    [
        pytest.param(lambda o, p: [ordered(o, p["cola"], 51)], "Cola: only 50 on hand.", id="ordered product"),
        pytest.param(lambda o, p: [added("WATER", 41, "20")], "Water: only 40 on hand.", id="added product"),
        pytest.param(lambda o, p: [added("SERVICE", 1, "20")], "Service: only 0 on hand.", id="no inventory row"),
    ],
)
def test_nothing_ships_beyond_the_stock_on_hand(order, products, make_lines, message):
    make_product(order.supplier, "SERVICE", stock=None)
    with pytest.raises(ApiError) as caught:
        send_invoice(order, make_lines(order, products))
    assert caught.value.message == message
    assert order.status == OrderStatus.PENDING
    assert stock_of(products["cola"]) == (50, 10) and stock_of(products["water"]) == (40, 0)


def test_an_ordered_product_without_a_stock_record_can_only_be_left_off(supplier, products, fixed_rates):
    make_retailer(supplier)
    install = make_product(supplier, "INSTALL", stock=None)  # e.g. a product from before stock was tracked
    order = make_order(supplier, [(products["cola"], 2, "12.50"), (install, 1, "100")])

    with pytest.raises(ApiError) as caught:
        send_invoice(order, [ordered(order, products["cola"], 2), ordered(order, install, 1)])
    assert caught.value.message == "Install: only 0 on hand."

    invoice = send_invoice(order, [ordered(order, products["cola"], 2), ordered(order, install, 0)])
    db.session.commit()
    assert set(lines_by_code(invoice)) == {"COLA"}
    assert stock_of(products["cola"]) == (48, 0)
    assert inventory_of(install) is None


def test_the_draft_becomes_the_sent_invoice(order, products):
    draft = save_draft(order, [ordered(order, products["cola"], 7)])
    db.session.commit()
    sent = send_invoice(order, [ordered(order, products["cola"], 7)])
    db.session.commit()

    assert sent.id == draft.id
    assert sent.invoice_number.startswith("INV-") and sent.status == InvoiceStatus.SENT
    assert db.session.scalars(select(Invoice.id).where(Invoice.order_id == order.id)).all() == [draft.id]


def test_an_invoice_needs_something_on_it(order, products):
    with pytest.raises(ApiError) as caught:
        send_invoice(order, [ordered(order, products["cola"], 0)])
    assert caught.value.message == "Invoice at least one item."


def test_an_order_is_invoiced_once(order, products):
    send_invoice(order, [ordered(order, products["cola"], 1)])
    db.session.commit()
    with pytest.raises(ApiError) as caught:
        send_invoice(order, [ordered(order, products["cola"], 1)])
    assert caught.value.message == "Only pending orders can be invoiced."


def test_no_gst_for_a_retailer_with_gst_turned_off(order, products):
    settings_for(order.supplier_id, order.retailer_id).gst_applicable = False
    db.session.commit()
    invoice = send_invoice(order, [ordered(order, products["cola"], 10), ordered(order, products["chips"], 5)])
    assert (invoice.subtotal, invoice.tax_amount, invoice.grand_total) == (D("145.00"), D("0.00"), D("145.00"))


def test_tax_is_rounded_half_up_to_paise(order, products):
    invoice = send_invoice(order, [ordered(order, products["chips"], 1, "0.25")])  # 0.25 × 18% = 0.045
    assert invoice.tax_amount == D("0.05")


# -- invoice numbers -------------------------------------------------------------------------------


def test_invoice_numbers_run_per_supplier_per_month(supplier, products, fixed_rates, clock):
    make_retailer(supplier)

    def invoice_new_order(number):
        order = make_order(supplier, [(products["cola"], 1, "12.50")], number=number)
        return send_invoice(order, [ordered(order, products["cola"], 1)]).invoice_number

    prefix = f"INV-{supplier.id:04d}"
    clock(2026, 1, 31, 23, 0)
    assert invoice_new_order("ORD-1") == f"{prefix}-202601-0001"
    assert invoice_new_order("ORD-2") == f"{prefix}-202601-0002"

    # Drafts don't use up numbers.
    save_draft(make_order(supplier, [(products["cola"], 1, "12.50")], number="ORD-3"), [])
    assert invoice_new_order("ORD-4") == f"{prefix}-202601-0003"

    clock(2026, 2, 1, 0, 0)
    assert invoice_new_order("ORD-5") == f"{prefix}-202602-0001"


def test_each_supplier_has_its_own_invoice_numbers(supplier, products, fixed_rates, clock):
    clock(2026, 11, 5, 9, 0)
    other = make_supplier("Other Supplies")
    make_retailer(supplier)
    make_retailer(other)
    theirs = make_product(other, "COLA")
    mine = make_order(supplier, [(products["cola"], 1, "1")])
    their_order = make_order(other, [(theirs, 1, "1")])

    assert send_invoice(mine, [ordered(mine, products["cola"], 1)]).invoice_number == f"INV-{supplier.id:04d}-202611-0001"
    assert send_invoice(their_order, [ordered(their_order, theirs, 1)]).invoice_number == f"INV-{other.id:04d}-202611-0001"


# -- request schemas and wire format ---------------------------------------------------------------


@pytest.mark.parametrize(
    "payload",
    [
        {"orderLineId": 1, "productCode": "WATER", "invoicedQuantity": 1},
        {"invoicedQuantity": 1},
        {"productCode": "   ", "invoicedQuantity": 1},
    ],
)
def test_each_line_is_an_order_line_or_a_product_code(payload):
    assert validation_message(InvoiceLineInput, payload) == "Each line needs an order line or a product code."


def test_line_quantities_are_whole_and_not_negative():
    assert validation_message(InvoiceLineInput, {"orderLineId": 1, "invoicedQuantity": 1.5}) == (
        "Quantity must be a whole number."
    )
    assert validation_message(InvoiceLineInput, {"orderLineId": 1, "invoicedQuantity": -1}).startswith("invoicedQuantity: ")


def test_an_invoice_request_needs_lines():
    assert validation_message(CreateInvoiceRequest, {"orderId": 1, "lines": []}).startswith("lines: ")
    body = CreateInvoiceRequest.model_validate({"orderId": 1, "lines": [{"orderLineId": 4, "invoicedQuantity": "3"}]})
    assert (body.order_id, body.lines[0].order_line_id, body.lines[0].invoiced_quantity) == (1, 4, 3)


@pytest.mark.parametrize(
    "status, accepted, shown",
    [
        (InvoiceStatus.SENT, False, "Sent"),
        (InvoiceStatus.SENT, True, "Accepted"),
        (InvoiceStatus.REJECTED, False, "Rejected"),
    ],
)
def test_invoice_status_as_the_client_names_it(status, accepted, shown):
    invoice = Invoice(id=1, invoice_number="INV-1", order_id=2, retailer_id=3, status=status,
                      invoice_date=datetime(2026, 11, 5, 9, 0), grand_total=D("171.10"))
    payload = invoice_json(invoice, "ORD-1", None, accepted=accepted)
    assert payload["status"] == shown
    assert payload["retailerName"] == "Retailer #3"
    assert (payload["amount"], payload["invoiceDate"]) == (D("171.10"), "2026-11-05T09:00:00Z")
