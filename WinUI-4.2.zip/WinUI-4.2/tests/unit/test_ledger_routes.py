"""Ledger endpoints (ledger/routes.py) the API tests don't reach: linking an offline account to a connected retailer
who has no ledger account of their own yet. (Recent payments and editing the last one: test_ledger_payments.py.)"""

from datetime import date

from sqlalchemy import select

from supplier_service.circles.models import Circle, CircleLocation
from supplier_service.extensions.database import db
from supplier_service.ledger.models import EntryType, LedgerAccount
from supplier_service.retailers.models import RetailerSettings

from .factories import ledger_entry, make_retailer, offline_account


def test_an_offline_account_becomes_the_retailers_account_when_they_have_none_yet(call, supplier):
    make_retailer(supplier)  # connected, never opened in the ledger: no account of their own
    circle = Circle(supplier_id=supplier.id, name="North Delhi", state="Delhi")
    db.session.add(circle)
    db.session.flush()
    location = CircleLocation(supplier_id=supplier.id, circle_id=circle.id, name="Rohini")
    db.session.add(location)
    shop = offline_account(supplier, "Green Valley (paper ledger)")
    shop.circle_id, shop.location_id = circle.id, location.id
    db.session.commit()
    ledger_entry(shop, EntryType.OFFLINE_ORDER, 500, date(2026, 11, 1))

    response = call("POST", f"/api/ledger/accounts/{shop.id}/link", {"retailerId": 1})

    assert response.status_code == 200, response.json
    linked = response.json
    assert (linked["id"], linked["isOnline"], linked["retailerId"], linked["name"]) == (shop.id, True, 1, "Green Valley Mart")
    assert (linked["circleId"], linked["locationId"], linked["balance"]) == (circle.id, location.id, 500)

    # The area moves to the retailer's own settings (an online account shows those); the history stays.
    settings = db.session.scalar(select(RetailerSettings).filter_by(supplier_id=supplier.id, retailer_id=1))
    assert (settings.circle_id, settings.location_id) == (circle.id, location.id)
    account = db.session.get(LedgerAccount, shop.id, populate_existing=True)
    assert (account.retailer_id, account.circle_id, account.location_id) == (1, None, None)
    assert db.session.scalars(select(LedgerAccount.id).filter_by(supplier_id=supplier.id)).all() == [shop.id]
