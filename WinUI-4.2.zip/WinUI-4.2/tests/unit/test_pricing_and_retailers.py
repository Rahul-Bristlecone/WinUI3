"""pricing/service.py (what a retailer pays) and retailers/ (settings, delivery addresses, connection status)."""

from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest
from sqlalchemy import select

from supplier_service.extensions.database import db
from supplier_service.pricing.service import retailer_price
from supplier_service.retailers.models import OrderDelivery, RetailerSettings, RetailerStatus
from supplier_service.retailers.service import delivery_address_json, gst_applicable, retailer_rows, settings_for

from .factories import make_group, make_product, make_retailer, set_price, standard_group


def today_utc() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None, hour=0, minute=0, second=0, microsecond=0)


@pytest.fixture
def cola(supplier):
    return make_product(supplier)


# -- retailer_price --------------------------------------------------------------------------------


def test_no_price_anywhere_is_none(supplier, cola):
    make_retailer(supplier)
    assert retailer_price(supplier.id, 1, cola.id) is None


def test_an_unassigned_retailer_pays_the_standard_price(supplier, cola):
    make_retailer(supplier)
    set_price(standard_group(supplier), cola, "12.50")
    assert retailer_price(supplier.id, 1, cola.id) == Decimal("12.50")


def test_an_assigned_retailer_pays_their_groups_price(supplier, cola):
    wholesale = make_group(supplier)
    make_retailer(supplier, group=wholesale)
    set_price(standard_group(supplier), cola, "12.50")
    set_price(wholesale, cola, "11.00")
    assert retailer_price(supplier.id, 1, cola.id) == Decimal("11.00")


def test_a_group_without_the_product_falls_back_to_standard(supplier, cola):
    wholesale = make_group(supplier)
    make_retailer(supplier, group=wholesale)
    set_price(standard_group(supplier), cola, "12.50")
    assert retailer_price(supplier.id, 1, cola.id) == Decimal("12.50")


def test_prices_that_have_not_started_do_not_count(supplier, cola):
    wholesale = make_group(supplier)
    make_retailer(supplier, group=wholesale)
    set_price(standard_group(supplier), cola, "12.50")
    set_price(wholesale, cola, "11.00", effective_from=today_utc() + timedelta(days=1))
    assert retailer_price(supplier.id, 1, cola.id) == Decimal("12.50")


def test_a_price_ending_today_still_counts_but_not_one_that_ended_yesterday(supplier, cola):
    make_retailer(supplier)
    row = set_price(standard_group(supplier), cola, "12.50", effective_to=today_utc())
    assert retailer_price(supplier.id, 1, cola.id) == Decimal("12.50")

    row.effective_to = today_utc() - timedelta(days=1)
    db.session.commit()
    assert retailer_price(supplier.id, 1, cola.id) is None


def test_another_suppliers_assignment_is_ignored(supplier, other_supplier, cola):
    theirs = make_group(other_supplier, "Their VIPs")
    make_retailer(supplier)
    make_retailer(other_supplier, group=theirs)
    set_price(standard_group(supplier), cola, "12.50")
    assert retailer_price(supplier.id, 1, cola.id) == Decimal("12.50")


# -- retailer settings -----------------------------------------------------------------------------


def test_gst_applies_unless_turned_off(supplier, other_supplier):
    make_retailer(supplier)
    assert gst_applicable(supplier.id, 1) is True

    make_retailer(other_supplier, gst=False)  # another supplier's setting doesn't apply
    assert gst_applicable(supplier.id, 1) is True
    assert gst_applicable(other_supplier.id, 1) is False


def test_settings_are_created_on_first_use_and_reused(supplier):
    make_retailer(supplier)
    first = settings_for(supplier.id, 1)
    assert first in db.session.new
    db.session.commit()
    assert first.gst_applicable is True  # the default

    assert settings_for(supplier.id, 1) is first
    assert db.session.scalars(select(RetailerSettings)).all() == [first]


def test_delivery_address(app):
    assert delivery_address_json(1) is None  # orders from before delivery addresses were recorded

    make_retailer(None)
    db.session.add(OrderDelivery(
        order_id=1, retailer_id=1, location_type="Store", name="Main Store", phone="+91 90000 10000",
        address="G202", city="Delhi", state="Delhi", country="India", postal_code="110054",
    ))
    db.session.commit()
    assert delivery_address_json(1) == {
        "name": "Main Store", "locationType": "Store", "phone": "+91 90000 10000", "address": "G202",
        "city": "Delhi", "state": "Delhi", "postalCode": "110054", "country": "India",
    }


@pytest.mark.parametrize(
    "stored, shown",
    [("Blocked", "Blocked"), ("blocked", "Blocked"), ("  BLOCKED ", "Blocked"), ("Active", "Active"),
     ("Pending", "Active"), ("", "Active"), (None, "Active")],
)
def test_only_blocked_connections_show_as_blocked(stored, shown):
    assert RetailerStatus.from_db(stored) == shown


def test_full_address_is_one_block_of_text(supplier):
    retailer = make_retailer(supplier)
    assert retailer.full_address == "10, MG Road\nPune, Maharashtra, 411005, India"


# -- retailer_rows ---------------------------------------------------------------------------------


def test_retailer_rows_show_each_retailers_effective_group_and_settings(supplier, other_supplier):
    wholesale = make_group(supplier)
    make_retailer(supplier, 1, name="Zenith Mart", group=wholesale)
    make_retailer(supplier, 2, name="Apex Stores", gst=False)
    make_retailer(other_supplier, 3, name="Not Ours")

    rows = db.session.execute(retailer_rows(supplier.id)).all()

    assert [(r.business_name, group.group_name, gst) for _, r, group, gst, _, _ in rows] == [
        ("Apex Stores", "Standard", False),  # sorted by name; unassigned means Standard
        ("Zenith Mart", "Wholesale", True),
    ]
