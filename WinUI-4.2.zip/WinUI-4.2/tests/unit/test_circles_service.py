"""circles/service.py: sales areas (State → Circle → Location) and the retailers assigned to them."""

from collections import Counter

import pytest
from sqlalchemy import select

from supplier_service.circles.models import Circle, CircleLocation
from supplier_service.circles.service import (
    DEFAULT_STATE,
    area_json,
    checked_area,
    circles_json,
    delete_circle,
    listed_state,
    replace_locations,
    retailer_counts,
    tidy,
)
from supplier_service.common.errors import ApiError
from supplier_service.extensions.database import db
from supplier_service.ledger.models import LedgerAccount
from supplier_service.retailers.models import RetailerSettings

from .factories import make_retailer


def make_circle(supplier, name="North Delhi", locations=(), state="Delhi") -> Circle:
    circle = Circle(supplier_id=supplier.id, name=name, state=state)
    db.session.add(circle)
    db.session.flush()
    db.session.add_all(CircleLocation(supplier_id=supplier.id, circle_id=circle.id, name=n) for n in locations)
    db.session.commit()
    return circle


def place(supplier, name) -> CircleLocation:
    return db.session.scalar(select(CircleLocation).filter_by(supplier_id=supplier.id, name=name))


def connected_retailer(supplier, retailer_id, circle, location=None, *, connected=True) -> RetailerSettings:
    """A retailer assigned to the circle; connected=False: it has since disconnected from the supplier."""
    make_retailer(supplier if connected else None, retailer_id)
    settings = RetailerSettings(
        supplier_id=supplier.id, retailer_id=retailer_id, circle_id=circle.id,
        location_id=location.id if location else None,
    )
    db.session.add(settings)
    db.session.commit()
    return settings


def offline_retailer(supplier, circle, location=None, name="Shree Kirana") -> LedgerAccount:
    account = LedgerAccount(supplier_id=supplier.id, name=name, circle_id=circle.id,
                            location_id=location.id if location else None)
    db.session.add(account)
    db.session.commit()
    return account


def location_names(circle) -> list[str]:
    return sorted(db.session.scalars(select(CircleLocation.name).filter_by(circle_id=circle.id)))


def rejected(call, *args) -> str:
    with pytest.raises(ApiError) as caught:
        call(*args)
    assert caught.value.status == 400
    return caught.value.message


# -- names and states ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "raw, tidied",
    [("North Delhi", "North Delhi"), ("  North   Delhi ", "North Delhi"), ("North\tDelhi\n", "North Delhi"), ("   ", "")],
)
def test_tidy_trims_and_collapses_spaces(raw, tidied):
    assert tidy(raw) == tidied


@pytest.mark.parametrize(
    "raw, state",
    [(None, DEFAULT_STATE), ("maharashtra", "Maharashtra"), ("  TAMIL   nadu ", "Tamil Nadu"),
     ("Dadra and Nagar Haveli and Daman and Diu", "Dadra and Nagar Haveli and Daman and Diu")],
)
def test_states_are_matched_ignoring_case_and_spacing(raw, state):
    assert listed_state(raw) == state


@pytest.mark.parametrize("raw", ["Atlantis", "", "Tamil", "Delhi NCR"])
def test_unlisted_states_are_refused(raw):
    with pytest.raises(ValueError, match="Choose a state from the list."):
        listed_state(raw)


def test_area_json():
    assert area_json(None, None) == {"circleId": None, "circleName": None, "locationId": None, "locationName": None}
    circle, location = Circle(id=1, name="North Delhi"), CircleLocation(id=2, name="Rohini")
    assert area_json(circle, location) == {"circleId": 1, "circleName": "North Delhi", "locationId": 2, "locationName": "Rohini"}


# -- checked_area ----------------------------------------------------------------------------------


@pytest.fixture
def north(supplier) -> Circle:
    return make_circle(supplier, "North Delhi", ["Rohini", "Pitampura"])


@pytest.fixture
def west(supplier) -> Circle:
    return make_circle(supplier, "West Delhi", ["Karol Bagh"])


def test_no_circle_clears_the_location_too(supplier, north):
    assert checked_area(supplier.id, None, place(supplier, "Rohini").id) == (None, None)


def test_a_circle_with_or_without_one_of_its_locations(supplier, north):
    rohini = place(supplier, "Rohini")
    assert checked_area(supplier.id, north.id, None) == (north.id, None)
    assert checked_area(supplier.id, north.id, rohini.id) == (north.id, rohini.id)


def test_the_circle_must_be_the_suppliers(supplier, other_supplier, north):
    theirs = make_circle(other_supplier, "Their Circle")
    assert rejected(checked_area, supplier.id, 999, None) == "Circle not found."
    assert rejected(checked_area, supplier.id, theirs.id, None) == "Circle not found."


def test_the_location_must_exist_and_be_in_that_circle(supplier, other_supplier, north, west):
    make_circle(other_supplier, "Theirs", ["Elsewhere"])
    their_location = place(other_supplier, "Elsewhere")
    assert rejected(checked_area, supplier.id, north.id, 999) == "Location not found."
    assert rejected(checked_area, supplier.id, north.id, their_location.id) == "Location not found."
    assert rejected(checked_area, supplier.id, north.id, place(supplier, "Karol Bagh").id) == "That location isn't in this circle."


# -- retailer counts and listing -------------------------------------------------------------------


def test_counts_include_connected_and_offline_retailers_only(supplier, other_supplier, north, west):
    rohini, karol = place(supplier, "Rohini"), place(supplier, "Karol Bagh")
    connected_retailer(supplier, 1, north, rohini)
    connected_retailer(supplier, 2, north)  # circle, no location
    offline_retailer(supplier, north, rohini)
    connected_retailer(supplier, 3, west, karol, connected=False)  # disconnected: not one of the supplier's
    online_account = offline_retailer(supplier, west, karol, name="Online")
    online_account.retailer_id = 1  # an online retailer's ledger account: its area comes from retailer_settings
    db.session.commit()
    connected_retailer(other_supplier, 4, make_circle(other_supplier, "Theirs"))

    in_circle, at_location = retailer_counts(supplier.id)
    assert in_circle == Counter({north.id: 3})
    assert at_location == Counter({rohini.id: 2})


def test_circles_json_lists_circles_and_locations_by_name_with_counts(supplier, north, west):
    make_circle(supplier, "east Delhi", state="Delhi")
    connected_retailer(supplier, 1, north, place(supplier, "Rohini"))

    listing = circles_json(supplier.id)
    assert [c["name"] for c in listing] == ["east Delhi", "North Delhi", "West Delhi"]
    north_json = listing[1]
    assert north_json["retailerCount"] == 1 and north_json["state"] == "Delhi"
    assert [(loc["name"], loc["retailerCount"]) for loc in north_json["locations"]] == [("Pitampura", 0), ("Rohini", 1)]


def test_circles_json_can_return_one_circle(supplier, north, west):
    assert [c["id"] for c in circles_json(supplier.id, west.id)] == [west.id]
    assert [loc["name"] for loc in circles_json(supplier.id, west.id)[0]["locations"]] == ["Karol Bagh"]


def test_circles_json_is_private_to_the_supplier(other_supplier, north):
    assert circles_json(other_supplier.id) == []


# -- replace_locations -----------------------------------------------------------------------------


def test_new_names_become_new_locations(supplier):
    circle = make_circle(supplier)
    replace_locations(circle, [(None, "Rohini"), (None, "Pitampura")])
    db.session.commit()
    assert location_names(circle) == ["Pitampura", "Rohini"]


def test_a_location_listed_by_id_is_renamed_in_place(supplier, north):
    rohini = place(supplier, "Rohini")
    replace_locations(north, [(rohini.id, "Rohini Sector 3"), (place(supplier, "Pitampura").id, "Pitampura")])
    db.session.commit()
    assert place(supplier, "Rohini Sector 3").id == rohini.id
    assert location_names(north) == ["Pitampura", "Rohini Sector 3"]


def test_names_must_be_unique_ignoring_case(supplier, north):
    assert rejected(replace_locations, north, [(None, "Rohini"), (None, "ROHINI")]) == "“Rohini” is listed twice."


def test_one_location_cannot_be_listed_twice(supplier, north):
    rohini = place(supplier, "Rohini")
    assert rejected(replace_locations, north, [(rohini.id, "A"), (rohini.id, "B")]) == "“Rohini” is listed twice."


def test_only_this_circles_locations_can_be_listed_by_id(supplier, north, west):
    karol = place(supplier, "Karol Bagh")
    assert rejected(replace_locations, north, [(karol.id, "Karol Bagh")]) == "Location not found."
    assert rejected(replace_locations, north, [(999, "Somewhere")]) == "Location not found."


def test_renaming_onto_another_circles_location_is_refused(supplier, north, west):
    rohini = place(supplier, "Rohini")
    assert rejected(replace_locations, north, [(rohini.id, "karol bagh")]) == "“Karol Bagh” is already in the West Delhi circle."


def test_listing_another_circles_location_by_name_moves_it_with_its_retailers(supplier, north, west):
    karol = place(supplier, "Karol Bagh")
    settings = connected_retailer(supplier, 1, west, karol)
    account = offline_retailer(supplier, west, karol)

    replace_locations(north, [(place(supplier, "Rohini").id, "Rohini"), (place(supplier, "Pitampura").id, "Pitampura"),
                              (None, "Karol Bagh")])
    db.session.commit()

    assert place(supplier, "Karol Bagh").id == karol.id and karol.circle_id == north.id
    assert location_names(west) == []
    assert (settings.circle_id, settings.location_id) == (north.id, karol.id)
    assert (account.circle_id, account.location_id) == (north.id, karol.id)


def test_a_name_freed_by_a_rename_can_be_reused_for_a_new_location(supplier, north):
    rohini = place(supplier, "Rohini")
    replace_locations(north, [(rohini.id, "Rohini West"), (None, "Rohini"), (place(supplier, "Pitampura").id, "Pitampura")])
    db.session.commit()
    assert location_names(north) == ["Pitampura", "Rohini", "Rohini West"]
    assert place(supplier, "Rohini West").id == rohini.id and place(supplier, "Rohini").id != rohini.id


def test_left_out_locations_are_removed_and_disconnected_retailers_lose_them(supplier, north):
    pitampura = place(supplier, "Pitampura")
    former = connected_retailer(supplier, 1, north, pitampura, connected=False)

    replace_locations(north, [(place(supplier, "Rohini").id, "Rohini")])
    db.session.commit()

    assert location_names(north) == ["Rohini"]
    assert (former.circle_id, former.location_id) == (north.id, None)


@pytest.mark.parametrize("offline_too, count", [(False, "1 retailer"), (True, "2 retailers")])
def test_a_location_in_use_cannot_be_removed(supplier, north, offline_too, count):
    pitampura = place(supplier, "Pitampura")
    connected_retailer(supplier, 1, north, pitampura)
    if offline_too:
        offline_retailer(supplier, north, pitampura)

    message = rejected(replace_locations, north, [(place(supplier, "Rohini").id, "Rohini")])
    assert message == f"“Pitampura” is used by {count}. Move it to another circle instead of removing it."
    db.session.rollback()
    assert location_names(north) == ["Pitampura", "Rohini"]


# -- delete_circle ---------------------------------------------------------------------------------


def test_an_empty_circle_is_deleted_with_its_locations(supplier, north, west):
    delete_circle(north)
    db.session.commit()
    assert db.session.scalars(select(Circle.name)).all() == ["West Delhi"]
    assert db.session.scalars(select(CircleLocation.name)).all() == ["Karol Bagh"]


@pytest.mark.parametrize("offline_too, message", [
    (False, "1 retailer is in this circle. Move them to another circle first."),
    (True, "2 retailers are in this circle. Move them to another circle first."),
])
def test_a_circle_with_retailers_cannot_be_deleted(supplier, north, offline_too, message):
    connected_retailer(supplier, 1, north)
    if offline_too:
        offline_retailer(supplier, north)
    assert rejected(delete_circle, north) == message


def test_deleting_a_circle_clears_disconnected_retailers_assignments(supplier, north):
    former = connected_retailer(supplier, 1, north, place(supplier, "Rohini"), connected=False)
    delete_circle(north)
    db.session.commit()
    assert (former.circle_id, former.location_id) == (None, None)
