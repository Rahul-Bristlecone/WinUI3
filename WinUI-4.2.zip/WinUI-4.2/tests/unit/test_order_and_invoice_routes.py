"""Order and invoice endpoints (orders/routes.py, invoices/routes.py) the API tests don't reach: listing orders
oldest first, and invoices that can't be opened (unknown, another supplier's, or still a draft)."""

from datetime import datetime

import pytest

from supplier_service.common.errors import NOT_FOUND
from supplier_service.extensions.database import db
from supplier_service.invoices.schemas import InvoiceLineInput
from supplier_service.invoices.service import save_draft, send_invoice

from .factories import make_order, make_product, make_retailer


def first_line(order, quantity=1) -> list[InvoiceLineInput]:
    return [InvoiceLineInput(order_line_id=order.items[0].id, invoiced_quantity=quantity)]


@pytest.mark.parametrize(
    "query, numbers",
    [
        ("", ["ORD-3", "ORD-2", "ORD-1"]),  # newest first by default
        ("?sortBy=date", ["ORD-1", "ORD-2", "ORD-3"]),
        ("?sortBy=date&sortDir=asc", ["ORD-1", "ORD-2", "ORD-3"]),
        ("?sortBy=date&sortDir=desc", ["ORD-3", "ORD-2", "ORD-1"]),
    ],
)
def test_orders_can_be_listed_oldest_first(call, supplier, query, numbers):
    make_retailer(supplier)
    cola = make_product(supplier)
    # Recorded out of date order, so the ids don't give the answer away.
    for number, day in (("ORD-2", 3), ("ORD-1", 1), ("ORD-3", 5)):
        make_order(supplier, [(cola, 1, "10")], number=number, order_date=datetime(2026, 11, day, 10, 0))

    assert [o["orderNumber"] for o in call("GET", f"/api/orders{query}").json["items"]] == numbers


def test_orders_on_the_same_instant_keep_a_stable_order(call, supplier):
    make_retailer(supplier)
    cola = make_product(supplier)
    for number in ("ORD-A", "ORD-B"):
        make_order(supplier, [(cola, 1, "10")], number=number, order_date=datetime(2026, 11, 1, 10, 0))

    def numbers(query):
        return [o["orderNumber"] for o in call("GET", f"/api/orders{query}").json["items"]]

    assert numbers("?sortBy=date") == ["ORD-A", "ORD-B"]
    assert numbers("") == ["ORD-B", "ORD-A"]


@pytest.fixture
def invoices(supplier, other_supplier, fixed_rates):
    """The supplier's sent invoice and draft, and another supplier's sent invoice."""
    make_retailer(supplier)
    make_retailer(other_supplier)
    cola, theirs = make_product(supplier), make_product(other_supplier)
    sent_order = make_order(supplier, [(cola, 2, "10")], number="ORD-1")
    draft_order = make_order(supplier, [(cola, 2, "10")], number="ORD-2")
    their_order = make_order(other_supplier, [(theirs, 2, "10")], number="ORD-9")
    result = {
        "sent": send_invoice(sent_order, first_line(sent_order)),
        "draft": save_draft(draft_order, first_line(draft_order)),
        "theirs": send_invoice(their_order, first_line(their_order)),
    }
    db.session.commit()
    return {name: invoice.id for name, invoice in result.items()}


def test_a_sent_invoice_can_be_opened(call, invoices):
    response = call("GET", f"/api/invoices/{invoices['sent']}")
    assert (response.status_code, response.json["id"], response.json["status"]) == (200, invoices["sent"], "Sent")


@pytest.mark.parametrize("which", ["draft", "theirs", "unknown"])
def test_drafts_other_suppliers_and_unknown_invoices_are_not_found(call, invoices, which):
    invoice_id = invoices.get(which, 9999)
    response = call("GET", f"/api/invoices/{invoice_id}")
    assert (response.status_code, response.json) == (404, {"message": NOT_FOUND})
