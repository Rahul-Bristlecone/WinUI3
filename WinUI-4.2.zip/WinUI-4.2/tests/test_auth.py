from datetime import datetime, timedelta, timezone

import jwt
from sqlalchemy import select

from conftest import PASSWORD, login, register
from supplier_service.auth.models import Supplier, SupplierSession
from supplier_service.common.security import SESSION_EXPIRED
from supplier_service.extensions.database import db


def test_register_login_and_profile(client):
    code = register(client)["supplierCode"]
    assert code == Supplier.generate_supplier_code("Acme Traders")

    api = login(client, email="ACME@Example.com")  # emails are case-insensitive
    profile = api.get("/api/supplier/profile").json
    assert profile["email"] == "acme@example.com"
    assert profile["gstNumber"] == "27ABCDE1234F1Z5"  # normalised to upper case

    profile.update(city="Mumbai", email="ignored@example.com", supplierCode="IGNORED")
    updated = api.put("/api/supplier/profile", profile).json
    assert updated["city"] == "Mumbai"
    assert updated["email"] == "acme@example.com"
    assert updated["supplierCode"] == code


def test_same_day_supplier_codes_are_disambiguated(client):
    first = register(client, "a@example.com", "Acme Traders")["supplierCode"]
    second = register(client, "b@example.com", "ACME Foods")["supplierCode"]
    assert second == f"{first}-2"


def test_register_validation(client):
    register(client)
    r = client.post("/api/auth/register", json={"email": "acme@example.com"})
    assert r.status_code == 400 and r.json["message"] == "companyName is required."

    payload = {"companyName": "X", "contactPerson": "Y", "email": "acme@example.com", "password": PASSWORD,
               "phone": "+91 98765 43210", "address": "A", "city": "C", "state": "S", "country": "IN",
               "postalCode": "411001"}
    assert client.post("/api/auth/register", json=payload).status_code == 409
    weak = client.post("/api/auth/register", json={**payload, "email": "new@example.com", "password": "short"})
    assert weak.status_code == 400 and "at least 8 characters" in weak.json["message"]


def test_login_rejects_bad_credentials(client):
    register(client)
    r = client.post("/api/auth/login", json={"email": "acme@example.com", "password": "Wrong@1234"})
    assert r.status_code == 401
    assert r.json == {"message": "Invalid email or password."}


def test_change_password(client):
    register(client)
    api = login(client)
    wrong = api.post("/api/auth/change-password", {"currentPassword": "Nope@1234", "newPassword": "Newpass@123"})
    assert wrong.status_code == 400
    assert api.post("/api/auth/change-password", {"currentPassword": PASSWORD, "newPassword": "Newpass@123"}).status_code == 204
    assert client.post("/api/auth/login", json={"email": "acme@example.com", "password": PASSWORD}).status_code == 401
    login(client, password="Newpass@123")


def test_protected_endpoints_require_a_valid_token(app, client):
    register(client)
    assert client.get("/api/products").status_code == 401
    assert client.get("/api/products", headers={"Authorization": "Bearer not-a-jwt"}).status_code == 401

    expired = jwt.encode(
        {"sub": "1", "exp": datetime.now(timezone.utc) - timedelta(minutes=1)}, app.config["JWT_SECRET_KEY"], "HS256"
    )
    r = client.get("/api/products", headers={"Authorization": f"Bearer {expired}"})
    assert r.status_code == 401
    assert r.json["message"] == "Your session has expired. Please sign in again."


# -- refresh tokens --------------------------------------------------------------------------------


def sign_in(client, password=PASSWORD) -> dict:
    r = client.post("/api/auth/login", json={"email": "acme@example.com", "password": password})
    assert r.status_code == 200, r.json
    return r.json


def refresh(client, refresh_token: str):
    return client.post("/api/auth/refresh", json={"refreshToken": refresh_token})


def bearer(signed_in: dict) -> dict:
    return {"Authorization": f"Bearer {signed_in['token']}"}


def time_passes(**delta) -> None:
    """Moves every session's timestamps back, as if `delta` had gone by."""
    gone = timedelta(**delta)
    for session in db.session.scalars(select(SupplierSession)):
        session.created_at -= gone
        session.token_issued_at -= gone
        session.expires_at -= gone
    db.session.commit()


def test_login_returns_a_refresh_token(app, client):
    register(client)
    body = sign_in(client)
    assert set(body) == {"token", "expiresAt", "refreshToken", "refreshTokenExpiresAt", "supplier"}
    assert body["refreshTokenExpiresAt"].endswith("Z") and body["refreshTokenExpiresAt"] > body["expiresAt"]
    claims = jwt.decode(body["token"], app.config["JWT_SECRET_KEY"], algorithms=["HS256"])
    assert claims["sid"] == body["refreshToken"].split(".")[0]


def test_refreshing_returns_a_new_pair_of_tokens(client):
    register(client)
    first = sign_in(client)
    r = refresh(client, first["refreshToken"])
    assert r.status_code == 200, r.json
    second = r.json
    assert set(second) == set(first)
    assert second["refreshToken"] != first["refreshToken"]
    assert second["supplier"] == first["supplier"]
    assert client.get("/api/supplier/profile", headers=bearer(second)).status_code == 200
    assert refresh(client, second["refreshToken"]).status_code == 200


def test_reusing_a_replaced_refresh_token_signs_the_session_out(client):
    register(client)
    first = sign_in(client)
    newest = refresh(client, first["refreshToken"]).json
    time_passes(minutes=1)

    r = refresh(client, first["refreshToken"])
    assert (r.status_code, r.json) == (401, {"message": SESSION_EXPIRED})
    assert refresh(client, newest["refreshToken"]).status_code == 401  # the whole session is gone
    sign_in(client)  # signing in again works


def test_simultaneous_refreshes_with_one_token_both_succeed(client):
    register(client)
    token = sign_in(client)["refreshToken"]
    first, second = refresh(client, token), refresh(client, token)
    assert first.status_code == second.status_code == 200
    assert first.json["refreshToken"] == second.json["refreshToken"]
    assert refresh(client, second.json["refreshToken"]).status_code == 200


def test_an_unused_session_expires(client):
    register(client)
    token = sign_in(client)["refreshToken"]
    time_passes(days=8)
    assert refresh(client, token).status_code == 401


def test_refresh_rejects_anything_but_a_refresh_token(client):
    register(client)
    signed_in = sign_in(client)
    missing = client.post("/api/auth/refresh", json={})
    assert (missing.status_code, missing.json) == (400, {"message": "refreshToken is required."})
    for token in ("not-a-token", signed_in["token"], signed_in["refreshToken"] + "x"):
        r = refresh(client, token)
        assert (r.status_code, r.json) == (401, {"message": SESSION_EXPIRED})
    # ...and a refresh token is not an access token.
    assert client.get("/api/supplier/profile", headers={"Authorization": f"Bearer {signed_in['refreshToken']}"}).status_code == 401


def test_logout_ends_the_session(client):
    register(client)
    signed_in = sign_in(client)
    assert client.post("/api/auth/logout", json={"refreshToken": signed_in["refreshToken"]}).status_code == 204
    assert refresh(client, signed_in["refreshToken"]).status_code == 401
    # Access tokens aren't checked against the session: this one lasts until it expires.
    assert client.get("/api/supplier/profile", headers=bearer(signed_in)).status_code == 200

    # Signing out again, or with a token that isn't valid, is not an error: the client is signing out anyway.
    assert client.post("/api/auth/logout", json={"refreshToken": signed_in["refreshToken"]}).status_code == 204
    assert client.post("/api/auth/logout", json={"refreshToken": "not-a-token"}).status_code == 204
    assert client.post("/api/auth/logout", json={}).status_code == 400


def test_logout_leaves_other_sessions_alone(client):
    register(client)
    here, elsewhere = sign_in(client), sign_in(client)
    client.post("/api/auth/logout", json={"refreshToken": here["refreshToken"]})
    assert refresh(client, elsewhere["refreshToken"]).status_code == 200


def test_changing_the_password_signs_out_other_sessions(client):
    register(client)
    here, elsewhere = sign_in(client), sign_in(client)
    r = client.post("/api/auth/change-password", json={"currentPassword": PASSWORD, "newPassword": "Newpass@123"},
                    headers=bearer(here))
    assert r.status_code == 204
    assert refresh(client, here["refreshToken"]).status_code == 200
    assert refresh(client, elsewhere["refreshToken"]).status_code == 401


def test_a_failed_password_change_signs_nobody_out(client):
    register(client)
    here, elsewhere = sign_in(client), sign_in(client)
    r = client.post("/api/auth/change-password", json={"currentPassword": "Wrong@1234", "newPassword": "Newpass@123"},
                    headers=bearer(here))
    assert r.status_code == 400
    assert refresh(client, elsewhere["refreshToken"]).status_code == 200
