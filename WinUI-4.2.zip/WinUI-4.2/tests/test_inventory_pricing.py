from datetime import datetime, timedelta, timezone

from conftest import connect_retailer, place_order


def test_stock_adjustments_respect_reservations(app, api):
    product = api.product(stock=10)
    group = api.price_group()
    connect_retailer(app, api.supplier["id"], group["id"])
    place_order(app, api.supplier["id"], 1, [(product["id"], 4, 12.5)])

    item = api.inventory(product["id"])
    assert (item["onHand"], item["reserved"], item["available"]) == (10, 4, 6)

    too_many = api.post(f"/api/inventory/{product['id']}/adjust", {"type": "StockRemoved", "quantity": 7})
    assert too_many.status_code == 400 and "only 6 available" in too_many.json["message"]

    api.post(f"/api/inventory/{product['id']}/adjust", {"type": "StockAdded", "quantity": 15, "remarks": "Delivery"})
    removed = api.post(f"/api/inventory/{product['id']}/adjust", {"type": "StockRemoved", "quantity": 5.0}).json
    assert (removed["onHand"], removed["available"]) == (20, 16)

    history = api.get(f"/api/inventory/{product['id']}/history").json["items"]
    assert [(h["type"], h["quantity"], h["balanceAfter"]) for h in history] == [
        ("StockRemoved", 5, 20), ("StockAdded", 15, 25), ("StockAdded", 10, 10),
    ]
    assert history[1]["remarks"] == "Delivery" and history[1]["performedBy"] == "Asha Verma"


def test_price_list_and_upsert(api):
    product = api.product()
    group = api.price_group()
    items = api.get(f"/api/pricegroups/{group['id']}/prices").json["items"]
    assert items == [{**items[0], "price": None, "effectiveFrom": None, "effectiveTo": None}]

    url = f"/api/pricegroups/{group['id']}/prices/{product['id']}"
    bad = api.put(url, {"price": 10, "effectiveFrom": "2026-11-10T00:00:00", "effectiveTo": "2026-11-01T00:00:00"})
    assert bad.json["message"] == "Effective To cannot be before Effective From."
    assert api.put(url, {"price": 0, "effectiveFrom": "2026-11-10T00:00:00"}).status_code == 400

    set_price = api.put(url, {"price": 12.345, "effectiveFrom": "2026-11-10T00:00:00+05:30", "effectiveTo": None}).json
    assert set_price["price"] == 12.35 and set_price["effectiveFrom"] == "2026-11-10T00:00:00"
    api.put(url, {"price": 11, "effectiveFrom": "2026-11-10"})  # an update, not a second row
    assert api.get("/api/pricegroups").json[0]["productCount"] == 1


def test_every_supplier_has_a_standard_group_that_stays_active(api):
    standard = api.get("/api/pricegroups").json
    assert [(g["name"], g["isDefault"], g["status"]) for g in standard] == [("Standard", True, "Active")]
    standard = standard[0]

    message = "The Standard price group can't be deactivated: retailers without a price group use it."
    assert api.post(f"/api/pricegroups/{standard['id']}/deactivate").json["message"] == message
    inactive = api.put(f"/api/pricegroups/{standard['id']}", {"name": "Standard", "status": "Inactive"})
    assert inactive.status_code == 400 and inactive.json["message"] == message
    renamed = api.put(f"/api/pricegroups/{standard['id']}", {"name": "Standard", "description": "List prices"}).json
    assert renamed["description"] == "List prices" and renamed["isDefault"] is True

    gold = api.price_group("Gold")
    assert gold["isDefault"] is False
    assert [g["name"] for g in api.get("/api/pricegroups").json] == ["Standard", "Gold"]


def test_price_group_deactivation_requires_moving_retailers(app, api):
    gold, platinum = api.price_group("Gold"), api.price_group("Platinum")
    connect_retailer(app, api.supplier["id"], gold["id"])
    assert {g["name"]: g["retailerCount"] for g in api.get("/api/pricegroups").json}["Gold"] == 1

    assert api.post(f"/api/pricegroups/{gold['id']}/deactivate").status_code == 400
    moved = api.put("/api/retailers/1/price-group", {"priceGroupId": platinum["id"]}).json
    assert moved["priceGroupName"] == "Platinum"
    assert api.post(f"/api/pricegroups/{gold['id']}/deactivate").status_code == 204
    assert api.put("/api/retailers/1/price-group", {"priceGroupId": gold["id"]}).status_code == 400
    assert api.post("/api/pricegroups", {"name": "gold"}).status_code == 409


def test_price_matrix_lists_every_active_product_with_its_group_prices(api):
    cola, chips = api.product("COLA", "Cola", stock=1), api.product("CHIPS", "Chips", stock=1)
    old = api.product("OLD", "Discontinued", stock=1)
    api.post(f"/api/products/{old['id']}/deactivate")
    standard, gold = api.price_group("Standard"), api.price_group("Gold")

    # The grid sends only the price: it applies from today (UTC), open ended.
    set_price = api.put(f"/api/pricegroups/{gold['id']}/prices/{cola['id']}", {"price": 42.75}).json
    today = datetime.now(timezone.utc).date().isoformat()
    assert (set_price["price"], set_price["effectiveFrom"], set_price["effectiveTo"]) == (42.75, f"{today}T00:00:00", None)
    api.put(f"/api/pricegroups/{standard['id']}/prices/{cola['id']}", {"price": 45})

    matrix = api.get("/api/pricegroups/matrix").json
    assert matrix["totalCount"] == 2  # new products show at once; deactivated ones don't
    rows = {row["productCode"]: row for row in matrix["items"]}
    assert rows["COLA"]["prices"] == {str(standard["id"]): 45, str(gold["id"]): 42.75}
    assert rows["CHIPS"] == {"productId": chips["id"], "productCode": "CHIPS", "productName": "Chips", "prices": {}}
    assert [row["productCode"] for row in api.get("/api/pricegroups/matrix?search=col").json["items"]] == ["COLA"]

    # Clearing a cell removes the group's price (and is a no-op when there is none).
    assert api.delete(f"/api/pricegroups/{gold['id']}/prices/{cola['id']}").status_code == 204
    assert api.delete(f"/api/pricegroups/{gold['id']}/prices/{chips['id']}").status_code == 204
    assert rows["COLA"]["productId"] == cola["id"]
    cola_prices = next(r for r in api.get("/api/pricegroups/matrix").json["items"] if r["productCode"] == "COLA")["prices"]
    assert cola_prices == {str(standard["id"]): 45}


def test_inventory_summary_values_stock_at_default_group_price(api):
    a, b = api.product("A1", stock=10), api.product("B1", stock=4)
    standard, gold = api.price_group("Standard"), api.price_group("Gold")
    today = datetime.now(timezone.utc).date()  # effectivity is compared with UTC "now"
    api.put(f"/api/pricegroups/{standard['id']}/prices/{a['id']}", {"price": 2.5, "effectiveFrom": today.isoformat()})
    api.put(f"/api/pricegroups/{gold['id']}/prices/{b['id']}", {"price": 100, "effectiveFrom": today.isoformat()})
    future = (today + timedelta(days=5)).isoformat()
    api.put(f"/api/pricegroups/{standard['id']}/prices/{b['id']}", {"price": 9, "effectiveFrom": future})

    summary = api.get("/api/inventory/summary").json
    assert summary == {"productCount": 2, "totalOnHand": 14, "totalReserved": 0, "totalValue": 25.0}


def test_retailer_block_and_activate(app, api):
    group = api.price_group()
    connect_retailer(app, api.supplier["id"], group["id"], retailer_id=7, name="Harbor Foods")
    assert api.post("/api/retailers/7/block").json["status"] == "Blocked"
    assert api.post("/api/retailers/7/activate").json["status"] == "Active"
    assert api.get("/api/retailers?search=harbor").json["items"][0]["id"] == 7
    assert api.post("/api/retailers/8/block").status_code == 404
