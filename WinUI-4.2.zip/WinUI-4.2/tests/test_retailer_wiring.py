"""Retailers, connections and invoice acceptances come from the retailer service's schema."""

from conftest import connect_retailer, place_order
from supplier_service.extensions.database import db
from supplier_service.retailers.models import InvoiceAcceptance, SupplierConnection


def test_retailer_details_come_from_the_retailer_schema(app, api):
    group = api.price_group()
    connect_retailer(app, api.supplier["id"], group["id"], retailer_id=7, name="Harbor Foods")

    retailer = api.get("/api/retailers").json["items"][0]
    assert retailer == {
        "id": 7, "retailerCode": "RTL-000007", "name": "Harbor Foods", "contactPerson": "Ravi Kumar",
        "email": "orders7@retailer.example", "phone": "+91 90000 10000",
        "address": "10, MG Road", "city": "Pune", "state": "Maharashtra", "postalCode": "411005", "country": "India",
        "gstNumber": "27RTL0134F1Z2", "priceGroupId": group["id"], "priceGroupName": "Standard",
        "connectionDate": retailer["connectionDate"], "status": "Active", "gstApplicable": True,
        "circleId": None, "circleName": None, "locationId": None, "locationName": None,
    }
    assert retailer["connectionDate"].endswith("Z")


def test_unassigned_retailers_use_the_standard_price_group(app, api):
    standard, gold = api.price_group("Standard"), api.price_group("Gold")
    connect_retailer(app, api.supplier["id"], None, retailer_id=3)

    retailer = api.get("/api/retailers").json["items"][0]
    assert (retailer["priceGroupId"], retailer["priceGroupName"]) == (standard["id"], "Standard")
    counts = {g["name"]: g["retailerCount"] for g in api.get("/api/pricegroups").json}
    assert counts == {"Standard": 1, "Gold": 0}

    moved = api.put("/api/retailers/3/price-group", {"priceGroupId": gold["id"]}).json
    assert moved["priceGroupName"] == "Gold"
    # Standard stays active even when no retailer is in it.
    assert api.post(f"/api/pricegroups/{standard['id']}/deactivate").status_code == 400


def test_retailers_are_put_in_a_circle_and_location(app, api, other_api):
    for retailer_id, name in ((1, "Green Valley Mart"), (2, "City Fresh Grocers"), (3, "Harbor Foods")):
        connect_retailer(app, api.supplier["id"], None, retailer_id=retailer_id, name=name)
    north = api.post("/api/circles", {"name": "North", "locations": [{"name": "Karol Bagh"}, {"name": "Rohini"}]}).json
    south = api.post("/api/circles", {"name": "South", "locations": [{"name": "Saket"}]}).json
    karol_bagh, rohini = (location["id"] for location in north["locations"])
    saket = south["locations"][0]["id"]

    placed = api.put("/api/retailers/1/area", {"circleId": north["id"], "locationId": karol_bagh}).json
    assert (placed["circleId"], placed["circleName"], placed["locationId"], placed["locationName"]) == (
        north["id"], "North", karol_bagh, "Karol Bagh")
    assert placed["gstApplicable"] is True
    circle_only = api.put("/api/retailers/2/area", {"circleId": north["id"]}).json
    assert (circle_only["circleName"], circle_only["locationId"], circle_only["locationName"]) == ("North", None, None)
    api.put("/api/retailers/3/area", {"circleId": south["id"], "locationId": saket})

    def rejected(body, retailer=1, client=api):
        r = client.put(f"/api/retailers/{retailer}/area", body)
        return r.status_code, r.json["message"] if r.status_code == 400 else None

    assert rejected({"circleId": south["id"], "locationId": rohini}) == (400, "That location isn't in this circle.")
    assert rejected({"circleId": 999}) == (400, "Circle not found.")
    assert rejected({"circleId": north["id"], "locationId": 999}) == (400, "Location not found.")
    assert rejected({"circleId": north["id"]}, retailer=99) == (404, None)
    assert rejected({"circleId": north["id"]}, client=other_api) == (404, None)
    other_circle = other_api.post("/api/circles", {"name": "Mine"}).json  # another supplier's circle isn't usable
    assert rejected({"circleId": other_circle["id"]}) == (400, "Circle not found.")

    def names(query):
        return [r["name"] for r in api.get(f"/api/retailers?{query}").json["items"]]

    assert names(f"circleId={north['id']}") == ["City Fresh Grocers", "Green Valley Mart"]
    assert names(f"circleId={north['id']}&search=green") == ["Green Valley Mart"]
    assert names(f"locationId={karol_bagh}") == ["Green Valley Mart"]
    assert names(f"locationId={rohini}") == []
    assert names("circleId=999") == []
    assert len(names("circleId=")) == 3  # blank: no filter

    # Turning GST off keeps the area; clearing the area keeps the GST setting. No circle clears the location too.
    assert api.put("/api/retailers/1/gst", {"gstApplicable": False}).json["locationName"] == "Karol Bagh"
    cleared = api.put("/api/retailers/1/area", {"circleId": None, "locationId": karol_bagh}).json
    assert (cleared["circleId"], cleared["locationId"], cleared["gstApplicable"]) == (None, None, False)


def test_blocking_writes_the_connection_status(app, api):
    connect_retailer(app, api.supplier["id"], None, retailer_id=3)
    assert api.post("/api/retailers/3/block").json["status"] == "Blocked"
    with app.app_context():
        assert db.session.query(SupplierConnection).one().status == "Blocked"
    assert api.post("/api/retailers/3/activate").json["status"] == "Active"


def test_only_this_suppliers_connections_are_visible(app, api, other_api):
    connect_retailer(app, api.supplier["id"], None, retailer_id=3)
    connect_retailer(app, other_api.supplier["id"], None, retailer_id=4, name="Other Retailer")

    assert [r["id"] for r in api.get("/api/retailers").json["items"]] == [3]
    assert api.post("/api/retailers/4/block").status_code == 404
    assert api.put("/api/retailers/4/price-group", {"priceGroupId": 1}).status_code == 404
    assert api.get("/api/dashboard").json["totalRetailers"] == 1


def test_order_and_invoice_carry_the_retailers_details(app, api):
    product = api.product("COLA", "Cola", stock=50)
    group = api.price_group()
    connect_retailer(app, api.supplier["id"], group["id"], retailer_id=9, name="Metro Supermarket")
    order_id = place_order(app, api.supplier["id"], 9, [(product["id"], 2, 10)])

    order = api.get(f"/api/orders/{order_id}").json
    assert (order["retailerName"], order["retailerCode"], order["retailerEmail"]) == (
        "Metro Supermarket", "RTL-000009", "orders9@retailer.example")
    assert order["retailerAddress"] == "10, MG Road\nPune, Maharashtra, 411005, India"

    line = order["lines"][0]["id"]
    invoice = api.post("/api/invoices", {"orderId": order_id, "lines": [{"orderLineId": line, "invoicedQuantity": 2}]}).json
    assert (invoice["retailerName"], invoice["retailerGst"], invoice["retailerCode"]) == (
        "Metro Supermarket", "27RTL0134F1Z2", "RTL-000009")
    assert invoice["status"] == "Sent"


def test_accepted_invoices_are_reported_as_accepted(app, api):
    product = api.product("COLA", "Cola", stock=50)
    connect_retailer(app, api.supplier["id"], None, retailer_id=9)
    order_id = place_order(app, api.supplier["id"], 9, [(product["id"], 2, 10)])
    line = api.get(f"/api/orders/{order_id}").json["lines"][0]["id"]
    invoice = api.post("/api/invoices", {"orderId": order_id, "lines": [{"orderLineId": line, "invoicedQuantity": 2}]}).json

    with app.app_context():
        db.session.add(InvoiceAcceptance(invoice_id=invoice["id"], retailer_id=9))
        db.session.commit()

    assert api.get("/api/invoices").json["items"][0]["status"] == "Accepted"
    assert api.get(f"/api/invoices/{invoice['id']}").json["status"] == "Accepted"


def test_statuses_set_by_the_retailer_side_are_reported(app, api):
    """Accepting an invoice moves the order to Fulfilled on the retailer side; the supplier sees the same."""
    from supplier_service.orders.models import Order, OrderStatus

    product = api.product("COLA", "Cola", stock=50)
    connect_retailer(app, api.supplier["id"], None, retailer_id=9)
    ids = [place_order(app, api.supplier["id"], 9, [(product["id"], 1, 10)], number=f"ORD-{n}") for n in range(3)]
    with app.app_context():
        for order_id, status in zip(ids, (OrderStatus.FULFILLED, OrderStatus.IN_TRANSIT, OrderStatus.INVOICE_SENT)):
            db.session.get(Order, order_id).status = status
        db.session.commit()

    assert api.get(f"/api/orders/{ids[0]}").json["status"] == "Fulfilled"
    by_status = {o["orderNumber"]: o["status"] for o in api.get("/api/orders").json["items"]}
    assert by_status == {"ORD-0": "Fulfilled", "ORD-1": "InTransit", "ORD-2": "Invoiced"}
    assert [o["orderNumber"] for o in api.get("/api/orders?status=Fulfilled").json["items"]] == ["ORD-0"]
    assert [o["orderNumber"] for o in api.get("/api/orders?status=Invoiced").json["items"]] == ["ORD-2"]
    assert api.get("/api/dashboard").json["orders"][0]["status"] in {"Fulfilled", "InTransit", "Invoiced"}
