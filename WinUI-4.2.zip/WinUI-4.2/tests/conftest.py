import os
from decimal import Decimal

import pytest
from sqlalchemy import event, inspect, text

from supplier_service import create_app
from supplier_service.extensions.database import EXTERNAL_SCHEMAS, SERVICE_SCHEMA, db

SCHEMAS = [SERVICE_SCHEMA, *EXTERNAL_SCHEMAS]

PASSWORD = "Password@123"


@pytest.fixture
def app(tmp_path):
    # SQLite by default; set TEST_DATABASE_URL to run the suite against Postgres.
    app = create_app(
        {
            "TESTING": True,
            "SQLALCHEMY_DATABASE_URI": os.environ.get("TEST_DATABASE_URL", "sqlite://"),
            "JWT_SECRET_KEY": "test-secret-key-0123456789-abcdefghijklmnop",
            "UPLOAD_FOLDER": str(tmp_path / "uploads"),
        }
    )
    with app.app_context():
        _prepare_database()
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()


def _prepare_database() -> None:
    """Gives the service and retailer schemas somewhere to live, and refuses to touch a database with data in it."""
    engine = db.engine
    if engine.dialect.name == "sqlite":
        # In-memory SQLite uses one connection; attach a second database so "retailer.<table>" resolves.
        @event.listens_for(engine, "connect")
        def attach(dbapi_connection, _):
            for schema in SCHEMAS:
                dbapi_connection.execute(f"ATTACH DATABASE ':memory:' AS {schema}")

        return

    # create_all()/drop_all() would otherwise wipe whatever is in the target database.
    inspector = inspect(engine)
    existing = {s: inspector.get_table_names(schema=s) for s in ["public", *SCHEMAS] if s in inspector.get_schema_names()}
    if any(existing.values()):
        pytest.exit(f"TEST_DATABASE_URL points at a database that already has tables ({existing}); use an empty one.", 2)
    with engine.begin() as connection:
        for schema in SCHEMAS:
            connection.execute(text(f"CREATE SCHEMA IF NOT EXISTS {schema}"))


@pytest.fixture
def client(app):
    return app.test_client()


class Api:
    """Test client bound to one supplier's bearer token."""

    def __init__(self, client, token: str, supplier: dict):
        self.client = client
        self.supplier = supplier
        self.headers = {"Authorization": f"Bearer {token}"}

    def get(self, url, **kw):
        return self.client.get(url, headers=self.headers, **kw)

    def post(self, url, json=None, **kw):
        return self.client.post(url, json=json, headers=self.headers, **kw)

    def put(self, url, json=None, **kw):
        return self.client.put(url, json=json, headers=self.headers, **kw)

    def delete(self, url, **kw):
        return self.client.delete(url, headers=self.headers, **kw)

    # -- builders --------------------------------------------------------------------------------

    def category(self, name="Beverages", parent_id=None) -> dict:
        r = self.post("/api/categories", {"name": name, "parentCategoryId": parent_id, "status": "Active"})
        assert r.status_code == 201, r.json
        return r.json

    def product(self, code="P0001", name="Cola 500ml", stock=100, category_id=None) -> dict:
        category_id = category_id or self.category(f"Cat {code}")["id"]
        r = self.post(
            "/api/products",
            {"productCode": code, "name": name, "description": "", "categoryId": category_id,
             "unitOfMeasure": "Bottle", "initialStock": stock, "status": "Active"},
        )
        assert r.status_code == 201, r.json
        return r.json

    def price_group(self, name="Standard") -> dict:
        """The supplier's group with this name; Standard exists from registration, others are created."""
        existing = next((g for g in self.get("/api/pricegroups").json if g["name"] == name), None)
        if existing is not None:
            return existing
        r = self.post("/api/pricegroups", {"name": name, "description": f"{name} tier", "status": "Active"})
        assert r.status_code == 201, r.json
        return r.json

    def inventory(self, product_id: int) -> dict:
        items = self.get("/api/inventory?pageSize=200").json["items"]
        return next(i for i in items if i["productId"] == product_id)


def register(client, email="acme@example.com", company="Acme Traders") -> dict:
    r = client.post(
        "/api/auth/register",
        json={"companyName": company, "contactPerson": "Asha Verma", "email": email, "password": PASSWORD,
              "phone": "+91 98765 43210", "address": "42 Industrial Estate", "city": "Pune", "state": "Maharashtra",
              "country": "India", "postalCode": "411001", "gstNumber": "27abcde1234f1z5"},
    )
    assert r.status_code == 201, r.json
    return r.json


def login(client, email="acme@example.com", password=PASSWORD) -> Api:
    r = client.post("/api/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.json
    return Api(client, r.json["token"], r.json["supplier"])


@pytest.fixture
def api(client) -> Api:
    register(client)
    return login(client)


@pytest.fixture
def other_api(client) -> Api:
    register(client, email="other@example.com", company="Other Supplies")
    return login(client, email="other@example.com")


# -- data the API can't create (retailers and orders arrive from the retailer side) ----------------


def connect_retailer(app, supplier_id: int, price_group_id: int | None, retailer_id=1, name="Green Valley Mart") -> None:
    """A retailer account (the retailer service's table) connected to the supplier.

    price_group_id=None leaves the retailer unassigned, i.e. in the supplier's default group.
    """
    from supplier_service.retailers.models import Retailer, RetailerPriceGroup, SupplierConnection

    with app.app_context():
        db.session.add(
            Retailer(
                id=retailer_id, retailer_code=f"RTL-{retailer_id:06d}", business_name=name, contact_person="Ravi Kumar",
                email=f"orders{retailer_id}@retailer.example", password_hash="x", phone="+91 90000 10000",
                address="10, MG Road", city="Pune", state="Maharashtra", country="India", postal_code="411005",
                gst_number="27RTL0134F1Z2",
            )
        )
        db.session.flush()
        db.session.add(SupplierConnection(retailer_id=retailer_id, supplier_id=supplier_id))
        if price_group_id is not None:
            db.session.add(
                RetailerPriceGroup(supplier_id=supplier_id, retailer_id=retailer_id, price_group_id=price_group_id)
            )
        db.session.commit()


def place_order(app, supplier_id: int, retailer_id: int, lines, number="ORD-0001") -> int:
    """lines: [(product_id, quantity, unit_price)]"""
    from supplier_service.auth.models import Supplier
    from supplier_service.catalogue.models import Product
    from supplier_service.orders.service import create_order

    with app.app_context():
        order = create_order(
            db.session.get(Supplier, supplier_id),
            retailer_id=retailer_id,
            order_number=number,
            lines=[(db.session.get(Product, pid), qty, Decimal(str(price))) for pid, qty, price in lines],
        )
        db.session.commit()
        return order.id
