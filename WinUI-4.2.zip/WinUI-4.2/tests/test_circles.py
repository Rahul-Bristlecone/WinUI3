from conftest import connect_retailer
from sqlalchemy import delete, select

from supplier_service.extensions.database import db
from supplier_service.retailers.models import RetailerSettings, SupplierConnection


def circle(api, name, *locations, **fields) -> dict:
    created = api.post("/api/circles", {"name": name, "locations": [{"name": n} for n in locations], **fields})
    assert created.status_code == 201, created.json
    return created.json


def ids(circle_json) -> dict:
    return {location["name"]: location["id"] for location in circle_json["locations"]}


def edit(api, circle_json, *locations, name=None):
    """locations: names (new or moved here) or (id, name) pairs."""
    items = [{"id": item[0], "name": item[1]} if isinstance(item, tuple) else {"name": item} for item in locations]
    return api.put(f"/api/circles/{circle_json['id']}", {"name": name or circle_json["name"], "state": circle_json["state"], "locations": items})


def message(response) -> tuple:
    return response.status_code, response.json["message"]


def test_states_are_indias_states_and_union_territories(api):
    states = api.get("/api/circles/states").json
    assert len(states) == 36 and states == sorted(states)
    assert (states[0], states[-1], "Delhi" in states) == ("Andaman and Nicobar Islands", "West Bengal", True)


def test_creating_and_listing_circles(api, other_api):
    north = circle(api, "  North   Delhi ", " Rohini ", "Karol   Bagh")
    assert (north["name"], north["state"], north["retailerCount"]) == ("North Delhi", "Delhi", 0)
    assert [(l["name"], l["retailerCount"]) for l in north["locations"]] == [("Karol Bagh", 0), ("Rohini", 0)]
    assert circle(api, "Pune", state="maharashtra")["state"] == "Maharashtra"
    assert circle(api, "Agra", state=None)["state"] == "Delhi"
    assert [c["name"] for c in api.get("/api/circles").json] == ["Agra", "North Delhi", "Pune"]
    assert other_api.get("/api/circles").json == []

    def rejected(body):
        return message(api.post("/api/circles", {"name": "South", **body}))

    assert message(api.post("/api/circles", {"name": " "})) == (400, "name is required.")
    assert message(api.post("/api/circles", {"name": "x" * 61})) == (400, "name can be at most 60 characters.")
    assert message(api.post("/api/circles", {"name": "north delhi"})) == (409, "A circle with this name already exists.")
    assert rejected({"state": "Atlantis"}) == (400, "Choose a state from the list.")
    assert rejected({"locations": [{"name": "x" * 51}]}) == (400, "Location names can be at most 50 characters.")
    assert rejected({"locations": [{"name": "  "}]}) == (400, "Enter a name for each location.")
    assert rejected({"locations": [{"name": "Saket"}, {"name": "saket"}]}) == (400, "“Saket” is listed twice.")
    assert other_api.post("/api/circles", {"name": "North Delhi"}).status_code == 201  # names are per supplier


def test_editing_renames_adds_moves_and_removes_locations(app, api, other_api):
    north = circle(api, "North", "Karol Bagh", "Rohini")
    south = circle(api, "South", "Saket")
    karol_bagh, rohini = ids(north)["Karol Bagh"], ids(north)["Rohini"]
    saket = ids(south)["Saket"]
    connect_retailer(app, api.supplier["id"], None)
    api.put("/api/retailers/1/area", {"circleId": north["id"], "locationId": rohini})
    api.post("/api/ledger/accounts", {"name": "Shree Kirana", "circleId": north["id"], "locationId": rohini})

    renamed = edit(api, north, (karol_bagh, "Karol Bagh West"), "Pitampura", (rohini, "Rohini"), name="North Delhi").json
    assert (renamed["name"], renamed["retailerCount"]) == ("North Delhi", 2)
    assert [(l["name"], l["retailerCount"]) for l in renamed["locations"]] == [("Karol Bagh West", 0), ("Pitampura", 0), ("Rohini", 2)]
    assert ids(renamed)["Karol Bagh West"] == karol_bagh
    assert api.get("/api/retailers").json["items"][0]["locationName"] == "Rohini"

    # A location in use can't be dropped; an unused one can.
    assert message(edit(api, north, (karol_bagh, "Karol Bagh West"))) == (
        400, "“Rohini” is used by 2 retailers. Move it to another circle instead of removing it.")
    assert list(ids(edit(api, renamed, (karol_bagh, "Karol Bagh West"), (rohini, "Rohini")).json)) == ["Karol Bagh West", "Rohini"]

    # Listing another circle's location by name moves it, with its retailers; it keeps its id and takes the typed name.
    moved = edit(api, south, (saket, "Saket"), "rohini").json
    assert (ids(moved), moved["retailerCount"]) == ({"rohini": rohini, "Saket": saket}, 2)
    assert [(c["name"], c["retailerCount"]) for c in api.get("/api/circles").json] == [("North Delhi", 0), ("South", 2)]
    retailer = api.get("/api/retailers").json["items"][0]
    assert (retailer["circleId"], retailer["circleName"], retailer["locationName"]) == (south["id"], "South", "rohini")
    account = api.get("/api/ledger/accounts?type=offline").json["items"][0]
    assert (account["circleName"], account["locationName"]) == ("South", "rohini")

    # Only id-less items move: an existing location can't be renamed onto another circle's.
    assert message(edit(api, north, (karol_bagh, "SAKET"))) == (400, "“Saket” is already in the South circle.")
    assert message(edit(api, north, (saket, "Saket"))) == (400, "Location not found.")
    assert message(edit(api, south, (saket, "Saket"), (saket, "Saket"), (rohini, "Rohini"))) == (400, "“Saket” is listed twice.")
    # An id-less name already in this circle is that location; names can swap; a renamed-away name can be reused.
    assert ids(edit(api, south, "SAKET", (rohini, "Rohini")).json) == {"Rohini": rohini, "SAKET": saket}
    assert ids(edit(api, south, (saket, "Rohini"), (rohini, "Saket")).json) == {"Rohini": saket, "Saket": rohini}
    reused = ids(edit(api, south, (saket, "Old Rohini"), "Rohini", (rohini, "Saket")).json)
    assert reused["Old Rohini"] == saket and reused["Rohini"] not in (saket, rohini)

    assert edit(other_api, south, "Mine").status_code == 404
    assert api.put("/api/circles/999", {"name": "Nowhere"}).status_code == 404


def test_deleting_a_circle(app, api, other_api):
    north = circle(api, "North", "Rohini")
    rohini = ids(north)["Rohini"]
    for retailer_id in (1, 2):
        connect_retailer(app, api.supplier["id"], None, retailer_id=retailer_id, name=f"Retailer {retailer_id}")
        api.put(f"/api/retailers/{retailer_id}/area", {"circleId": north["id"], "locationId": rohini})
    shop = api.post("/api/ledger/accounts", {"name": "Shree Kirana", "circleId": north["id"]}).json

    assert message(api.delete(f"/api/circles/{north['id']}")) == (400, "3 retailers are in this circle. Move them to another circle first.")
    api.put("/api/retailers/1/area", {"circleId": None})
    api.put(f"/api/ledger/accounts/{shop['id']}", {"name": "Shree Kirana"})
    assert message(api.delete(f"/api/circles/{north['id']}")) == (400, "1 retailer is in this circle. Move them to another circle first.")
    assert other_api.delete(f"/api/circles/{north['id']}").status_code == 404

    # A retailer that disconnected isn't counted, can't be moved, and doesn't block the delete: its area is cleared.
    with app.app_context():
        db.session.execute(delete(SupplierConnection).where(SupplierConnection.retailer_id == 2))
        db.session.commit()
    assert api.get("/api/circles").json[0]["retailerCount"] == 0
    assert api.delete(f"/api/circles/{north['id']}").status_code == 204
    assert api.get("/api/circles").json == []
    with app.app_context():
        settings = db.session.scalar(select(RetailerSettings).filter_by(retailer_id=2))
        assert (settings.circle_id, settings.location_id) == (None, None)
    assert api.delete(f"/api/circles/{north['id']}").status_code == 404


def test_removing_a_location_clears_disconnected_retailers(app, api):
    north = circle(api, "North", "Rohini", "Saket")
    connect_retailer(app, api.supplier["id"], None)
    api.put("/api/retailers/1/area", {"circleId": north["id"], "locationId": ids(north)["Rohini"]})
    with app.app_context():
        db.session.execute(delete(SupplierConnection).where(SupplierConnection.retailer_id == 1))
        db.session.commit()

    assert list(ids(edit(api, north, (ids(north)["Saket"], "Saket")).json)) == ["Saket"]
    with app.app_context():
        settings = db.session.scalar(select(RetailerSettings).filter_by(retailer_id=1))
        assert (settings.circle_id, settings.location_id) == (north["id"], None)
