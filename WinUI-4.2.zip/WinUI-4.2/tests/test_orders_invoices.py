from datetime import datetime, timezone

import pytest

from conftest import connect_retailer, place_order


@pytest.fixture
def order(app, api):
    """A pending order: 10 x Cola @ 12.50 and 5 x Chips @ 4.00, from retailer 1."""
    cola = api.product("COLA", "Cola", stock=50)
    chips = api.product("CHIPS", "Chips", stock=30)
    group = api.price_group()
    connect_retailer(app, api.supplier["id"], group["id"])
    order_id = place_order(app, api.supplier["id"], 1, [(cola["id"], 10, 12.5), (chips["id"], 5, 4)])
    detail = api.get(f"/api/orders/{order_id}").json
    lines = {line["productCode"]: line["id"] for line in detail["lines"]}
    return {"id": order_id, "cola": cola["id"], "chips": chips["id"], "lines": lines}


def test_new_order_reserves_stock(api, order):
    detail = api.get(f"/api/orders/{order['id']}").json
    assert detail["status"] == "Pending" and detail["amount"] == 145.0
    assert detail["retailerName"] == "Green Valley Mart" and detail["invoiceId"] is None
    assert [line["invoicedQuantity"] for line in detail["lines"]] == [None, None]
    assert api.inventory(order["cola"])["reserved"] == 10


def test_the_delivery_address_shows_on_the_order_and_its_invoice(app, api, order):
    from supplier_service.extensions.database import db
    from supplier_service.retailers.models import OrderDelivery

    # Orders placed before the retailer service recorded a delivery address have none.
    assert api.get(f"/api/orders/{order['id']}").json["deliveryAddress"] is None
    with app.app_context():
        db.session.add(OrderDelivery(
            order_id=order["id"], retailer_id=1, location_type="Store", name="GodaamPe Store", phone="",
            address="G202", city="Delhi", state="Delhi", country="India", postal_code="110054",
        ))
        db.session.commit()

    expected = {"name": "GodaamPe Store", "locationType": "Store", "phone": "", "address": "G202",
                "city": "Delhi", "state": "Delhi", "postalCode": "110054", "country": "India"}
    assert api.get(f"/api/orders/{order['id']}").json["deliveryAddress"] == expected
    lines = [{"orderLineId": line_id, "invoicedQuantity": 1} for line_id in order["lines"].values()]
    sent = api.post("/api/invoices", {"orderId": order["id"], "lines": lines})
    assert sent.json["deliveryAddress"] == expected
    assert api.get(f"/api/invoices/{sent.json['id']}").json["deliveryAddress"] == expected


def test_invoices_skip_gst_for_retailers_without_it(api, order):
    all_lines = [{"orderLineId": line_id, "invoicedQuantity": qty}
                 for line_id, qty in ((order["lines"]["COLA"], 10), (order["lines"]["CHIPS"], 5))]
    assert api.get(f"/api/orders/{order['id']}").json["gstApplicable"] is True

    retailer = api.put("/api/retailers/1/gst", {"gstApplicable": False}).json
    assert retailer["gstApplicable"] is False
    assert api.get("/api/retailers").json["items"][0]["gstApplicable"] is False
    assert api.get(f"/api/orders/{order['id']}").json["gstApplicable"] is False

    invoice = api.post("/api/invoices", {"orderId": order["id"], "lines": all_lines}).json
    assert (invoice["subtotal"], invoice["taxRate"], invoice["taxAmount"], invoice["amount"]) == (145, 0, 0, 145)

    # Turning GST back on doesn't change the invoice already sent.
    api.put("/api/retailers/1/gst", {"gstApplicable": True})
    assert api.get(f"/api/invoices/{invoice['id']}").json["taxAmount"] == 0
    assert api.put("/api/retailers/99/gst", {"gstApplicable": False}).status_code == 404


def test_reject_releases_stock_and_is_final(api, order):
    rejected = api.post(f"/api/orders/{order['id']}/reject", {"reason": "No delivery slot"}).json
    assert rejected["status"] == "SupplierRejected"
    assert api.inventory(order["cola"])["reserved"] == 0

    detail = api.get(f"/api/orders/{order['id']}").json
    assert detail["rejectionReason"] == "No delivery slot"
    assert [line["invoicedQuantity"] for line in detail["lines"]] == [0, 0]

    assert api.post(f"/api/orders/{order['id']}/reject", {}).json["message"] == "Only pending orders can be rejected."
    lines = [{"orderLineId": order["lines"]["COLA"], "invoicedQuantity": 1}]
    assert api.post("/api/invoices", {"orderId": order["id"], "lines": lines}).status_code == 400


def test_edit_order_then_send_invoice(api, order):
    cola_line, chips_line = order["lines"]["COLA"], order["lines"]["CHIPS"]
    edited = api.put(
        f"/api/orders/{order['id']}/invoiced-quantities", {"lines": [{"orderLineId": cola_line, "invoicedQuantity": 8}]}
    ).json
    # Untouched lines keep their ordered quantity.
    assert {line["productCode"]: line["invoicedQuantity"] for line in edited["lines"]} == {"COLA": 8, "CHIPS": 5}
    assert api.get("/api/invoices").json["totalCount"] == 0  # the draft isn't an invoice yet
    assert api.get("/api/dashboard").json["invoicesSent"] == 0

    sent = api.post(
        "/api/invoices",
        {"orderId": order["id"], "lines": [{"orderLineId": cola_line, "invoicedQuantity": 8},
                                           {"orderLineId": chips_line, "invoicedQuantity": 0}]},
    )
    assert sent.status_code == 201
    invoice = sent.json
    month = datetime.now(timezone.utc).strftime("%Y%m")
    assert invoice["invoiceNumber"] == f"INV-{api.supplier['id']:04d}-{month}-0001"
    assert (invoice["subtotal"], invoice["taxRate"], invoice["taxAmount"], invoice["amount"]) == (100.0, 0.18, 18.0, 118.0)
    assert [(line["productCode"], line["invoicedQuantity"]) for line in invoice["lines"]] == [("COLA", 8)]
    assert invoice["supplier"]["companyName"] == "Acme Traders" and invoice["retailerGst"] == "27RTL0134F1Z2"

    detail = api.get(f"/api/orders/{order['id']}").json
    assert detail["status"] == "Invoiced" and detail["invoiceId"] == invoice["id"]
    assert {line["productCode"]: line["invoicedQuantity"] for line in detail["lines"]} == {"COLA": 8, "CHIPS": 0}

    cola, chips = api.inventory(order["cola"]), api.inventory(order["chips"])
    assert (cola["onHand"], cola["reserved"], chips["onHand"], chips["reserved"]) == (42, 0, 30, 0)
    latest = api.get(f"/api/inventory/{order['cola']}/history").json["items"][0]
    assert (latest["type"], latest["quantity"], latest["balanceAfter"], latest["performedBy"]) == ("StockRemoved", 8, 42, "System")

    assert api.get(f"/api/invoices/{invoice['id']}").json["invoiceNumber"] == invoice["invoiceNumber"]
    listed = api.get("/api/invoices?search=green").json["items"]
    assert [(i["id"], i["status"], i["orderNumber"]) for i in listed] == [(invoice["id"], "Sent", "ORD-0001")]
    again = api.post("/api/invoices", {"orderId": order["id"], "lines": [{"orderLineId": cola_line, "invoicedQuantity": 1}]})
    assert again.json["message"] == "Only pending orders can be invoiced."


@pytest.mark.parametrize(
    "quantities, message",
    [
        ({"COLA": 0, "CHIPS": 0}, "Invoice at least one item."),
        ({"COLA": 2.5}, "Quantity must be a whole number."),
    ],
)
def test_invoice_validation(api, order, quantities, message):
    lines = [{"orderLineId": order["lines"][code], "invoicedQuantity": qty} for code, qty in quantities.items()]
    r = api.post("/api/invoices", {"orderId": order["id"], "lines": lines})
    assert (r.status_code, r.json["message"]) == (400, message)
    neither = api.post("/api/invoices", {"orderId": order["id"], "lines": [{"invoicedQuantity": 1}]})
    assert neither.json["message"] == "Each line needs an order line or a product code."


def test_invoice_cannot_exceed_stock_on_hand(app, api, order):
    # Orders may reserve more than is on hand (50 Cola, 10 + 45 ordered); invoicing can't ship it.
    big = place_order(app, api.supplier["id"], 1, [(order["cola"], 45, 12.5)], number="ORD-0002")
    first = [{"orderLineId": order["lines"]["COLA"], "invoicedQuantity": 10}]
    assert api.post("/api/invoices", {"orderId": order["id"], "lines": first}).status_code == 201

    big_line = api.get(f"/api/orders/{big}").json["lines"][0]["id"]
    r = api.post("/api/invoices", {"orderId": big, "lines": [{"orderLineId": big_line, "invoicedQuantity": 45}]})
    assert (r.status_code, r.json["message"]) == (400, "Cola: only 40 on hand.")


def test_order_list_filter_sort_and_dashboard(app, api, order):
    second = place_order(app, api.supplier["id"], 1, [(order["cola"], 1, 12.5)], number="ORD-0002")
    api.post(f"/api/orders/{second}/reject", {"reason": None})

    assert [o["orderNumber"] for o in api.get("/api/orders?status=Pending").json["items"]] == ["ORD-0001"]
    by_status = api.get("/api/orders?sortBy=status&sortDir=asc").json["items"]
    assert [o["status"] for o in by_status] == ["Pending", "SupplierRejected"]
    assert api.get("/api/orders?search=valley").json["totalCount"] == 2

    dashboard = api.get("/api/dashboard").json
    assert (dashboard["totalProducts"], dashboard["totalRetailers"], dashboard["pendingOrders"]) == (2, 1, 1)
    assert dashboard["orders"][0]["status"] == "Pending"


def test_other_suppliers_orders_are_invisible(api, other_api, order):
    assert other_api.get(f"/api/orders/{order['id']}").status_code == 404
    assert other_api.post(f"/api/orders/{order['id']}/reject", {}).status_code == 404
    lines = [{"orderLineId": order["lines"]["COLA"], "invoicedQuantity": 1}]
    assert other_api.post("/api/invoices", {"orderId": order["id"], "lines": lines}).json["message"] == "Order not found."


def test_seed_demo_command(app):
    runner = app.test_cli_runner()
    assert "Seeded demo@supplier.com" in runner.invoke(args=["seed-demo"]).output
    assert "already exists" in runner.invoke(args=["seed-demo"]).output


def test_edit_order_over_ships_and_adds_products(app, api, order):
    standard = api.price_group()
    water = api.product("WATER", "Water", stock=20)
    api.put(f"/api/pricegroups/{standard['id']}/prices/{water['id']}", {"price": 2.5})
    unpriced = api.product("NOPRICE", "Unpriced", stock=5)
    old = api.post("/api/products", {"productCode": "OLD", "name": "Old", "description": "", "categoryId": water["categoryId"],
                                     "unitOfMeasure": "Bottle", "initialStock": 5, "status": "Inactive"})
    assert old.status_code == 201, old.json

    def lookup(code):
        r = api.get(f"/api/orders/{order['id']}/product-lookup?code={code}")
        return r.status_code, r.json if r.status_code == 200 else r.json["message"]

    assert lookup(" water ") == (200, {"productId": water["id"], "productCode": "WATER", "productName": "Water", "unitPrice": 2.5, "onHand": 20})
    assert lookup("nope") == (404, "No active product with code NOPE.")
    assert lookup("old") == (404, "No active product with code OLD.")
    assert lookup("cola") == (400, "COLA is already on this order.")
    # No price in the retailer's group or Standard: the supplier types one.
    assert lookup("noprice") == (200, {"productId": unpriced["id"], "productCode": "NOPRICE", "productName": "Unpriced", "unitPrice": None, "onHand": 5})
    assert lookup("") == (400, "Enter a product code.")

    cola_line, chips_line = order["lines"]["COLA"], order["lines"]["CHIPS"]

    def draft(*lines):
        return api.put(f"/api/orders/{order['id']}/invoiced-quantities", {"lines": list(lines)})

    # Over-shipping an ordered line, and adding a product: the draft lists it after the order's lines.
    edited = draft({"orderLineId": cola_line, "invoicedQuantity": 12}, {"productCode": "water", "invoicedQuantity": 4}).json
    rows = [(l["id"] is None, l["productCode"], l["quantity"], l["invoicedQuantity"], l["unitPrice"], l["isAdded"]) for l in edited["lines"]]
    assert rows == [(False, "COLA", 10, 12, 12.5, False), (False, "CHIPS", 5, 5, 4, False), (True, "WATER", 0, 4, 2.5, True)]
    # The request's added products replace the draft's.
    assert [l["productCode"] for l in draft({"orderLineId": chips_line, "invoicedQuantity": 3}).json["lines"]] == ["COLA", "CHIPS"]
    assert draft({"productCode": "WATER", "invoicedQuantity": 0}).json["message"] == "WATER: an added product needs a quantity of at least 1."
    twice = draft({"productCode": "WATER", "invoicedQuantity": 1}, {"productCode": "water", "invoicedQuantity": 2})
    assert (twice.status_code, twice.json["message"]) == (400, "WATER is listed twice.")
    assert draft({"productCode": "COLA", "invoicedQuantity": 1}).json["message"] == "COLA is already on this order."

    def send(cola, chips, water):
        lines = [{"orderLineId": cola_line, "invoicedQuantity": cola}, {"orderLineId": chips_line, "invoicedQuantity": chips}]
        return api.post("/api/invoices", {"orderId": order["id"], "lines": lines + [{"productCode": "WATER", "invoicedQuantity": water}]})

    # Stock covers what's shipped, over-shipped and added quantities included.
    assert send(51, 0, 1).json["message"] == "Cola: only 50 on hand."
    assert send(12, 0, 21).json["message"] == "Water: only 20 on hand."
    sent = send(12, 0, 4)
    assert sent.status_code == 201, sent.json
    invoice = sent.json
    assert [(l["productCode"], l["orderedQuantity"], l["invoicedQuantity"], l["lineTotal"]) for l in invoice["lines"]] == [
        ("COLA", 10, 12, 150), ("WATER", 0, 4, 10)]
    assert (invoice["subtotal"], invoice["taxAmount"], invoice["amount"]) == (160, 28.8, 188.8)

    cola, chips, water_stock = api.inventory(order["cola"]), api.inventory(order["chips"]), api.inventory(water["id"])
    assert (cola["onHand"], cola["reserved"], chips["onHand"], chips["reserved"], water_stock["onHand"]) == (38, 0, 30, 0, 16)
    detail = api.get(f"/api/orders/{order['id']}").json
    assert [(l["productCode"], l["invoicedQuantity"], l["isAdded"]) for l in detail["lines"]] == [
        ("COLA", 12, False), ("CHIPS", 0, False), ("WATER", 4, True)]
    assert lookup("water") == (400, "Only pending orders can be edited.")


def test_an_added_product_is_priced_from_the_retailers_group(app, api, order):
    standard, gold = api.price_group("Standard"), api.price_group("Gold")
    water, juice = api.product("WATER", "Water"), api.product("JUICE", "Juice")
    for group, product, price in ((standard, water, 2.5), (gold, water, 2), (standard, juice, 3)):
        api.put(f"/api/pricegroups/{group['id']}/prices/{product['id']}", {"price": price})
    api.put("/api/retailers/1/price-group", {"priceGroupId": gold["id"]})

    def price(code):
        return api.get(f"/api/orders/{order['id']}/product-lookup?code={code}").json["unitPrice"]

    assert (price("WATER"), price("JUICE")) == (2, 3)  # Gold's price, else Standard's


def test_edit_order_changes_line_prices_for_the_invoice_only(app, api, order):
    standard = api.price_group()
    water = api.product("WATER", "Water", stock=20)
    api.put(f"/api/pricegroups/{standard['id']}/prices/{water['id']}", {"price": 2.5})
    api.product("NOPRICE", "Unpriced", stock=5)
    cola_line, chips_line = order["lines"]["COLA"], order["lines"]["CHIPS"]

    def draft(*lines):
        return api.put(f"/api/orders/{order['id']}/invoiced-quantities", {"lines": list(lines)})

    def prices(detail):
        return [(l["productCode"], l["unitPrice"], l["invoicedUnitPrice"]) for l in detail["lines"]]

    # A typed price is rounded to paise; the order keeps its own price.
    edited = draft({"orderLineId": cola_line, "invoicedQuantity": 10, "unitPrice": 11.995},
                   {"productCode": "WATER", "invoicedQuantity": 2, "unitPrice": 3}).json
    assert prices(edited) == [("COLA", 12.5, 12.0), ("CHIPS", 4, None), ("WATER", 3, None)]
    assert edited["amount"] == 145
    # Lines left out keep their planned price; null goes back to the order's price, as does the same price.
    assert prices(draft({"orderLineId": chips_line, "invoicedQuantity": 5, "unitPrice": 4}).json)[:2] == [("COLA", 12.5, 12.0), ("CHIPS", 4, None)]
    assert prices(draft({"orderLineId": cola_line, "invoicedQuantity": 10, "unitPrice": None}).json)[0] == ("COLA", 12.5, None)
    # An added product without a group price needs one typed.
    unpriced = draft({"productCode": "NOPRICE", "invoicedQuantity": 1})
    assert unpriced.json["message"] == "NOPRICE has no price for this retailer. Enter a price, or set one in Price Groups."
    assert prices(draft({"productCode": "NOPRICE", "invoicedQuantity": 1, "unitPrice": 7}).json)[-1] == ("NOPRICE", 7, None)

    for price, message in ((0, "Cola: enter a price above 0."), (-1, "Cola: enter a price above 0."),
                           (0.004, "Cola: enter a price above 0."), (100000000, "Cola: the price can be at most 99,999,999.99.")):
        r = draft({"orderLineId": cola_line, "invoicedQuantity": 1, "unitPrice": price})
        assert (r.status_code, r.json["message"]) == (400, message)

    lines = [{"orderLineId": cola_line, "invoicedQuantity": 10, "unitPrice": 12}, {"orderLineId": chips_line, "invoicedQuantity": 0},
             {"productCode": "WATER", "invoicedQuantity": 2, "unitPrice": 3}]
    invoice = api.post("/api/invoices", {"orderId": order["id"], "lines": lines}).json
    assert [(l["productCode"], l["unitPrice"], l["lineTotal"]) for l in invoice["lines"]] == [("COLA", 12, 120), ("WATER", 3, 6)]
    assert (invoice["subtotal"], invoice["taxAmount"], invoice["amount"]) == (126, 22.68, 148.68)

    detail = api.get(f"/api/orders/{order['id']}").json
    assert (detail["amount"], prices(detail)) == (145, [("COLA", 12.5, 12.0), ("CHIPS", 4, None), ("WATER", 3, None)])
    assert api.get("/api/ledger/accounts").json["items"][0]["balance"] == 148.68
    group_prices = {p["productCode"]: p["price"] for p in api.get(f"/api/pricegroups/{standard['id']}/prices").json["items"]}
    assert group_prices["WATER"] == 2.5
