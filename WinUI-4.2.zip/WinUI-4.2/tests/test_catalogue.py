import io
from pathlib import Path

from PIL import Image



def _image(fmt: str, size: tuple[int, int], mode: str = "RGB", color=(30, 120, 200)) -> bytes:
    """A real image. RGB ones are noise, so the original is much larger than its thumbnail."""
    image = Image.effect_noise(size, 80).convert("RGB") if mode == "RGB" else Image.new(mode, size, color)
    out = io.BytesIO()
    image.save(out, fmt)
    return out.getvalue()


def test_categories(api):
    beverages = api.category("Beverages")
    soft = api.category("Soft Drinks", parent_id=beverages["id"])
    assert soft["parentCategoryName"] == "Beverages"

    assert api.post("/api/categories", {"name": "beverages"}).status_code == 409

    cycle = api.put(f"/api/categories/{beverages['id']}", {"name": "Beverages", "parentCategoryId": soft["id"]})
    assert cycle.status_code == 400

    page = api.get("/api/categories?search=soft").json
    assert [c["name"] for c in page["items"]] == ["Soft Drinks"] and page["totalCount"] == 1

    assert api.post(f"/api/categories/{soft['id']}/deactivate").status_code == 204
    statuses = {c["name"]: c["status"] for c in api.get("/api/categories/all").json}
    assert statuses == {"Beverages": "Active", "Soft Drinks": "Inactive"}


def test_create_product_records_opening_stock(api):
    product = api.product(code="cola-500", stock=25)
    assert product["productCode"] == "COLA-500"
    assert product["currentStock"] == 25

    assert api.inventory(product["id"])["onHand"] == 25
    history = api.get(f"/api/inventory/{product['id']}/history").json["items"]
    assert [(h["type"], h["quantity"], h["balanceAfter"]) for h in history] == [("StockAdded", 25, 25)]


def test_product_validation(api):
    category = api.category()
    body = {"productCode": "P1", "name": "Cola", "categoryId": category["id"], "unitOfMeasure": "Bottle"}
    assert api.post("/api/products", body).status_code == 201
    assert api.post("/api/products", {**body, "productCode": "p1"}).status_code == 409
    assert api.post("/api/products", {**body, "productCode": "P2", "categoryId": 999}).json["message"] == "Category not found."
    fractional = api.post("/api/products", {**body, "productCode": "P3", "initialStock": 2.5})
    assert fractional.status_code == 400 and fractional.json["message"] == "Quantity must be a whole number."


def test_product_barcode_is_optional_and_unique(api):
    category = api.category()
    body = {"productCode": "P1", "name": "Cola", "categoryId": category["id"], "unitOfMeasure": "Bottle", "barcode": "8901234567890"}
    cola = api.post("/api/products", body).json
    assert cola["barcode"] == "8901234567890"
    assert api.post("/api/products", {**body, "productCode": "P2", "barcode": "  "}).json["barcode"] is None
    clash = api.post("/api/products", {**body, "productCode": "P3"})
    assert clash.status_code == 409 and clash.json["message"] == "Barcode '8901234567890' is already in use."


def test_product_list_filters_and_sorting(api):
    category = api.category()
    a = api.product("A1", "Apple Juice", stock=5, category_id=category["id"])
    api.product("B1", "Butter", stock=50, category_id=category["id"])
    api.product("C1", "Cheddar", stock=20, category_id=category["id"])
    api.post(f"/api/products/{a['id']}/deactivate")

    by_stock = api.get("/api/products?sortBy=stock&sortDir=desc").json["items"]
    assert [p["currentStock"] for p in by_stock] == [50, 20, 5]
    assert [p["name"] for p in api.get("/api/products?status=Inactive").json["items"]] == ["Apple Juice"]
    assert [p["productCode"] for p in api.get("/api/products?search=che").json["items"]] == ["C1"]
    paged = api.get("/api/products?page=2&pageSize=2").json
    assert paged["totalCount"] == 3 and len(paged["items"]) == 1 and paged["page"] == 2


def _upload(api, product_id: int, data: bytes, filename: str):
    return api.post(
        f"/api/products/{product_id}/image", data={"file": (io.BytesIO(data), filename)},
        content_type="multipart/form-data",
    )


def _path(url: str) -> str:
    return url.removeprefix("http://localhost")


def test_product_image_upload_replace_and_delete(app, api, client):
    product = api.product()
    original = _image("PNG", (1000, 800))
    first = _upload(api, product["id"], original, "photo.png").json
    url, thumb_url = first["imageUrl"], first["thumbnailUrl"]
    assert url.startswith("http://localhost/media/products/") and url.endswith(".png")
    assert thumb_url == url.removesuffix(".png") + "-thumb.jpg"

    served = client.get(_path(url))  # public: no token needed
    assert served.status_code == 200 and served.data == original
    assert "max-age=31536000" in served.headers["Cache-Control"]
    served.close()

    thumb = client.get(_path(thumb_url))
    with Image.open(io.BytesIO(thumb.data)) as small:
        assert (small.format, small.size) == ("JPEG", (256, 205))  # 1000x800 scaled to fit 256, same ratio
    assert len(thumb.data) < len(original) / 5
    thumb.close()

    folder = Path(app.config["UPLOAD_FOLDER"]) / "products"
    second = _upload(api, product["id"], _image("JPEG", (300, 300)), "photo.jpeg").json
    assert second["imageUrl"].endswith(".jpg") and second["thumbnailUrl"].endswith("-thumb.jpg")
    assert len(list(folder.iterdir())) == 2  # the replaced original and its thumbnail are gone

    listed = api.get("/api/products").json["items"][0]
    assert (listed["imageUrl"], listed["thumbnailUrl"]) == (second["imageUrl"], second["thumbnailUrl"])

    assert api.delete(f"/api/products/{product['id']}/image").status_code == 204
    assert list(folder.iterdir()) == []
    listed = api.get("/api/products").json["items"][0]
    assert (listed["imageUrl"], listed["thumbnailUrl"]) == (None, None)


def test_image_upload_rejects_bad_files(app, api):
    product = api.product()
    url = product["id"]
    assert _upload(api, url, _image("PNG", (10, 10)), "photo.gif").json["message"] == "Only PNG or JPEG images are supported."
    assert _upload(api, url, b"GIF89a" + b"\x00" * 64, "photo.png").json["message"] == "The file is not a valid PNG or JPEG image."
    truncated = _image("PNG", (400, 400))[:200]
    assert _upload(api, url, truncated, "photo.png").json["message"] == "The file is not a valid PNG or JPEG image."
    assert _upload(api, url, _image("JPEG", (50, 50)), "photo.png").status_code == 400  # JPEG data named .png
    assert _upload(api, url, b"", "photo.png").status_code == 400

    app.config["MAX_IMAGE_PIXELS"] = 1000
    assert _upload(api, url, _image("PNG", (100, 100)), "photo.png").json["message"] == "The image's dimensions are too large."
    assert not (Path(app.config["UPLOAD_FOLDER"]) / "products").exists()  # nothing was stored


def test_thumbnail_flattens_transparency_and_keeps_small_images(api, client):
    product = api.product()
    out = _upload(api, product["id"], _image("PNG", (40, 40), mode="RGBA", color=(255, 0, 0, 0)), "logo.png").json
    thumb = client.get(_path(out["thumbnailUrl"]))
    with Image.open(io.BytesIO(thumb.data)) as small:
        assert small.size == (40, 40)  # never enlarged
        assert small.getpixel((20, 20)) == (255, 255, 255)  # fully transparent red became white
    thumb.close()


def test_missing_thumbnail_is_created_on_first_request(app, api, client):
    """Images uploaded before thumbnails existed have an original only."""
    product = api.product()
    out = _upload(api, product["id"], _image("PNG", (600, 600)), "old.png").json
    folder = Path(app.config["UPLOAD_FOLDER"]) / "products"
    thumb_name = out["thumbnailUrl"].rsplit("/", 1)[1]
    (folder / thumb_name).unlink()

    served = client.get(_path(out["thumbnailUrl"]))
    assert served.status_code == 200 and (folder / thumb_name).exists()
    served.close()
    assert client.get("/media/products/1-" + "0" * 32 + "-thumb.jpg").status_code == 404  # no such original
    assert client.get("/media/products/..%2Fsecret-thumb.jpg").status_code == 404


def test_suppliers_cannot_see_each_others_catalogue(api, other_api):
    product = api.product()
    assert other_api.get("/api/products").json["totalCount"] == 0
    edit = {"productCode": "X1", "name": "Taken over", "categoryId": product["categoryId"]}
    assert other_api.put(f"/api/products/{product['id']}", edit).status_code == 404
    assert other_api.post(f"/api/products/{product['id']}/deactivate").status_code == 404
    assert other_api.get(f"/api/inventory/{product['id']}/history").status_code == 404
