"""Development server: `python run.py`. For production, serve wsgi:app with waitress or gunicorn."""

import os

from dotenv import load_dotenv

load_dotenv()

from supplier_service import create_app  # noqa: E402  (after the environment is loaded)

app = create_app()

if __name__ == "__main__":
    app.run(
        host=os.environ.get("HOST", "127.0.0.1"),
        port=int(os.environ.get("PORT", "5000")),
        debug=os.environ.get("FLASK_DEBUG", "0") == "1",
    )
