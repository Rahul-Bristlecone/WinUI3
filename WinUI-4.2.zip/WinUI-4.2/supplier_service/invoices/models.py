from datetime import datetime, timezone
from supplier_service.common.base_model import BaseModel
from supplier_service.extensions.database import db


class InvoiceStatus:
    DRAFT = "Draft"
    SENT = "Invoice Sent"
    ACCEPTED = "Accepted"
    REJECTED = "Rejected"
    VALUES = {DRAFT, SENT, ACCEPTED, REJECTED}


class Invoice(BaseModel):
    __tablename__ = "invoices"
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False, index=True)
    retailer_id = db.Column(db.Integer, nullable=False, index=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False, index=True, unique=True)
    invoice_number = db.Column(db.String(64), nullable=False, unique=True, index=True)
    invoice_date = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    status = db.Column(db.String(30), nullable=False, default=InvoiceStatus.SENT)
    subtotal = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    tax_amount = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    grand_total = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    notes = db.Column(db.Text, nullable=True)
    supplier = db.relationship("Supplier", backref=db.backref("invoices", lazy="dynamic"))
    order = db.relationship("Order", backref=db.backref("invoice", uselist=False, lazy="joined"))
    lines = db.relationship("InvoiceLine", back_populates="invoice", cascade="all, delete-orphan")


class InvoiceLine(BaseModel):
    __tablename__ = "invoice_lines"
    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey("invoices.id"), nullable=False, index=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)
    product_code = db.Column(db.String(64), nullable=False)
    product_name = db.Column(db.String(255), nullable=False)
    ordered_quantity = db.Column(db.Integer, nullable=False, default=0)
    invoiced_quantity = db.Column(db.Integer, nullable=False, default=0)
    unit_price = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    line_total = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    invoice = db.relationship("Invoice", back_populates="lines")
    product = db.relationship("Product", backref=db.backref("invoice_lines", lazy="dynamic"))
