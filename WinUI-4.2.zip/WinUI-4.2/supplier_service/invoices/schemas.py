from decimal import Decimal

from pydantic import Field, model_validator

from supplier_service.common.http import OptionalText, Quantity, RequestSchema, iso_timestamp
from supplier_service.invoices.models import Invoice, InvoiceStatus

# The desktop client's InvoiceStatus enum is Sent | Paid. Drafts are never listed; Accepted and
# Rejected (set by the retailer side) pass through unchanged and need adding to that enum.
# An invoice with a retailer.invoice_acceptances row is reported as Accepted.
API_STATUS = {InvoiceStatus.SENT: "Sent"}
ACCEPTED = "Accepted"


class InvoiceLineInput(RequestSchema):
    """An order line by order_line_id, or a product the supplier adds to the order by product_code.

    An order line's quantity may be more than was ordered (over-shipping). unit_price is the price on this
    invoice only; null keeps the order's price (an added product: the retailer's price-group price)."""

    order_line_id: int | None = None
    product_code: OptionalText = Field(default=None, max_length=64)
    invoiced_quantity: Quantity = Field(ge=0)
    unit_price: Decimal | None = None  # checked in the service, so the message can name the product

    @model_validator(mode="after")
    def _one_line(self):
        if (self.order_line_id is None) == (self.product_code is None):
            raise ValueError("Each line needs an order line or a product code.")
        return self


class InvoiceLinesRequest(RequestSchema):
    lines: list[InvoiceLineInput] = Field(min_length=1)


class CreateInvoiceRequest(InvoiceLinesRequest):
    order_id: int


def invoice_json(invoice: Invoice, order_number: str, retailer_name: str | None, accepted: bool = False) -> dict:
    return {
        "id": invoice.id,
        "invoiceNumber": invoice.invoice_number,
        "orderId": invoice.order_id,
        "orderNumber": order_number,
        "retailerName": retailer_name or f"Retailer #{invoice.retailer_id}",
        "invoiceDate": iso_timestamp(invoice.invoice_date),
        "amount": invoice.grand_total,
        "status": ACCEPTED if accepted else API_STATUS.get(invoice.status, invoice.status),
    }
