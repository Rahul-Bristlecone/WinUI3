"""Invoicing an order.

Edit Order (planned invoiced quantities) is stored as a Draft invoice for the order; sending
the invoice turns that draft into the real one. Invoice lines carry the product rather than the
order item, so lines are matched to order items by product (an order lists each product once).

The supplier may invoice more than was ordered (over-shipping), and may add products the retailer didn't
order: those are invoice lines for a product not on the order, with an ordered quantity of 0. A line's price
can be changed for the invoice alone; the order and the price groups keep theirs.
"""

from collections.abc import Iterable
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal

from flask import current_app
from sqlalchemy import func, select

from supplier_service.auth.models import Supplier
from supplier_service.catalogue.models import Product
from supplier_service.common.base_model import utcnow
from supplier_service.common.errors import ApiError
from supplier_service.extensions.database import db
from supplier_service.inventory.models import ReferenceType, TransactionType
from supplier_service.inventory.service import lock_inventory, record_movement, release
from supplier_service.invoices.models import Invoice, InvoiceLine, InvoiceStatus
from supplier_service.invoices.schemas import InvoiceLineInput
from supplier_service.orders.models import Order, OrderStatus
from supplier_service.orders.service import ensure_transition
from supplier_service.pricing.service import retailer_price
from supplier_service.retailers.service import gst_applicable

MONEY = Decimal("0.01")
MAX_PRICE = Decimal("99999999.99")  # as in Price Groups


@dataclass
class AddedLine:
    """A product the supplier adds to the order, priced as the retailer would pay for it."""

    product: Product
    quantity: int
    unit_price: Decimal


def invoiced_quantities(order: Order) -> dict[int, int | None]:
    """Per order item: the invoiced quantity once sent, the planned one while drafted, else None."""
    if order.status in (OrderStatus.SUPPLIER_REJECT, OrderStatus.CANCELLED):
        return {item.id: 0 for item in order.items}
    invoice = order.invoice
    if invoice is None:
        return {item.id: None for item in order.items}
    by_product = {line.product_id: line.invoiced_quantity for line in invoice.lines}
    missing = None if invoice.status == InvoiceStatus.DRAFT else 0
    return {item.id: by_product.get(item.product_id, missing) for item in order.items}


def invoiced_prices(order: Order) -> dict[int, Decimal | None]:
    """Per order item: the price on its draft or sent invoice line, else None."""
    if order.invoice is None or order.status in (OrderStatus.SUPPLIER_REJECT, OrderStatus.CANCELLED):
        return {item.id: None for item in order.items}
    by_product = {line.product_id: line.unit_price for line in order.invoice.lines}
    return {item.id: by_product.get(item.product_id) for item in order.items}


def added_lines(order: Order) -> list[InvoiceLine]:
    """The products the supplier added to the order, on its draft or sent invoice, in the order they were added."""
    if order.invoice is None or order.status in (OrderStatus.SUPPLIER_REJECT, OrderStatus.CANCELLED):
        return []
    on_order = {item.product_id for item in order.items}
    return sorted((line for line in order.invoice.lines if line.product_id not in on_order), key=lambda line: line.id)


def ensure_editable(order: Order) -> None:
    if order.status != OrderStatus.PENDING:
        raise ApiError(400, "Only pending orders can be edited.")


def addable_product(order: Order, code: str, *, missing_status: int = 400) -> Product:
    """The supplier's active product with this code (ignoring case), if it isn't on the order already."""
    code = code.strip().upper()
    product = db.session.scalar(
        select(Product).where(
            Product.supplier_id == order.supplier_id, func.upper(Product.product_code) == code, Product.is_active.is_(True)
        )
    )
    if product is None:
        raise ApiError(missing_status, f"No active product with code {code}.")
    if any(item.product_id == product.id for item in order.items):
        raise ApiError(400, f"{product.product_code} is already on this order.")
    return product


def group_price(order: Order, product: Product) -> Decimal | None:
    """What the retailer pays for a product added to their order: their price group's price, else Standard's."""
    return retailer_price(order.supplier_id, order.retailer_id, product.id)


def save_draft(order: Order, inputs: Iterable[InvoiceLineInput]) -> Invoice:
    """Order lines not in the request keep their planned quantity and price (the ordered ones if never set);
    the request's added products replace the draft's."""
    ensure_editable(order)
    ordered, added = _validated(order, inputs)
    quantities, prices = invoiced_quantities(order), invoiced_prices(order)
    planned = {
        item.id: (
            item.quantity if quantities[item.id] is None else quantities[item.id],
            item.unit_price if prices[item.id] is None else prices[item.id],
        )
        for item in order.items
    }
    planned.update(ordered)
    if not any(quantity for quantity, _ in planned.values()) and not added:
        raise ApiError(400, "At least one line must have an invoiced quantity. Reject the order instead.")

    invoice = order.invoice
    if invoice is None:
        invoice = Invoice(
            order=order,
            supplier_id=order.supplier_id,
            retailer_id=order.retailer_id,
            invoice_number=f"DRAFT-{order.id}",
            status=InvoiceStatus.DRAFT,
        )
        db.session.add(invoice)
    _fill(invoice, order, planned, added, keep_zero_lines=True)
    return invoice


def send_invoice(order: Order, inputs: Iterable[InvoiceLineInput]) -> Invoice:
    ensure_transition(order, OrderStatus.INVOICE_SENT, "Only pending orders can be invoiced.")
    ordered, added = _validated(order, inputs)
    planned = {item.id: (0, item.unit_price) for item in order.items} | ordered
    if not any(quantity for quantity, _ in planned.values()) and not added:
        raise ApiError(400, "Invoice at least one item.")

    # What leaves the warehouse, over-shipped and added quantities included: (product, quantity), one per product.
    shipped = [(item.product, planned[item.id][0]) for item in order.items] + [(a.product, a.quantity) for a in added]
    stock = lock_inventory(product.id for product, _ in shipped)
    for product, quantity in shipped:
        on_hand = stock[product.id].on_hand_quantity if product.id in stock else 0
        if quantity > on_hand:
            raise ApiError(400, f"{product.product_name}: only {on_hand} on hand.")

    # Serialises invoice numbering per supplier.
    supplier = db.session.execute(select(Supplier).where(Supplier.id == order.supplier_id).with_for_update()).scalar_one()
    number = _next_invoice_number(supplier)

    invoice = order.invoice
    if invoice is None:
        invoice = Invoice(order=order, supplier_id=order.supplier_id, retailer_id=order.retailer_id)
        db.session.add(invoice)
    invoice.invoice_number = number
    invoice.invoice_date = utcnow()
    invoice.status = InvoiceStatus.SENT
    _fill(invoice, order, planned, added, keep_zero_lines=False)

    for item in order.items:
        if item.product_id in stock:
            release(stock[item.product_id], item.quantity)
    for product, quantity in shipped:
        if quantity:
            record_movement(
                stock[product.id], TransactionType.STOCK_REMOVED, quantity,
                reference_type=ReferenceType.INVOICE, reference_id=number,
                remarks=f"Dispatched on invoice {number} (order {order.order_number})",
            )
    order.status = OrderStatus.INVOICE_SENT
    order.invoice_number = number
    order.invoiced_qty = sum(quantity for _, quantity in shipped)
    return invoice


def tax_rate(invoice: Invoice) -> Decimal:
    """Invoices don't store their rate: use the configured one if it explains the stored tax."""
    configured = current_app.config["GST_RATE"]
    expected = (invoice.subtotal * configured).quantize(MONEY, rounding=ROUND_HALF_UP)
    if not invoice.subtotal or abs(expected - invoice.tax_amount) <= MONEY:
        return configured
    return (invoice.tax_amount / invoice.subtotal).quantize(Decimal("0.0001"))


def _validated(
    order: Order, inputs: Iterable[InvoiceLineInput]
) -> tuple[dict[int, tuple[int, Decimal]], list[AddedLine]]:
    """((quantity, price) per order item, added products).

    An order line takes any quantity from 0; more than ordered is over-shipping. An added product must be
    addable (see addable_product) and needs at least 1. A line without a price keeps the order's price, or for
    an added product takes the retailer's price-group price."""
    items = {item.id: item for item in order.items}
    ordered: dict[int, tuple[int, Decimal]] = {}
    added: list[AddedLine] = []
    for line in inputs:
        if line.order_line_id is not None:
            item = items.get(line.order_line_id)
            if item is None:
                raise ApiError(400, f"Order line {line.order_line_id} is not part of this order.")
            price = _typed_price(item.product, line.unit_price)
            ordered[item.id] = (line.invoiced_quantity, item.unit_price if price is None else price)
            continue
        product = addable_product(order, line.product_code)
        if any(other.product.id == product.id for other in added):
            raise ApiError(400, f"{product.product_code} is listed twice.")
        if line.invoiced_quantity < 1:
            raise ApiError(400, f"{product.product_code}: an added product needs a quantity of at least 1.")
        price = _typed_price(product, line.unit_price)
        if price is None:
            price = group_price(order, product)
        if price is None:
            raise ApiError(400, f"{product.product_code} has no price for this retailer. Enter a price, or set one in Price Groups.")
        added.append(AddedLine(product, line.invoiced_quantity, price))
    return ordered, added


def _typed_price(product: Product, price: Decimal | None) -> Decimal | None:
    """A price the supplier typed for this invoice, rounded to paise; None when they didn't."""
    if price is None:
        return None
    if price > MAX_PRICE:
        raise ApiError(400, f"{product.product_name}: the price can be at most 99,999,999.99.")
    price = price.quantize(MONEY, rounding=ROUND_HALF_UP)
    if price <= 0:
        raise ApiError(400, f"{product.product_name}: enter a price above 0.")
    return price


def _fill(
    invoice: Invoice,
    order: Order,
    planned: dict[int, tuple[int, Decimal]],
    added: list[AddedLine],
    *,
    keep_zero_lines: bool,
) -> None:
    """planned: (quantity, price) per order item; a missing item isn't invoiced."""
    invoice.lines.clear()
    for item in sorted(order.items, key=lambda i: i.id):
        quantity, price = planned.get(item.id, (0, item.unit_price))
        if quantity or keep_zero_lines:
            invoice.lines.append(
                InvoiceLine(
                    product_id=item.product_id,
                    product_code=item.product.product_code,
                    product_name=item.product.product_name,
                    ordered_quantity=item.quantity,
                    invoiced_quantity=quantity,
                    unit_price=price,
                    line_total=(price * quantity).quantize(MONEY),
                )
            )
    for line in added:
        invoice.lines.append(
            InvoiceLine(
                product_id=line.product.id,
                product_code=line.product.product_code,
                product_name=line.product.product_name,
                ordered_quantity=0,
                invoiced_quantity=line.quantity,
                unit_price=line.unit_price,
                line_total=(line.unit_price * line.quantity).quantize(MONEY),
            )
        )
    subtotal = sum((line.line_total for line in invoice.lines), Decimal("0"))
    invoice.subtotal = subtotal
    # The retailer's GST setting is read when the invoice is (re)filled, so a sent invoice keeps the tax it was sent with.
    rate = current_app.config["GST_RATE"] if gst_applicable(order.supplier_id, order.retailer_id) else Decimal("0")
    invoice.tax_amount = (subtotal * rate).quantize(MONEY, rounding=ROUND_HALF_UP)
    invoice.grand_total = subtotal + invoice.tax_amount


def _next_invoice_number(supplier: Supplier) -> str:
    # invoice_number is unique across suppliers, so it carries the supplier id; sequence restarts monthly.
    prefix = f"INV-{supplier.id:04d}-{utcnow():%Y%m}-"
    issued = db.session.scalar(
        select(func.count(Invoice.id)).where(Invoice.supplier_id == supplier.id, Invoice.invoice_number.like(f"{prefix}%"))
    )
    return f"{prefix}{issued + 1:04d}"
