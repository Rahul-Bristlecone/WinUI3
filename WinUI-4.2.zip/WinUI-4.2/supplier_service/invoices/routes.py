from flask import Blueprint
from sqlalchemy import or_, select
from sqlalchemy.orm import selectinload

from supplier_service.auth.schemas import profile_json
from supplier_service.common.errors import not_found
from supplier_service.common.http import contains, paginate, parse_body, search_term
from supplier_service.common.security import current_supplier, require_supplier
from supplier_service.extensions.database import db
from supplier_service.invoices.models import Invoice, InvoiceStatus
from supplier_service.invoices.schemas import CreateInvoiceRequest, invoice_json
from supplier_service.invoices.service import send_invoice, tax_rate
from supplier_service.orders.models import Order
from supplier_service.orders.service import owned_order
from supplier_service.retailers.models import InvoiceAcceptance, Retailer
from supplier_service.retailers.service import delivery_address_json

bp = Blueprint("invoices", __name__, url_prefix="/api")
bp.before_request(require_supplier)


def invoice_detail_json(invoice: Invoice) -> dict:
    supplier = current_supplier()
    retailer = db.session.get(Retailer, invoice.retailer_id)
    accepted = db.session.scalar(select(InvoiceAcceptance.id).filter_by(invoice_id=invoice.id)) is not None
    payload = invoice_json(invoice, invoice.order.order_number, retailer.business_name if retailer else None, accepted)
    payload.update(
        {
            "supplier": profile_json(supplier),
            "retailerCode": (retailer.retailer_code if retailer else None) or "",
            "retailerAddress": retailer.full_address if retailer else "",
            "retailerGst": (retailer.gst_number if retailer else None) or "",
            # The order's delivery address (ship to); null for orders placed before the retailer service recorded it.
            "deliveryAddress": delivery_address_json(invoice.order_id),
            "subtotal": invoice.subtotal,
            "taxRate": tax_rate(invoice),
            "taxAmount": invoice.tax_amount,
            "notes": invoice.notes,
            "lines": [
                {
                    "productId": line.product_id,
                    "productCode": line.product_code,
                    "productName": line.product_name,
                    "orderedQuantity": line.ordered_quantity,
                    "invoicedQuantity": line.invoiced_quantity,
                    "unitPrice": line.unit_price,
                    "lineTotal": line.line_total,
                }
                for line in sorted(invoice.lines, key=lambda line: line.id)
            ],
        }
    )
    return payload


@bp.get("/invoices")
def list_invoices():
    stmt = (
        select(Invoice, Order.order_number, Retailer.business_name, InvoiceAcceptance.id.is_not(None))
        .join(Order, Order.id == Invoice.order_id)
        .outerjoin(Retailer, Retailer.id == Invoice.retailer_id)
        .outerjoin(InvoiceAcceptance, InvoiceAcceptance.invoice_id == Invoice.id)
        .where(Invoice.supplier_id == current_supplier().id, Invoice.status != InvoiceStatus.DRAFT)
        .order_by(Invoice.invoice_date.desc(), Invoice.id.desc())
    )
    if term := search_term():
        pattern = contains(term)
        stmt = stmt.where(
            or_(
                Invoice.invoice_number.ilike(pattern, escape="\\"),
                Order.order_number.ilike(pattern, escape="\\"),
                Retailer.business_name.ilike(pattern, escape="\\"),
            )
        )
    return paginate(stmt, lambda row: invoice_json(*row), scalars=False)


@bp.get("/invoices/<int:invoice_id>")
def get_invoice(invoice_id: int):
    invoice = db.session.scalar(
        select(Invoice)
        .where(
            Invoice.id == invoice_id,
            Invoice.supplier_id == current_supplier().id,
            Invoice.status != InvoiceStatus.DRAFT,
        )
        .options(selectinload(Invoice.lines), selectinload(Invoice.order))
    )
    if invoice is None:
        raise not_found()
    return invoice_detail_json(invoice)


@bp.post("/invoices")
def create_invoice():
    body = parse_body(CreateInvoiceRequest)
    order = owned_order(current_supplier().id, body.order_id, lock=True, missing="Order not found.")
    invoice = send_invoice(order, body.lines)
    db.session.commit()
    return invoice_detail_json(invoice), 201
