from sqlalchemy import UniqueConstraint
from supplier_service.catalogue.models import Product
from supplier_service.common.base_model import BaseModel
from supplier_service.extensions.database import db


class TransactionType:
    """inventory_transactions.transaction_type values; named like the client's AdjustmentType enum."""
    STOCK_ADDED = "StockAdded"
    STOCK_REMOVED = "StockRemoved"
    VALUES = {STOCK_ADDED, STOCK_REMOVED}


class ReferenceType:
    """inventory_transactions.reference_type values: what caused the movement."""
    OPENING_STOCK = "opening_stock"
    ADJUSTMENT = "adjustment"
    INVOICE = "invoice"


class Inventory(BaseModel):
    __tablename__ = "inventory"
    __table_args__ = (
        UniqueConstraint("product_id", name="uq_inventory_product_id"),
    )
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)
    on_hand_quantity = db.Column(db.Integer, nullable=False, default=0)
    reserved_quantity = db.Column(db.Integer, nullable=False, default=0)
    available_quantity = db.Column(db.Integer, nullable=False, default=0)
    last_updated = db.Column(db.DateTime, nullable=True)
    product = db.relationship("Product", backref=db.backref("inventory", uselist=False))

    def recalculate_available(self):
        self.available_quantity = self.on_hand_quantity - self.reserved_quantity
        self.last_updated = db.func.now()


class InventoryTransaction(BaseModel):
    __tablename__ = "inventory_transactions"
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)
    transaction_type = db.Column(db.String(64), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=0)
    reference_type = db.Column(db.String(64), nullable=True)
    reference_id = db.Column(db.String(128), nullable=True)
    remarks = db.Column(db.Text, nullable=True)
    product = db.relationship("Product", backref=db.backref("inventory_transactions", lazy="dynamic"))
