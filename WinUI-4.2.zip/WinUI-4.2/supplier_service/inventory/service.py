"""Stock movements. Every change to on-hand stock goes through record_movement(), so the
transaction log always sums to on_hand_quantity (history derives running balances from it)."""

from collections.abc import Iterable

from sqlalchemy import select

from supplier_service.extensions.database import db
from supplier_service.inventory.models import Inventory, InventoryTransaction, TransactionType


def new_inventory(product_id: int) -> Inventory:
    inventory = Inventory(product_id=product_id, on_hand_quantity=0, reserved_quantity=0)
    inventory.recalculate_available()
    return inventory


def lock_inventory(product_ids: Iterable[int]) -> dict[int, Inventory]:
    """SELECT ... FOR UPDATE the inventory rows, in product order so concurrent writers can't deadlock."""
    ids = sorted(set(product_ids))
    if not ids:
        return {}
    rows = db.session.scalars(
        select(Inventory).where(Inventory.product_id.in_(ids)).order_by(Inventory.product_id).with_for_update()
    )
    return {row.product_id: row for row in rows}


def record_movement(
    inventory: Inventory,
    transaction_type: str,
    quantity: int,
    *,
    reference_type: str,
    reference_id: str | None = None,
    remarks: str | None = None,
) -> InventoryTransaction:
    signed = quantity if transaction_type == TransactionType.STOCK_ADDED else -quantity
    inventory.on_hand_quantity += signed
    inventory.recalculate_available()
    transaction = InventoryTransaction(
        product_id=inventory.product_id,
        transaction_type=transaction_type,
        quantity=quantity,
        reference_type=reference_type,
        reference_id=reference_id,
        remarks=remarks,
    )
    db.session.add(transaction)
    return transaction


def reserve(inventory: Inventory, quantity: int) -> None:
    inventory.reserved_quantity += quantity
    inventory.recalculate_available()


def release(inventory: Inventory, quantity: int) -> None:
    inventory.reserved_quantity = max(0, inventory.reserved_quantity - quantity)
    inventory.recalculate_available()
