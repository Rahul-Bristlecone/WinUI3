from typing import Literal

from flask import Blueprint
from pydantic import Field
from sqlalchemy import and_, case, func, or_, select
from sqlalchemy.orm import aliased

from supplier_service.catalogue.models import Product
from supplier_service.catalogue.routes import owned_product
from supplier_service.common.base_model import utcnow
from supplier_service.common.errors import ApiError
from supplier_service.common.http import (
    OptionalText,
    Quantity,
    RequestSchema,
    contains,
    iso_timestamp,
    paginate,
    parse_body,
    search_term,
)
from supplier_service.common.security import current_supplier, require_supplier
from supplier_service.extensions.database import db
from supplier_service.inventory.models import Inventory, InventoryTransaction, ReferenceType, TransactionType
from supplier_service.inventory.service import lock_inventory, new_inventory, record_movement
from supplier_service.pricing.models import PriceGroup, ProductPrice

bp = Blueprint("inventory", __name__, url_prefix="/api")
bp.before_request(require_supplier)


class StockAdjustmentRequest(RequestSchema):
    type: Literal["StockAdded", "StockRemoved"]
    quantity: Quantity = Field(gt=0)
    remarks: OptionalText = Field(default=None, max_length=500)


def inventory_json(inventory: Inventory, product: Product) -> dict:
    return {
        "productId": product.id,
        "productCode": product.product_code,
        "productName": product.product_name,
        "onHand": inventory.on_hand_quantity,
        "reserved": inventory.reserved_quantity,
        "available": inventory.available_quantity,
        "lastUpdated": iso_timestamp(inventory.last_updated or inventory.updated_at),
    }


@bp.get("/inventory")
def list_inventory():
    stmt = (
        select(Inventory, Product)
        .join(Product, Product.id == Inventory.product_id)
        .where(Product.supplier_id == current_supplier().id)
        .order_by(Product.product_code, Product.id)
    )
    if term := search_term():
        pattern = contains(term)
        stmt = stmt.where(or_(Product.product_name.ilike(pattern, escape="\\"), Product.product_code.ilike(pattern, escape="\\")))
    return paginate(stmt, lambda row: inventory_json(*row), scalars=False)


@bp.get("/inventory/summary")
def inventory_summary():
    supplier_id = current_supplier().id
    # Stock is valued at the current price in the supplier's Standard price group.
    default_group = (
        select(PriceGroup.id).where(PriceGroup.supplier_id == supplier_id, PriceGroup.is_default.is_(True))
        .limit(1).scalar_subquery()
    )
    now = utcnow().replace(tzinfo=None)
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    current_price = and_(
        ProductPrice.product_id == Inventory.product_id,
        ProductPrice.price_group_id == default_group,
        ProductPrice.effective_from <= now,
        or_(ProductPrice.effective_to.is_(None), ProductPrice.effective_to >= today),
    )
    count, on_hand, reserved, value = db.session.execute(
        select(
            func.count(Inventory.id),
            func.coalesce(func.sum(Inventory.on_hand_quantity), 0),
            func.coalesce(func.sum(Inventory.reserved_quantity), 0),
            func.coalesce(func.sum(Inventory.on_hand_quantity * ProductPrice.unit_price), 0),
        )
        .join(Product, Product.id == Inventory.product_id)
        .outerjoin(ProductPrice, current_price)
        .where(Product.supplier_id == supplier_id)
    ).one()
    return {"productCount": count, "totalOnHand": on_hand, "totalReserved": reserved, "totalValue": value}


@bp.post("/inventory/<int:product_id>/adjust")
def adjust_stock(product_id: int):
    body = parse_body(StockAdjustmentRequest)
    product = owned_product(product_id)
    inventory = lock_inventory([product.id]).get(product.id)
    if inventory is None:
        inventory = new_inventory(product.id)
        db.session.add(inventory)
    if body.type == TransactionType.STOCK_REMOVED and body.quantity > inventory.available_quantity:
        raise ApiError(
            400,
            f"Cannot remove {body.quantity}; only {inventory.available_quantity} available (excluding reserved stock).",
        )
    record_movement(inventory, body.type, body.quantity, reference_type=ReferenceType.ADJUSTMENT, remarks=body.remarks)
    db.session.commit()
    return inventory_json(inventory, product)


@bp.get("/inventory/<int:product_id>/history")
def stock_history(product_id: int):
    product = owned_product(product_id)
    signed = case(
        (InventoryTransaction.transaction_type == TransactionType.STOCK_ADDED, InventoryTransaction.quantity),
        else_=-InventoryTransaction.quantity,
    )
    balance = func.sum(signed).over(order_by=(InventoryTransaction.created_at, InventoryTransaction.id))
    ledger = (
        select(InventoryTransaction, balance.label("balance_after"))
        .where(InventoryTransaction.product_id == product.id)
        .subquery()
    )
    entry = aliased(InventoryTransaction, ledger)
    stmt = select(entry, ledger.c.balance_after).order_by(ledger.c.created_at.desc(), ledger.c.id.desc())

    # One supplier account per company: manual movements are the supplier's, invoice dispatch is automatic.
    performer = current_supplier().contact_person

    def serialize(row) -> dict:
        txn, balance_after = row
        return {
            "id": txn.id,
            "productId": txn.product_id,
            "date": iso_timestamp(txn.created_at),
            "type": txn.transaction_type,
            "quantity": txn.quantity,
            "balanceAfter": balance_after,
            "remarks": txn.remarks,
            "referenceType": txn.reference_type,
            "referenceId": txn.reference_id,
            "performedBy": "System" if txn.reference_type == ReferenceType.INVOICE else performer,
        }

    return paginate(stmt, serialize, scalars=False)
