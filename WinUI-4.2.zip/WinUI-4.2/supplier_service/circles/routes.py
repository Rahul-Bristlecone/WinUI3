from typing import Annotated

from flask import Blueprint
from pydantic import AfterValidator, Field
from sqlalchemy import func, select

from supplier_service.circles.models import Circle
from supplier_service.circles.service import (
    CIRCLE_NAME_MAX,
    DEFAULT_STATE,
    LOCATION_NAME_MAX,
    STATES,
    circles_json,
    delete_circle,
    listed_state,
    replace_locations,
    tidy,
)
from supplier_service.common.errors import ApiError, not_found
from supplier_service.common.http import RequestSchema, Text, parse_body
from supplier_service.common.security import current_supplier, require_supplier
from supplier_service.extensions.database import db

bp = Blueprint("circles", __name__, url_prefix="/api")
bp.before_request(require_supplier)


def _location_name(value: str) -> str:
    value = tidy(value)
    if not value:
        raise ValueError("Enter a name for each location.")
    if len(value) > LOCATION_NAME_MAX:
        raise ValueError(f"Location names can be at most {LOCATION_NAME_MAX} characters.")
    return value


class LocationItem(RequestSchema):
    id: int | None = None  # null: a new location, or one moved here from another circle by name
    name: Annotated[str, AfterValidator(_location_name)]


class CircleRequest(RequestSchema):
    name: Annotated[Text, AfterValidator(tidy)] = Field(min_length=1, max_length=CIRCLE_NAME_MAX)
    state: Annotated[str | None, AfterValidator(listed_state)] = DEFAULT_STATE  # null or absent: Delhi
    locations: list[LocationItem] = []


@bp.get("/circles/states")
def list_states():
    """India's states and union territories, for a circle's State."""
    return list(STATES)


@bp.get("/circles")
def list_circles():
    return circles_json(current_supplier().id)


@bp.post("/circles")
def create_circle():
    circle = Circle(supplier_id=current_supplier().id)
    _apply_circle(circle, parse_body(CircleRequest))
    db.session.commit()
    return _circle_response(circle), 201


@bp.put("/circles/<int:circle_id>")
def update_circle(circle_id: int):
    """Replaces the name, state and location list (see replace_locations)."""
    circle = _owned_circle(circle_id)
    _apply_circle(circle, parse_body(CircleRequest))
    db.session.commit()
    return _circle_response(circle)


@bp.delete("/circles/<int:circle_id>")
def remove_circle(circle_id: int):
    delete_circle(_owned_circle(circle_id))
    db.session.commit()
    return "", 204


def _owned_circle(circle_id: int) -> Circle:
    circle = db.session.scalar(select(Circle).filter_by(id=circle_id, supplier_id=current_supplier().id))
    if circle is None:
        raise not_found()
    return circle


def _circle_response(circle: Circle) -> dict:
    return circles_json(circle.supplier_id, circle.id)[0]


def _apply_circle(circle: Circle, body: CircleRequest) -> None:
    clash = select(Circle.id).where(Circle.supplier_id == circle.supplier_id, func.lower(Circle.name) == body.name.lower())
    if circle.id is not None:
        clash = clash.where(Circle.id != circle.id)
    if db.session.scalar(clash) is not None:
        raise ApiError(409, "A circle with this name already exists.")
    circle.name = body.name
    circle.state = body.state
    db.session.add(circle)
    db.session.flush()  # a new circle needs its id for its locations
    replace_locations(circle, [(item.id, item.name) for item in body.locations])
