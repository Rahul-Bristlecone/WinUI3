"""Circles: the supplier's sales areas (State → Circle → Location), which retailers are assigned to.

An assignment is a circle and, optionally, one of its locations; a row with a location always carries that
location's circle, also after the location moves to another circle. "Retailers" here are the ones the supplier
can see and reassign: connected retailers (any status) and offline ledger accounts. A disconnected retailer
doesn't count, and its assignment is cleared when its circle or location is removed.
"""

from collections import Counter, defaultdict

from sqlalchemy import and_, delete, select, update

from supplier_service.circles.models import Circle, CircleLocation
from supplier_service.common.errors import ApiError
from supplier_service.extensions.database import db
from supplier_service.ledger.models import LedgerAccount
from supplier_service.retailers.models import RetailerSettings, SupplierConnection

# India's 28 states and 8 union territories.
STATES = (
    "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh",
    "Chhattisgarh", "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Goa", "Gujarat", "Haryana",
    "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Ladakh", "Lakshadweep",
    "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Puducherry",
    "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand",
    "West Bengal",
)
DEFAULT_STATE = "Delhi"
_STATES_BY_KEY = {state.lower(): state for state in STATES}

CIRCLE_NAME_MAX = 60
LOCATION_NAME_MAX = 50

# Every table that holds an assignment: connected retailers' settings and offline ledger accounts.
_ASSIGNED = (RetailerSettings, LedgerAccount)


def tidy(name: str) -> str:
    """Trimmed, inner spaces collapsed: "North   Delhi" is the same name as "North Delhi"."""
    return " ".join(name.split())


def listed_state(value: str | None) -> str:
    """The state as STATES spells it (ignoring case); None means Delhi."""
    if value is None:
        return DEFAULT_STATE
    state = _STATES_BY_KEY.get(tidy(value).lower())
    if state is None:
        raise ValueError("Choose a state from the list.")
    return state


def checked_area(supplier_id: int, circle_id: int | None, location_id: int | None) -> tuple[int | None, int | None]:
    """A requested (circle, location) for a retailer, validated. No circle clears both."""
    if circle_id is None:
        return None, None
    if db.session.scalar(select(Circle.id).filter_by(id=circle_id, supplier_id=supplier_id)) is None:
        raise ApiError(400, "Circle not found.")
    if location_id is not None:
        location = db.session.scalar(select(CircleLocation).filter_by(id=location_id, supplier_id=supplier_id))
        if location is None:
            raise ApiError(400, "Location not found.")
        if location.circle_id != circle_id:
            raise ApiError(400, "That location isn't in this circle.")
    return circle_id, location_id


def area_json(circle: Circle | None, location: CircleLocation | None) -> dict:
    return {
        "circleId": circle.id if circle else None,
        "circleName": circle.name if circle else None,
        "locationId": location.id if location else None,
        "locationName": location.name if location else None,
    }


def retailer_counts(supplier_id: int) -> tuple[Counter, Counter]:
    """(retailers per circle id, retailers per location id), counting connected retailers and offline accounts."""
    connected = (
        select(RetailerSettings.circle_id, RetailerSettings.location_id)
        .join(
            SupplierConnection,
            and_(
                SupplierConnection.supplier_id == RetailerSettings.supplier_id,
                SupplierConnection.retailer_id == RetailerSettings.retailer_id,
            ),
        )
        .where(RetailerSettings.supplier_id == supplier_id, RetailerSettings.circle_id.is_not(None))
    )
    offline = select(LedgerAccount.circle_id, LedgerAccount.location_id).where(
        LedgerAccount.supplier_id == supplier_id, LedgerAccount.retailer_id.is_(None), LedgerAccount.circle_id.is_not(None)
    )
    rows = db.session.execute(connected.union_all(offline)).all()
    return Counter(circle_id for circle_id, _ in rows), Counter(location_id for _, location_id in rows if location_id)


def circles_json(supplier_id: int, circle_id: int | None = None) -> list[dict]:
    """The supplier's circles (or just circle_id) by name, each with its locations by name and retailer counts."""
    circles = select(Circle).filter_by(supplier_id=supplier_id)
    locations = select(CircleLocation).filter_by(supplier_id=supplier_id)
    if circle_id is not None:
        circles, locations = circles.filter_by(id=circle_id), locations.filter_by(circle_id=circle_id)
    in_circle, at_location = retailer_counts(supplier_id)
    by_circle = defaultdict(list)
    for location in sorted(db.session.scalars(locations), key=_by_name):
        by_circle[location.circle_id].append(
            {"id": location.id, "name": location.name, "retailerCount": at_location[location.id]}
        )
    return [
        {
            "id": circle.id,
            "name": circle.name,
            "state": circle.state,
            "retailerCount": in_circle[circle.id],
            "locations": by_circle[circle.id],
        }
        for circle in sorted(db.session.scalars(circles), key=_by_name)
    ]


def replace_locations(circle: Circle, items: list[tuple[int | None, str]]) -> None:
    """Makes the circle's locations exactly `items` ((id or None, tidied name)), as the circle editor sends them.

    With an id: one of this circle's locations, renamed if need be. Without: the supplier's location of that name
    (ignoring case), moved here with its retailers if it's in another circle; else a new location. This circle's
    locations left out are deleted, unless a retailer is at one. The circle must have an id (flush a new one).
    """
    supplier_id = circle.supplier_id
    names = Counter(name.lower() for _, name in items)
    if repeated := next((name for _, name in items if names[name.lower()] > 1), None):
        raise ApiError(400, f"“{repeated}” is listed twice.")
    existing = db.session.scalars(select(CircleLocation).filter_by(supplier_id=supplier_id)).all()
    by_id = {location.id: location for location in existing}
    by_name = {location.name.lower(): location for location in existing}
    listed_ids = Counter(location_id for location_id, _ in items if location_id is not None)

    plan: list[tuple[CircleLocation | None, str]] = []
    for location_id, name in items:
        same_name = by_name.get(name.lower())
        if location_id is None:
            # The location already called this, unless it's also listed by id (it's being renamed away).
            location = same_name if same_name is not None and same_name.id not in listed_ids else None
        else:
            location = by_id.get(location_id)
            if location is None or location.circle_id != circle.id:
                raise ApiError(400, "Location not found.")
            if listed_ids[location_id] > 1:
                raise ApiError(400, f"“{location.name}” is listed twice.")
            if same_name is not None and same_name.circle_id != circle.id:
                other = db.session.get(Circle, same_name.circle_id)
                raise ApiError(400, f"“{same_name.name}” is already in the {other.name} circle.")
        plan.append((location, name))

    kept = {location.id for location, _ in plan if location is not None}
    removed = sorted((l for l in existing if l.circle_id == circle.id and l.id not in kept), key=_by_name)
    _, at_location = retailer_counts(supplier_id)
    for location in removed:
        if count := at_location[location.id]:
            raise ApiError(
                400, f"“{location.name}” is used by {_retailers(count)}. Move it to another circle instead of removing it."
            )

    for location in removed:
        for model in _ASSIGNED:  # only disconnected retailers can still be there
            db.session.execute(update(model).where(model.location_id == location.id).values(location_id=None))
        db.session.delete(location)
    for location, name in plan:
        if location is None:
            db.session.add(CircleLocation(supplier_id=supplier_id, circle_id=circle.id, name=name))
            continue
        if location.circle_id != circle.id:
            location.circle_id = circle.id
            for model in _ASSIGNED:
                db.session.execute(update(model).where(model.location_id == location.id).values(circle_id=circle.id))
        location.name = name


def delete_circle(circle: Circle) -> None:
    """Deletes the circle and its locations, unless a retailer is in it."""
    in_circle, _ = retailer_counts(circle.supplier_id)
    if count := in_circle[circle.id]:
        verb = "is" if count == 1 else "are"
        raise ApiError(400, f"{_retailers(count)} {verb} in this circle. Move them to another circle first.")
    for model in _ASSIGNED:  # only disconnected retailers can still be there
        db.session.execute(update(model).where(model.circle_id == circle.id).values(circle_id=None, location_id=None))
    db.session.execute(delete(CircleLocation).where(CircleLocation.circle_id == circle.id))
    db.session.delete(circle)


def _by_name(row) -> tuple[str, int]:
    return row.name.lower(), row.id


def _retailers(count: int) -> str:
    return f"{count} retailer" if count == 1 else f"{count} retailers"
