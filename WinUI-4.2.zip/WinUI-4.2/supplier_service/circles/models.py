from supplier_service.common.base_model import BaseModel
from supplier_service.extensions.database import db


class Circle(BaseModel):
    """A supplier's sales area within a state, e.g. "North Delhi". Its locations are where its retailers are.

    Retailers are assigned a circle, optionally with one of its locations: online ones in retailer_settings,
    offline ones on their ledger account.
    """

    __tablename__ = "circles"
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False, index=True)
    name = db.Column(db.String(60), nullable=False)  # unique per supplier, ignoring case
    state = db.Column(db.String(60), nullable=False)  # one of service.STATES


class CircleLocation(BaseModel):
    """A location in a circle. Names are unique per supplier (ignoring case), so a location is in exactly one circle."""

    __tablename__ = "circle_locations"
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False, index=True)
    circle_id = db.Column(db.Integer, db.ForeignKey("circles.id"), nullable=False, index=True)
    name = db.Column(db.String(50), nullable=False)
