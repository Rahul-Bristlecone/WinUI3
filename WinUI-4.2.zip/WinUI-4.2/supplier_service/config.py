import os
import re
from datetime import timedelta, timezone
from decimal import Decimal
from pathlib import Path

DEFAULT_DATABASE_URL = "postgresql+psycopg://supplier:supplier@localhost:5432/supplier_service"
SERVICE_ROOT = Path(__file__).resolve().parent.parent


def load_config() -> dict:
    """Configuration from environment variables (see .env.example)."""
    return {
        "SQLALCHEMY_DATABASE_URI": os.environ.get("DATABASE_URL", DEFAULT_DATABASE_URL),
        "SQLALCHEMY_ENGINE_OPTIONS": {"pool_pre_ping": True},
        "JWT_SECRET_KEY": os.environ.get("JWT_SECRET_KEY", ""),
        # Access token (JWT) lifetime; the client renews it with its refresh token (auth/sessions.py).
        "JWT_EXPIRES": _access_token_lifetime(),
        # A sign-in lasts while its refresh token is used at least every REFRESH_IDLE, and never beyond REFRESH_MAX.
        "REFRESH_IDLE": timedelta(days=int(os.environ.get("REFRESH_TOKEN_IDLE_DAYS", "7"))),
        "REFRESH_MAX": timedelta(days=int(os.environ.get("REFRESH_TOKEN_MAX_DAYS", "30"))),
        # How long a just-replaced refresh token still gets the new one back (two refreshes racing), not a revocation.
        "REFRESH_REUSE_GRACE": timedelta(seconds=30),
        "GST_RATE": Decimal(os.environ.get("GST_RATE", "0.18")),
        # The supplier's business day (ledger dates): India Standard Time unless set, e.g. "+05:30".
        "BUSINESS_TIMEZONE": utc_offset(os.environ.get("BUSINESS_UTC_OFFSET", "+05:30")),
        "UPLOAD_FOLDER": os.environ.get("UPLOAD_FOLDER") or str(SERVICE_ROOT / "uploads"),
        # "local" = files on this machine's disk (UPLOAD_FOLDER). See catalogue/storage.py.
        "IMAGE_STORAGE": os.environ.get("IMAGE_STORAGE", "local"),
        "MAX_IMAGE_BYTES": 2 * 1024 * 1024,
        # Decoded size limit: a small file can still expand to a huge bitmap.
        "MAX_IMAGE_PIXELS": 25_000_000,
        "THUMBNAIL_SIZE": 256,
        # Rejects oversized uploads before they are read (413); leaves room for multipart overhead.
        "MAX_CONTENT_LENGTH": 3 * 1024 * 1024,
        # Origin used in imageUrl when the service runs behind a proxy, e.g. https://api.example.com
        "PUBLIC_BASE_URL": os.environ.get("PUBLIC_BASE_URL") or None,
    }


def _access_token_lifetime() -> timedelta:
    minutes = os.environ.get("JWT_ACCESS_EXPIRES_MINUTES")
    if minutes:
        return timedelta(minutes=int(minutes))
    # Before refresh tokens the access token was the whole session (JWT_EXPIRES_HOURS). Keep honouring it, so a
    # client that doesn't refresh yet isn't signed out every few minutes.
    hours = os.environ.get("JWT_EXPIRES_HOURS")
    return timedelta(hours=int(hours)) if hours else timedelta(minutes=15)


def utc_offset(value: str) -> timezone:
    """"+05:30" → a fixed-offset timezone."""
    match = re.fullmatch(r"([+-])(\d{2}):(\d{2})", value.strip())
    if match is None:
        raise ValueError(f"BUSINESS_UTC_OFFSET must look like +05:30, not {value!r}.")
    sign, hours, minutes = match.groups()
    offset = timedelta(hours=int(hours), minutes=int(minutes))
    return timezone(-offset if sign == "-" else offset)


def normalize_database_url(url: str) -> str:
    """Accept postgres://, postgresql:// and postgresql+<driver>:// URLs, but always use the psycopg 3 driver."""
    return re.sub(r"^postgres(?:ql)?(?:\+\w+)?://", "postgresql+psycopg://", url)
