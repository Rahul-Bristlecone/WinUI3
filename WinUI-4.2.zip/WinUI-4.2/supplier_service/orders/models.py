from datetime import datetime, timezone
from sqlalchemy import UniqueConstraint
from supplier_service.catalogue.models import Product
from supplier_service.common.base_model import BaseModel
from supplier_service.extensions.database import db


class OrderStatus:
    PENDING = "Pending"
    CANCELLED = "Cancelled"
    SUPPLIER_REJECT = "Supplier Reject"
    INVOICE_SENT = "Invoice Sent"
    IN_TRANSIT = "In-Transit"
    FULFILLED = "Fulfilled"
    VALUES = {
        PENDING,
        CANCELLED,
        SUPPLIER_REJECT,
        INVOICE_SENT,
        IN_TRANSIT,
        FULFILLED,
    }
    ALLOWED_TRANSITIONS = {
        PENDING: {CANCELLED, SUPPLIER_REJECT, INVOICE_SENT, IN_TRANSIT},
        CANCELLED: set(),
        SUPPLIER_REJECT: set(),
        INVOICE_SENT: {IN_TRANSIT, FULFILLED},
        IN_TRANSIT: {FULFILLED},
        FULFILLED: set(),
    }


class Order(BaseModel):
    __tablename__ = "orders"
    __table_args__ = (
        UniqueConstraint("supplier_id", "order_number", name="uq_supplier_order_number"),
    )
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False, index=True)
    retailer_id = db.Column(db.Integer, nullable=False, index=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)
    store_id = db.Column(db.Integer, nullable=True, index=True)
    order_number = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(50), nullable=False, default=OrderStatus.PENDING)
    order_date = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    ordered_qty = db.Column(db.Integer, nullable=False, default=0)
    invoiced_qty = db.Column(db.Integer, nullable=False, default=0)
    price = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    total_amount = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    notes = db.Column(db.Text, nullable=True)
    invoice_number = db.Column(db.String(64), nullable=True)
    rejection_reason = db.Column(db.Text, nullable=True)
    supplier = db.relationship("Supplier", backref=db.backref("orders", lazy="dynamic"))
    product = db.relationship("Product", backref=db.backref("orders", lazy="dynamic"))
    items = db.relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")


class OrderItem(BaseModel):
    __tablename__ = "order_items"
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False, index=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    unit_price = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    total_amount = db.Column(db.Numeric(12, 2), nullable=False, default=0)
    order = db.relationship("Order", back_populates="items")
    product = db.relationship("Product", backref=db.backref("order_items", lazy="dynamic"))
