from decimal import Decimal

from pydantic import Field
from sqlalchemy import case, select

from supplier_service.common.http import OptionalText, RequestSchema, iso_timestamp
from supplier_service.invoices.models import InvoiceStatus
from supplier_service.invoices.service import added_lines, invoiced_prices, invoiced_quantities
from supplier_service.orders.models import Order, OrderStatus
from supplier_service.retailers.models import Retailer
from supplier_service.retailers.service import delivery_address_json, gst_applicable

# The database values (OrderStatus) as the desktop client's OrderStatus enum names them. In-Transit,
# Fulfilled (set when the retailer accepts the invoice) and Cancelled are set by the retailer side.
API_STATUS = {
    OrderStatus.PENDING: "Pending",
    OrderStatus.SUPPLIER_REJECT: "SupplierRejected",
    OrderStatus.INVOICE_SENT: "Invoiced",
    OrderStatus.IN_TRANSIT: "InTransit",
    OrderStatus.FULFILLED: "Fulfilled",
    OrderStatus.CANCELLED: "Cancelled",
}
STATUS_FILTER = {
    label: {status for status, mapped in API_STATUS.items() if mapped == label} for label in set(API_STATUS.values())
}


class RejectOrderRequest(RequestSchema):
    reason: OptionalText = Field(default=None, max_length=500)


def api_status_expr():
    """SQL expression for the API status label (for sorting by status)."""
    return case(API_STATUS, value=Order.status, else_=Order.status)


def order_rows(supplier_id: int):
    """select(Order, retailer name) for a supplier's orders."""
    return (
        select(Order, Retailer.business_name)
        .outerjoin(Retailer, Retailer.id == Order.retailer_id)
        .where(Order.supplier_id == supplier_id)
    )


def order_json(order: Order, retailer_name: str | None) -> dict:
    return {
        "id": order.id,
        "orderNumber": order.order_number,
        "retailerId": order.retailer_id,
        "retailerName": retailer_name or f"Retailer #{order.retailer_id}",
        "orderDate": iso_timestamp(order.order_date),
        "amount": order.total_amount,
        "status": API_STATUS.get(order.status, order.status),
    }


def order_detail_json(order: Order, retailer: Retailer | None) -> dict:
    invoice = order.invoice
    sent = invoice if invoice is not None and invoice.status != InvoiceStatus.DRAFT else None
    invoiced = invoiced_quantities(order)
    prices = invoiced_prices(order)
    payload = order_json(order, retailer.business_name if retailer else None)
    payload.update(
        {
            "retailerCode": (retailer.retailer_code if retailer else None) or "",
            "retailerEmail": retailer.email if retailer else "",
            "retailerPhone": retailer.phone if retailer else "",
            "retailerAddress": retailer.full_address if retailer else "",
            "deliveryAddress": delivery_address_json(order.id),
            # Whether an invoice raised now would carry GST (the client previews totals with it).
            "gstApplicable": gst_applicable(order.supplier_id, order.retailer_id),
            "storeId": order.store_id,
            "notes": order.notes,
            "rejectionReason": order.rejection_reason,
            "invoiceId": sent.id if sent else None,
            "invoiceNumber": sent.invoice_number if sent else None,
            "lines": [
                {
                    "id": item.id,
                    "productId": item.product_id,
                    "productCode": item.product.product_code,
                    "productName": item.product.product_name,
                    "quantity": item.quantity,
                    "unitPrice": item.unit_price,
                    "lineTotal": item.total_amount,
                    "invoicedQuantity": invoiced[item.id],
                    # The planned (draft) or invoiced price, when the supplier changed it from the order's.
                    "invoicedUnitPrice": prices[item.id] if prices[item.id] not in (None, item.unit_price) else None,
                    "isAdded": False,
                }
                for item in sorted(order.items, key=lambda i: i.id)
            ]
            + [
                # A product the supplier added (Edit Order): nothing was ordered, so there's no order line.
                {
                    "id": None,
                    "productId": line.product_id,
                    "productCode": line.product_code,
                    "productName": line.product_name,
                    "quantity": 0,
                    "unitPrice": line.unit_price,
                    "lineTotal": Decimal("0.00"),
                    "invoicedQuantity": line.invoiced_quantity,
                    "invoicedUnitPrice": None,
                    "isAdded": True,
                }
                for line in added_lines(order)
            ],
        }
    )
    return payload
