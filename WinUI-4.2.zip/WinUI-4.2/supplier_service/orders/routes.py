from flask import Blueprint, request
from sqlalchemy import or_, select

from supplier_service.common.errors import ApiError
from supplier_service.common.http import contains, paginate, parse_body, search_term, sort_descending
from supplier_service.common.security import current_supplier, require_supplier
from supplier_service.extensions.database import db
from supplier_service.inventory.models import Inventory
from supplier_service.invoices.schemas import InvoiceLinesRequest
from supplier_service.invoices.service import addable_product, ensure_editable, group_price, save_draft
from supplier_service.orders.models import Order
from supplier_service.orders.schemas import (
    STATUS_FILTER,
    RejectOrderRequest,
    api_status_expr,
    order_detail_json,
    order_json,
    order_rows,
)
from supplier_service.orders.service import owned_order, reject_order
from supplier_service.retailers.models import Retailer

bp = Blueprint("orders", __name__, url_prefix="/api")
bp.before_request(require_supplier)


@bp.get("/orders")
def list_orders():
    stmt = order_rows(current_supplier().id)
    if term := search_term():
        pattern = contains(term)
        stmt = stmt.where(
            or_(Order.order_number.ilike(pattern, escape="\\"), Retailer.business_name.ilike(pattern, escape="\\"))
        )
    if statuses := STATUS_FILTER.get(request.args.get("status")):
        stmt = stmt.where(Order.status.in_(statuses))

    newest_first = (Order.order_date.desc(), Order.id.desc())
    match request.args.get("sortBy"):
        case "date" if not sort_descending():
            ordering = (Order.order_date.asc(), Order.id.asc())
        case "status":
            label = api_status_expr()
            ordering = (label.desc() if sort_descending() else label.asc(), *newest_first)
        case _:
            ordering = newest_first
    return paginate(stmt.order_by(*ordering), lambda row: order_json(*row), scalars=False)


@bp.get("/orders/<int:order_id>")
def get_order(order_id: int):
    order = owned_order(current_supplier().id, order_id)
    return order_detail_json(order, db.session.get(Retailer, order.retailer_id))


@bp.post("/orders/<int:order_id>/reject")
def reject(order_id: int):
    body = parse_body(RejectOrderRequest)
    order = owned_order(current_supplier().id, order_id, lock=True)
    reject_order(order, body.reason)
    db.session.commit()
    retailer = db.session.get(Retailer, order.retailer_id)
    return order_json(order, retailer.business_name if retailer else None)


@bp.get("/orders/<int:order_id>/product-lookup")
def product_lookup(order_id: int):
    """Edit Order: a product to add by its code, with the price the retailer pays for it (null if their price
    group and Standard both lack one: the supplier types it) and the stock on hand."""
    order = owned_order(current_supplier().id, order_id)
    ensure_editable(order)
    code = request.args.get("code", "").strip()
    if not code:
        raise ApiError(400, "Enter a product code.")
    product = addable_product(order, code, missing_status=404)
    inventory = db.session.scalar(select(Inventory).filter_by(product_id=product.id))
    return {
        "productId": product.id,
        "productCode": product.product_code,
        "productName": product.product_name,
        "unitPrice": group_price(order, product),
        "onHand": inventory.on_hand_quantity if inventory else 0,
    }


@bp.put("/orders/<int:order_id>/invoiced-quantities")
def update_invoiced_quantities(order_id: int):
    body = parse_body(InvoiceLinesRequest)
    order = owned_order(current_supplier().id, order_id, lock=True)
    save_draft(order, body.lines)
    db.session.commit()
    return order_detail_json(order, db.session.get(Retailer, order.retailer_id))
