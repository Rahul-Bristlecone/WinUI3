from datetime import datetime
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from supplier_service.auth.models import Supplier
from supplier_service.catalogue.models import Product
from supplier_service.common.errors import ApiError, not_found
from supplier_service.extensions.database import db
from supplier_service.inventory.service import lock_inventory, release, reserve
from supplier_service.invoices.models import InvoiceStatus
from supplier_service.orders.models import Order, OrderItem, OrderStatus

MONEY = Decimal("0.01")


def owned_order(supplier_id: int, order_id: int, *, lock: bool = False, missing: str | None = None) -> Order:
    stmt = (
        select(Order)
        .where(Order.id == order_id, Order.supplier_id == supplier_id)
        .options(selectinload(Order.items).selectinload(OrderItem.product))
    )
    if lock:
        # OF orders: the invoice backref is joined-eager (an outer join), which FOR UPDATE can't cover.
        stmt = stmt.with_for_update(of=Order)
    order = db.session.scalar(stmt)
    if order is None:
        raise not_found(missing) if missing else not_found()
    return order


def ensure_transition(order: Order, target: str, message: str) -> None:
    if target not in OrderStatus.ALLOWED_TRANSITIONS.get(order.status, set()):
        raise ApiError(400, message)


def create_order(
    supplier: Supplier,
    *,
    retailer_id: int,
    order_number: str,
    lines: list[tuple[Product, int, Decimal]],
    order_date: datetime | None = None,
    store_id: int | None = None,
    notes: str | None = None,
) -> Order:
    """Records an incoming retailer order and reserves its stock.

    Retailers place orders outside this service; this is the entry point an order-intake
    consumer would call (the demo seed uses it). `lines` are (product, quantity, unit price).
    """
    if not lines:
        raise ValueError("An order needs at least one line.")
    order = Order(
        supplier_id=supplier.id,
        retailer_id=retailer_id,
        order_number=order_number,
        store_id=store_id,
        notes=notes,
        status=OrderStatus.PENDING,
    )
    if order_date is not None:
        order.order_date = order_date
    for product, quantity, unit_price in lines:
        order.items.append(
            OrderItem(
                product=product,
                quantity=quantity,
                unit_price=unit_price,
                total_amount=(unit_price * quantity).quantize(MONEY),
            )
        )
    # Header product/price describe the first line; quantity and amount cover all lines.
    order.product = order.items[0].product
    order.price = order.items[0].unit_price
    order.ordered_qty = sum(item.quantity for item in order.items)
    order.total_amount = sum((item.total_amount for item in order.items), Decimal("0"))
    db.session.add(order)

    stock = lock_inventory(product.id for product, _, _ in lines)
    for item in order.items:
        if item.product.id in stock:
            reserve(stock[item.product.id], item.quantity)
    return order


def reject_order(order: Order, reason: str | None) -> None:
    ensure_transition(order, OrderStatus.SUPPLIER_REJECT, "Only pending orders can be rejected.")
    stock = lock_inventory(item.product_id for item in order.items)
    for item in order.items:
        if item.product_id in stock:
            release(stock[item.product_id], item.quantity)
    if order.invoice is not None and order.invoice.status == InvoiceStatus.DRAFT:
        db.session.delete(order.invoice)
    order.status = OrderStatus.SUPPLIER_REJECT
    order.rejection_reason = reason
    order.invoiced_qty = 0
