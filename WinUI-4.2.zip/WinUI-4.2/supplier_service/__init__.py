from flask import Flask
from sqlalchemy import text

from supplier_service.config import load_config, normalize_database_url
from supplier_service.extensions.database import db, migrate, migrate_options


def create_app(overrides: dict | None = None) -> Flask:
    app = Flask(__name__)
    app.config.update(load_config())
    if overrides:
        app.config.update(overrides)
    _check_config(app)

    from supplier_service.common.json_provider import ApiJSONProvider

    app.json = ApiJSONProvider(app)

    db.init_app(app)
    migrate.init_app(app, db, **migrate_options(app.config["SQLALCHEMY_DATABASE_URI"]))
    from supplier_service import models  # noqa: F401  (registers every mapper)

    from supplier_service.common.errors import register_error_handlers

    register_error_handlers(app)
    _register_blueprints(app)

    from supplier_service.seed import seed_demo_command

    app.cli.add_command(seed_demo_command)

    @app.get("/health")
    def health():
        db.session.execute(text("select 1"))
        return {"status": "ok"}

    return app


def _check_config(app: Flask) -> None:
    secret = app.config.get("JWT_SECRET_KEY") or ""
    if len(secret) < 32:
        raise RuntimeError("Set JWT_SECRET_KEY to a random string of at least 32 characters (see .env.example).")

    app.config["SQLALCHEMY_DATABASE_URI"] = normalize_database_url(app.config["SQLALCHEMY_DATABASE_URI"])
    if app.config["SQLALCHEMY_DATABASE_URI"].startswith("postgresql"):
        # Timestamps are stored in UTC "timestamp without time zone" columns; pin the session
        # time zone so server-side now() agrees with the UTC values written from Python.
        options = dict(app.config.get("SQLALCHEMY_ENGINE_OPTIONS") or {})
        options.setdefault("connect_args", {}).setdefault("options", "-c timezone=UTC")
        app.config["SQLALCHEMY_ENGINE_OPTIONS"] = options


def _register_blueprints(app: Flask) -> None:
    from supplier_service.auth.routes import bp as auth_bp
    from supplier_service.catalogue.routes import bp as catalogue_bp, media_bp
    from supplier_service.circles.routes import bp as circles_bp
    from supplier_service.dashboard.routes import bp as dashboard_bp
    from supplier_service.inventory.routes import bp as inventory_bp
    from supplier_service.invoices.routes import bp as invoices_bp
    from supplier_service.ledger.routes import bp as ledger_bp
    from supplier_service.orders.routes import bp as orders_bp
    from supplier_service.pricing.routes import bp as pricing_bp
    from supplier_service.retailers.routes import bp as retailers_bp

    for blueprint in (
        auth_bp, catalogue_bp, media_bp, circles_bp, dashboard_bp, inventory_bp,
        invoices_bp, ledger_bp, orders_bp, pricing_bp, retailers_bp,
    ):
        app.register_blueprint(blueprint)
