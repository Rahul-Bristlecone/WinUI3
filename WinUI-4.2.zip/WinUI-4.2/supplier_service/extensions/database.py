from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import MetaData

# Deterministic constraint names so Alembic migrations can reference (and drop) them.
NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

# Every table of this service lives in its own schema (Table(schema=...) overrides it for the retailer
# service's tables, which this service maps but doesn't own).
SERVICE_SCHEMA = "supplier"
EXTERNAL_SCHEMAS = {"retailer"}


def skip_external_tables(obj, name, type_, reflected, compare_to) -> bool:
    """Alembic include_object hook: tables in another service's schema are never created, altered or dropped."""
    return not (type_ == "table" and getattr(obj, "schema", None) in EXTERNAL_SCHEMAS)


def include_service_schema_only(name, type_, parent_names) -> bool:
    """Alembic include_name hook: reflect only this service's schema (not public, not the retailer service's)."""
    return name == SERVICE_SCHEMA if type_ == "schema" else True


def migrate_options(database_uri: str) -> dict:
    """Flask-Migrate/Alembic options. Schemas are a PostgreSQL feature; other databases keep Alembic's defaults."""
    options = {"include_object": skip_external_tables}
    if database_uri.startswith("postgresql"):
        options |= {
            "include_schemas": True,
            "include_name": include_service_schema_only,
            "version_table_schema": SERVICE_SCHEMA,
        }
    return options


db = SQLAlchemy(metadata=MetaData(schema=SERVICE_SCHEMA, naming_convention=NAMING_CONVENTION))
migrate = Migrate()
