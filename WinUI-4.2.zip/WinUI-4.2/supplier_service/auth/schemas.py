import re

from pydantic import Field, field_validator

from supplier_service.auth.models import Supplier
from supplier_service.common.http import OptionalText, RequestSchema, Text

# Same rules the desktop client validates with (SupplierPortal/ViewModels/Forms/AccountForms.cs).
PASSWORD_RULE = re.compile(r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$")
PASSWORD_MESSAGE = "Password must be at least 8 characters with upper-case, lower-case and a digit."
PHONE_RULE = re.compile(r"^[+0-9\-\s()]{7,20}$")
GST_RULE = re.compile(r"^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$")
POSTAL_RULE = re.compile(r"^[A-Za-z0-9\- ]{3,10}$")
EMAIL_RULE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _email(value: str) -> str:
    if not EMAIL_RULE.fullmatch(value):
        raise ValueError("Enter a valid email address.")
    return value.lower()


def _password(value: str) -> str:
    if not PASSWORD_RULE.fullmatch(value):
        raise ValueError(PASSWORD_MESSAGE)
    return value


class LoginRequest(RequestSchema):
    email: Text = Field(min_length=1, max_length=255)
    password: str = Field(min_length=1)

    @field_validator("email")
    @classmethod
    def _lower(cls, value: str) -> str:
        return value.lower()


class RefreshRequest(RequestSchema):
    """Body of refresh and logout. No length limit: anything that isn't a refresh token gets the same 401."""

    refresh_token: Text = Field(min_length=1)


class ProfileRequest(RequestSchema):
    company_name: Text = Field(min_length=1, max_length=255)
    contact_person: Text = Field(min_length=1, max_length=255)
    phone: Text = Field(min_length=1, max_length=50)
    address: Text = Field(min_length=1, max_length=1000)
    city: Text = Field(min_length=1, max_length=120)
    state: Text = Field(min_length=1, max_length=120)
    country: Text = Field(min_length=1, max_length=120)
    postal_code: Text = Field(min_length=1, max_length=30)
    gst_number: OptionalText = Field(default=None, max_length=50)

    @field_validator("phone")
    @classmethod
    def _phone(cls, value: str) -> str:
        if not PHONE_RULE.fullmatch(value):
            raise ValueError("Enter a valid phone number.")
        return value

    @field_validator("postal_code")
    @classmethod
    def _postal_code(cls, value: str) -> str:
        if not POSTAL_RULE.fullmatch(value):
            raise ValueError("Enter a valid postal code.")
        return value

    @field_validator("gst_number")
    @classmethod
    def _gst_number(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = value.upper()
        if not GST_RULE.fullmatch(value):
            raise ValueError("Enter a valid 15-character GSTIN (e.g. 27ABCDE1234F1Z5).")
        return value

    def apply_to(self, supplier: Supplier) -> None:
        supplier.company_name = self.company_name
        supplier.contact_person = self.contact_person
        supplier.phone = self.phone
        supplier.address = self.address
        supplier.city = self.city
        supplier.state = self.state
        supplier.country = self.country
        supplier.postal_code = self.postal_code
        supplier.gst_number = self.gst_number


class RegisterRequest(ProfileRequest):
    email: Text = Field(min_length=1, max_length=255)
    password: str = Field(min_length=1, max_length=128)

    _check_email = field_validator("email")(_email)
    _check_password = field_validator("password")(_password)


class ChangePasswordRequest(RequestSchema):
    current_password: str = Field(min_length=1)
    new_password: str = Field(min_length=1, max_length=128)

    _check_password = field_validator("new_password")(_password)


def profile_json(supplier: Supplier) -> dict:
    return {
        "id": supplier.id,
        "supplierCode": supplier.supplier_code,
        "companyName": supplier.company_name,
        "contactPerson": supplier.contact_person,
        "email": supplier.email,
        "phone": supplier.phone,
        "address": supplier.address,
        "city": supplier.city,
        "state": supplier.state,
        "country": supplier.country,
        "postalCode": supplier.postal_code,
        "gstNumber": supplier.gst_number or "",
    }
