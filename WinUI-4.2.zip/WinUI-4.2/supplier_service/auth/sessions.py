"""Sign-in sessions and their refresh tokens.

Signing in starts a session and returns two tokens: a short-lived access token (a JWT, common/security.py) that
goes with every request, and a refresh token that POST api/auth/refresh trades for a new pair. Every refresh
rotates the refresh token: the client must keep the new one, and the old one stops working.

A refresh token is "<session public id>.<generation>.<signature>", where the signature is an HMAC-SHA256 of the
first two parts under JWT_SECRET_KEY. The database stores no token, only each session's current generation, so:
- A stale generation means the token was copied: the client always keeps the newest. Presenting one revokes the
  whole session, which signs out both the copy's holder and the user (who signs in again).
- Two requests that refresh with the same token at the same moment both succeed. For REFRESH_REUSE_GRACE after a
  rotation, the previous generation is answered with the current token (tokens are derived, so the same one can
  be issued twice) instead of counting as reuse.
- Changing JWT_SECRET_KEY invalidates every refresh token, as it does every access token.
"""

import base64
import hashlib
import hmac
import logging
import re
import secrets
from datetime import datetime

from flask import current_app
from sqlalchemy import delete, or_, select, update

from supplier_service.auth.models import Supplier, SupplierSession
from supplier_service.common.base_model import utcnow
from supplier_service.common.errors import ApiError
from supplier_service.common.security import SESSION_EXPIRED
from supplier_service.extensions.database import db

log = logging.getLogger(__name__)

REVOKED_SIGN_OUT = "sign_out"
REVOKED_REUSE = "reuse"
REVOKED_PASSWORD_CHANGE = "password_change"

_TOKEN = re.compile(r"([A-Za-z0-9_-]{1,32})\.([0-9]{1,9})\.([A-Za-z0-9_-]{43})")


def start_session(supplier: Supplier) -> SupplierSession:
    """A new session for a supplier who just proved their password. Also deletes their sessions that have ended."""
    now = _now()
    db.session.execute(
        delete(SupplierSession).where(
            SupplierSession.supplier_id == supplier.id,
            or_(SupplierSession.revoked_at.is_not(None), SupplierSession.expires_at <= now),
        )
    )
    session = SupplierSession(
        supplier=supplier, public_id=secrets.token_urlsafe(16), generation=0, token_issued_at=now, created_at=now,
    )
    session.expires_at = _expiry(session, now)
    db.session.add(session)
    return session


def refresh_token(session: SupplierSession) -> str:
    """The session's current refresh token."""
    return f"{session.public_id}.{session.generation}.{_signature(session.public_id, session.generation)}"


def refresh_session(token: str) -> SupplierSession:
    """Rotates the session `token` belongs to, so refresh_token() gives its successor. 401 if it can't be used.

    Presenting a replaced token (outside the grace period) revokes the session, and that is committed here."""
    parsed = _parse(token)
    if parsed is None:
        raise ApiError(401, SESSION_EXPIRED)
    public_id, generation = parsed
    # Locked so that two refreshes of one session take turns: the second sees the first one's rotation.
    session = db.session.scalar(select(SupplierSession).filter_by(public_id=public_id).with_for_update())
    now = _now()
    if session is None or session.revoked_at is not None or session.expires_at <= now or not session.supplier.is_active:
        raise ApiError(401, SESSION_EXPIRED)

    if generation == session.generation:
        session.generation += 1
        session.token_issued_at = now
        session.expires_at = _expiry(session, now)
    elif generation == session.generation - 1 and now - session.token_issued_at <= current_app.config["REFRESH_REUSE_GRACE"]:
        pass  # a concurrent refresh just rotated it; this caller gets the same new token
    else:
        _revoke(session, REVOKED_REUSE, now)
        db.session.commit()
        log.warning("Refresh token reused: session %s of supplier %s revoked.", session.id, session.supplier_id)
        raise ApiError(401, SESSION_EXPIRED)
    return session


def end_session(token: str) -> None:
    """Sign-out: revokes the session `token` belongs to, from any of its generations. A token that isn't valid, or
    whose session has already ended, is ignored: the client is signing out either way."""
    parsed = _parse(token)
    if parsed is None:
        return
    session = db.session.scalar(select(SupplierSession).filter_by(public_id=parsed[0]))
    if session is not None and session.revoked_at is None:
        _revoke(session, REVOKED_SIGN_OUT, _now())


def revoke_other_sessions(supplier: Supplier, keep: str | None, reason: str) -> None:
    """Revokes the supplier's sessions except the one whose public id is `keep` (None: all of them)."""
    stmt = update(SupplierSession).where(
        SupplierSession.supplier_id == supplier.id, SupplierSession.revoked_at.is_(None)
    )
    if keep is not None:
        stmt = stmt.where(SupplierSession.public_id != keep)
    db.session.execute(stmt.values(revoked_at=_now(), revoked_reason=reason))


def _revoke(session: SupplierSession, reason: str, now: datetime) -> None:
    session.revoked_at = now
    session.revoked_reason = reason


def _expiry(session: SupplierSession, now: datetime) -> datetime:
    """REFRESH_IDLE from now, but no later than REFRESH_MAX after sign-in."""
    config = current_app.config
    return min(now + config["REFRESH_IDLE"], session.created_at + config["REFRESH_MAX"])


def _signature(public_id: str, generation: int) -> str:
    key = current_app.config["JWT_SECRET_KEY"].encode()
    digest = hmac.new(key, f"refresh:{public_id}.{generation}".encode(), hashlib.sha256).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode()


def _parse(token: str) -> tuple[str, int] | None:
    """(public id, generation) of a refresh token this service signed, or None."""
    match = _TOKEN.fullmatch(token)
    if match is None:
        return None
    public_id, generation, signature = match.group(1), int(match.group(2)), match.group(3)
    if not hmac.compare_digest(signature, _signature(public_id, generation)):
        return None
    return public_id, generation


def _now() -> datetime:
    return utcnow().replace(tzinfo=None)  # naive UTC, as the columns store it
