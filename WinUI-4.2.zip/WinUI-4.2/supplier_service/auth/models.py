import re
from datetime import datetime, timezone
from sqlalchemy import UniqueConstraint
from supplier_service.common.base_model import BaseModel
from supplier_service.extensions.database import db


class Supplier(BaseModel):
    __tablename__ = "suppliers"
    __table_args__ = (
        UniqueConstraint("email", name="uq_suppliers_email"),
        UniqueConstraint("supplier_code", name="uq_suppliers_supplier_code"),
    )
    id = db.Column(db.Integer, primary_key=True)
    supplier_code = db.Column(db.String(32), unique=True, nullable=False, index=True)
    company_name = db.Column(db.String(255), nullable=False)
    contact_person = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False, unique=True, index=True)
    phone = db.Column(db.String(50), nullable=False)
    address = db.Column(db.Text, nullable=False)
    state = db.Column(db.String(120), nullable=False)
    city = db.Column(db.String(120), nullable=False)
    country = db.Column(db.String(120), nullable=False)
    postal_code = db.Column(db.String(30), nullable=False)
    gst_number = db.Column(db.String(50), nullable=True)
    password_hash = db.Column(db.String(255), nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)

    def set_password(self, password: str) -> None:
        from werkzeug.security import generate_password_hash
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        from werkzeug.security import check_password_hash
        return check_password_hash(self.password_hash, password)

    @staticmethod
    def generate_supplier_code(company_name: str) -> str:
        cleaned = re.sub(r"[^A-Za-z0-9]", "", (company_name or "").strip())
        cleaned = cleaned.upper()
        if not cleaned:
            prefix = "GDP"
        else:
            prefix = cleaned[:4]
            if len(prefix) < 4:
                prefix = (prefix + "X" * (4 - len(prefix)))[:4]
        today = datetime.now(timezone.utc).strftime("%Y%m%d")
        return f"GDP-{prefix}-{today}"

    def to_dict(self):
        payload = super().to_dict()
        payload.pop("password_hash", None)
        return payload


class SupplierSession(BaseModel):
    """One sign-in. Its refresh token changes on every refresh; auth/sessions.py has the rules.

    No token is stored: tokens are signed, and this row only says which generation is the current one.
    Timestamps are naive UTC, like the rest of the schema.
    """

    __tablename__ = "supplier_sessions"
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False, index=True)
    # Names the session inside its tokens. Random rather than the row id, so ids can't be enumerated.
    public_id = db.Column(db.String(32), nullable=False, unique=True)
    # Bumped by every refresh; only the token for the current generation can be refreshed.
    generation = db.Column(db.Integer, nullable=False, default=0)
    token_issued_at = db.Column(db.DateTime, nullable=False)  # when the current generation was issued
    expires_at = db.Column(db.DateTime, nullable=False)  # when the current refresh token stops working
    revoked_at = db.Column(db.DateTime, nullable=True)
    revoked_reason = db.Column(db.String(20), nullable=True)  # one of sessions.REVOKED_*

    supplier = db.relationship(Supplier)
