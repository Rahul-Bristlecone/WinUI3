"""`flask seed-demo`: the desktop client's mock data set (Services/Mock/MockDatabase.cs), in Postgres.

Also inserts 14 demo retailers (codes RTL-D00001...) into the retailer schema."""

import random
from datetime import datetime, time, timedelta
from decimal import Decimal

import click
from flask.cli import with_appcontext
from sqlalchemy import select
from werkzeug.security import generate_password_hash

from supplier_service.auth.models import Supplier
from supplier_service.catalogue.models import Category, Product
from supplier_service.common.base_model import utcnow
from supplier_service.extensions.database import db
from supplier_service.inventory.models import ReferenceType, TransactionType
from supplier_service.inventory.service import new_inventory, record_movement
from supplier_service.invoices.schemas import InvoiceLineInput
from supplier_service.invoices.service import send_invoice
from supplier_service.orders.service import create_order, reject_order
from supplier_service.pricing.models import STANDARD_GROUP, PriceGroup, ProductPrice
from supplier_service.retailers.models import Retailer, RetailerPriceGroup, RetailerStatus, SupplierConnection

DEMO_EMAIL = "demo@supplier.com"
DEMO_PASSWORD = "Password@123"

CATEGORIES = [
    ("Beverages", None), ("Soft Drinks", "Beverages"), ("Juices", "Beverages"),
    ("Snacks", None), ("Chips", "Snacks"), ("Dairy", None), ("Household", None),
]
PRICE_GROUPS = [("Standard", Decimal("1.00")), ("Gold", Decimal("0.95")), ("Platinum", Decimal("0.90"))]
CATALOGUE = [
    ("Cola 500ml", "Bottle", "Soft Drinks"), ("Lemon Soda 500ml", "Bottle", "Soft Drinks"),
    ("Orange Fizz 1L", "Bottle", "Soft Drinks"), ("Mango Juice 1L", "Carton", "Juices"),
    ("Apple Juice 1L", "Carton", "Juices"), ("Mixed Fruit Juice 200ml", "Pack", "Juices"),
    ("Salted Chips 100g", "Pack", "Chips"), ("Masala Chips 100g", "Pack", "Chips"),
    ("Cheese Puffs 80g", "Pack", "Snacks"), ("Roasted Peanuts 250g", "Pack", "Snacks"),
    ("Whole Milk 1L", "Carton", "Dairy"), ("Butter 500g", "Block", "Dairy"),
    ("Cheddar Cheese 200g", "Block", "Dairy"), ("Plain Yogurt 400g", "Cup", "Dairy"),
    ("Dish Soap 750ml", "Bottle", "Household"), ("Laundry Detergent 2kg", "Pack", "Household"),
    ("Paper Towels 6pk", "Pack", "Household"), ("Mineral Water 1L", "Bottle", "Beverages"),
    ("Green Tea 25 bags", "Box", "Beverages"), ("Instant Coffee 200g", "Jar", "Beverages"),
    ("Energy Drink 250ml", "Can", "Soft Drinks"), ("Tonic Water 300ml", "Bottle", "Soft Drinks"),
    ("Coconut Water 330ml", "Carton", "Juices"), ("Tortilla Chips 200g", "Pack", "Chips"),
    ("Trail Mix 300g", "Pack", "Snacks"), ("Cream 250ml", "Carton", "Dairy"),
    ("Glass Cleaner 500ml", "Bottle", "Household"), ("Trash Bags 30ct", "Roll", "Household"),
    ("Sparkling Water 500ml", "Bottle", "Beverages"), ("Iced Tea 500ml", "Bottle", "Beverages"),
]
RETAILERS = [
    "Green Valley Mart", "City Fresh Grocers", "Metro Supermarket", "Daily Needs Store", "Sunrise Retail",
    "Harbor Foods", "Corner Basket", "Urban Pantry", "Value Hub", "Family Mart", "Prime Provisions",
    "Lakeside Stores", "Hilltop Grocers", "Royal Retail",
]
CITIES = [("Pune", "411005"), ("Mumbai", "400050"), ("Nashik", "422005"), ("Nagpur", "440012")]
STREETS = [
    "MG Road, Shivaji Nagar", "FC Road, Deccan", "Linking Road, Bandra West",
    "College Road, Gangapur", "Wardha Road, Dhantoli", "Station Road, Camp",
]


@click.command("seed-demo")
@with_appcontext
def seed_demo_command() -> None:
    """Create the demo supplier (demo@supplier.com / Password@123) with catalogue, retailers and orders."""
    if db.session.scalar(select(Supplier.id).filter_by(email=DEMO_EMAIL)) is not None:
        click.echo(f"{DEMO_EMAIL} already exists; nothing to do.")
        return
    supplier = seed_demo()
    db.session.commit()
    click.echo(f"Seeded {DEMO_EMAIL} / {DEMO_PASSWORD} (supplier code {supplier.supplier_code}).")


def seed_demo() -> Supplier:
    rng = random.Random(42)
    password_hash = generate_password_hash(DEMO_PASSWORD)
    today = datetime.combine(utcnow().date(), time.min)

    supplier = Supplier(
        email=DEMO_EMAIL, supplier_code=Supplier.generate_supplier_code("Acme Distribution Pvt Ltd"),
        company_name="Acme Distribution Pvt Ltd", contact_person="Asha Verma", phone="+91 98765 43210",
        address="42 Industrial Estate, Phase II", city="Pune", state="Maharashtra", country="India",
        postal_code="411001", gst_number="27ABCDE1234F1Z5",
    )
    supplier.set_password(DEMO_PASSWORD)
    db.session.add(supplier)
    db.session.flush()

    categories: dict[str, Category] = {}
    for name, parent in CATEGORIES:
        categories[name] = Category(supplier_id=supplier.id, category_name=name, parent_category=categories.get(parent))
        db.session.add(categories[name])

    groups = [
        PriceGroup(supplier_id=supplier.id, group_name=name, description=f"{name} tier pricing", is_default=name == STANDARD_GROUP)
        for name, _ in PRICE_GROUPS
    ]
    db.session.add_all(groups)
    db.session.flush()

    products, inventories, prices = [], {}, {}
    for index, (name, uom, category) in enumerate(CATALOGUE, start=1):
        product = Product(
            supplier_id=supplier.id, product_code=f"P{index:04d}", product_name=name,
            description=f"{name} – supplier catalogue item.", category=categories[category], unit_of_measure=uom,
        )
        db.session.add(product)
        db.session.flush()
        products.append(product)

        inventory = new_inventory(product.id)
        db.session.add(inventory)
        record_movement(
            inventory, TransactionType.STOCK_ADDED, rng.randint(40, 599),
            reference_type=ReferenceType.OPENING_STOCK, remarks="Opening stock",
        )
        inventories[product.id] = inventory

        base_price = Decimal(rng.randint(20, 899)) / 10
        for group, (_, factor) in zip(groups, PRICE_GROUPS):
            unit_price = (base_price * factor).quantize(Decimal("0.01"))
            prices[group.id, product.id] = unit_price
            db.session.add(ProductPrice(
                price_group_id=group.id, product_id=product.id, unit_price=unit_price,
                effective_from=today - timedelta(days=90),
            ))

    # Retailers belong to the retailer service. The demo creates its own (ids come from that schema's
    # sequence, so they can't collide with real retailers) and connects them to the demo supplier.
    retailers, group_of = [], {}
    for index, name in enumerate(RETAILERS, start=1):
        city, pin = CITIES[(index - 1) % len(CITIES)]
        retailer = Retailer(
            retailer_code=f"RTL-D{index:05d}", business_name=name, contact_person=f"{name} Manager",
            email=f"orders@{name.replace(' ', '').lower()}.example", password_hash=password_hash,
            phone=f"+91 90000 {10000 + (index - 1) * 137}",
            address=f"{index * 7 % 90 + 10}, {STREETS[index % len(STREETS)]}", city=city, state="Maharashtra",
            country="India", postal_code=pin, gst_number=f"27RTL{index:02d}34F1Z{index % 9 + 1}",
        )
        db.session.add(retailer)
        db.session.flush()
        group_of[retailer.id] = groups[(index - 1) % len(groups)]
        db.session.add(SupplierConnection(
            retailer_id=retailer.id, supplier_id=supplier.id,
            status=RetailerStatus.BLOCKED if index == 10 else RetailerStatus.ACTIVE,
            connected_at=today - timedelta(days=rng.randint(30, 400)),
        ))
        db.session.add(RetailerPriceGroup(
            supplier_id=supplier.id, retailer_id=retailer.id, price_group_id=group_of[retailer.id].id,
        ))
        retailers.append(retailer)
    db.session.flush()

    for i in range(24):
        retailer = rng.choice(retailers)
        order_date = today - timedelta(days=24 - i)
        picked = list({p.id: p for p in (rng.choice(products) for _ in range(rng.randint(1, 4)))}.values())
        order = create_order(
            supplier, retailer_id=retailer.id, order_number=f"ORD-{order_date:%Y%m}-{i + 1:04d}",
            order_date=order_date,
            lines=[(p, rng.randint(5, 59), prices[group_of[retailer.id].id, p.id]) for p in picked],
        )
        db.session.flush()
        if i < 8:
            lines = [
                InvoiceLineInput(
                    order_line_id=item.id,
                    invoiced_quantity=min(item.quantity, inventories[item.product_id].on_hand_quantity),
                )
                for item in order.items
            ]
            send_invoice(order, lines)
        elif i < 11:
            reject_order(order, "Out of stock for requested delivery window.")
        db.session.flush()
    return supplier
