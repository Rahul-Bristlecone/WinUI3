from datetime import date, datetime
from decimal import Decimal

from flask.json.provider import DefaultJSONProvider


class ApiJSONProvider(DefaultJSONProvider):
    """Money as JSON numbers (Flask's default writes Decimal as a string) and ISO-8601 dates."""

    sort_keys = False

    @staticmethod
    def default(o):
        if isinstance(o, Decimal):
            # NUMERIC(12,2) has at most 12 significant digits, which a float round-trips exactly.
            return float(o)
        if isinstance(o, (datetime, date)):
            return o.isoformat()
        return DefaultJSONProvider.default(o)
