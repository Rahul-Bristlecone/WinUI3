import logging

from flask import Flask, jsonify
from sqlalchemy.exc import IntegrityError
from werkzeug.exceptions import HTTPException

from supplier_service.extensions.database import db

log = logging.getLogger(__name__)

NOT_FOUND = "The requested item could not be found."


class ApiError(Exception):
    """Raised by handlers; rendered as {"message": ...} with the given status (the client's ErrorResponse)."""

    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def not_found(message: str = NOT_FOUND) -> ApiError:
    return ApiError(404, message)


_HTTP_MESSAGES = {
    404: "Unknown endpoint.",
    405: "This endpoint does not support that method.",
    413: "The request is too large.",
}


def register_error_handlers(app: Flask) -> None:
    @app.errorhandler(ApiError)
    def _api_error(error: ApiError):
        return jsonify(message=error.message), error.status

    @app.errorhandler(IntegrityError)
    def _integrity_error(error: IntegrityError):
        # Uniqueness is checked up front; this is the lost-race case (two writers at once).
        db.session.rollback()
        log.warning("Integrity error: %s", error.orig)
        return jsonify(message="This change conflicts with existing data. Refresh and try again."), 409

    @app.errorhandler(HTTPException)
    def _http_error(error: HTTPException):
        status = error.code or 500
        message = _HTTP_MESSAGES.get(status, error.description if status < 500 else "An unexpected error occurred.")
        return jsonify(message=message), status
