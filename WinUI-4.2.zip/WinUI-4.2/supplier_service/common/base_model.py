from datetime import date, datetime, timezone
from decimal import Decimal

from supplier_service.extensions.database import db


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class BaseModel(db.Model):
    """Abstract base for every table: audit timestamps (UTC) and a column-level to_dict()."""

    __abstract__ = True

    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=utcnow, onupdate=utcnow)

    def to_dict(self) -> dict:
        payload = {}
        for column in self.__table__.columns:
            value = getattr(self, column.key)
            if isinstance(value, (datetime, date)):
                value = value.isoformat()
            elif isinstance(value, Decimal):
                value = float(value)
            payload[column.key] = value
        return payload
