"""Request parsing, paging and wire formatting shared by the API blueprints.

Wire format (what the desktop client expects): camelCase JSON, enums as strings,
paged lists as {items, totalCount, page, pageSize}, errors as {message}.
"""

from collections.abc import Callable
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Annotated, Literal, TypeVar

from flask import request
from pydantic import AfterValidator, BaseModel as Schema, BeforeValidator, ConfigDict, StringConstraints, ValidationError
from pydantic.alias_generators import to_camel
from sqlalchemy import Select, func, select

from supplier_service.common.errors import ApiError
from supplier_service.extensions.database import db

RecordStatus = Literal["Active", "Inactive"]


class RequestSchema(Schema):
    """Base for request bodies: camelCase on the wire, unknown fields ignored."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


def _blank_to_none(value):
    return None if isinstance(value, str) and not value.strip() else value


def _whole_number(value: Decimal) -> int:
    if value != value.to_integral_value():
        raise ValueError("Quantity must be a whole number.")
    return int(value)


def _calendar_date(value):
    if isinstance(value, str):
        try:
            # Keep the calendar day the client picked; don't shift it into UTC.
            return datetime.fromisoformat(value).date()
        except ValueError:
            raise ValueError("Enter a valid date.") from None
    if isinstance(value, datetime):
        return value.date()
    return value


Text = Annotated[str, StringConstraints(strip_whitespace=True)]
OptionalText = Annotated[Text | None, BeforeValidator(_blank_to_none)]
# Stock is stored as integers; the client sends decimals, so accept 5 or 5.0 but not 5.5.
Quantity = Annotated[Decimal, AfterValidator(_whole_number)]
CalendarDate = Annotated[date, BeforeValidator(_calendar_date)]

S = TypeVar("S", bound=Schema)


def parse_body(schema: type[S]) -> S:
    payload = request.get_json(silent=True)
    if payload is None:
        payload = {}
    if not isinstance(payload, dict):
        raise ApiError(400, "The request body must be a JSON object.")
    try:
        return schema.model_validate(payload)
    except ValidationError as error:
        raise ApiError(400, _describe(error)) from None


def _describe(error: ValidationError) -> str:
    detail = error.errors(include_url=False)[0]
    field = ".".join(str(part) for part in detail["loc"]) or "body"
    kind, ctx = detail["type"], detail.get("ctx") or {}
    if kind == "value_error":
        return str(ctx.get("error", detail["msg"]))
    if kind == "missing" or (kind == "string_too_short" and ctx.get("min_length") == 1):
        return f"{field} is required."
    if kind == "string_too_long":
        return f"{field} can be at most {ctx['max_length']} characters."
    if kind == "greater_than":
        return f"{field} must be greater than {ctx['gt']}."
    return f"{field}: {detail['msg']}."


# ---- query strings ------------------------------------------------------------------------------


def search_term() -> str | None:
    return request.args.get("search", "").strip() or None


def contains(term: str) -> str:
    """ILIKE pattern matching `term` anywhere; use with escape="\\\\"."""
    escaped = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


def sort_descending(default: bool = False) -> bool:
    """sortDir=asc|desc; `default` when it's absent."""
    direction = request.args.get("sortDir")
    return direction == "desc" if direction else default


def query_date(name: str) -> date | None:
    """A calendar date from the query string ("2026-11-04"), or None when absent."""
    value = request.args.get(name, "").strip()
    if not value:
        return None
    try:
        return datetime.fromisoformat(value).date()
    except ValueError:
        raise ApiError(400, f"{name}: enter a valid date.") from None


def _page_and_size() -> tuple[int, int]:
    page = max(request.args.get("page", 1, type=int), 1)
    size = min(max(request.args.get("pageSize", 20, type=int), 1), 200)
    return page, size


def paginate(stmt: Select, serialize: Callable, *, scalars: bool = True) -> dict:
    page, size = _page_and_size()
    total = db.session.scalar(select(func.count()).select_from(stmt.order_by(None).subquery()))
    result = db.session.execute(stmt.limit(size).offset((page - 1) * size))
    rows = result.scalars().all() if scalars else result.all()
    return {"items": [serialize(row) for row in rows], "totalCount": total or 0, "page": page, "pageSize": size}


def paginate_list(items: list) -> dict:
    """paginate() for items already in memory, e.g. sorted by a value computed in Python."""
    page, size = _page_and_size()
    return {"items": items[(page - 1) * size:page * size], "totalCount": len(items), "page": page, "pageSize": size}


# ---- response values ----------------------------------------------------------------------------


def iso_timestamp(value: datetime | None) -> str | None:
    """An instant as ISO-8601 UTC ("...Z"). Naive values read back from the database are UTC."""
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def iso_calendar_date(value: date | datetime | None) -> str | None:
    """A calendar date (e.g. price effectivity) as midnight with no offset."""
    if value is None:
        return None
    day = value.date() if isinstance(value, datetime) else value
    return f"{day.isoformat()}T00:00:00"


def record_status(is_active: bool) -> RecordStatus:
    return "Active" if is_active else "Inactive"
