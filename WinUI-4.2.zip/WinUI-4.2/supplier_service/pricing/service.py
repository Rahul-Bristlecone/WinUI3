from decimal import Decimal

from sqlalchemy import or_, select

from supplier_service.common.base_model import utcnow
from supplier_service.extensions.database import db
from supplier_service.pricing.models import PriceGroup, ProductPrice
from supplier_service.retailers.models import RetailerPriceGroup


def retailer_price(supplier_id: int, retailer_id: int, product_id: int) -> Decimal | None:
    """The product's current price in the retailer's price group, else in the supplier's Standard group.

    None if neither prices it today.
    """
    assigned = db.session.scalar(
        select(RetailerPriceGroup.price_group_id).filter_by(supplier_id=supplier_id, retailer_id=retailer_id)
    )
    standard = db.session.scalar(select(PriceGroup.id).filter_by(supplier_id=supplier_id, is_default=True))
    now = utcnow().replace(tzinfo=None)
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    for group_id in (assigned, standard):
        if group_id is None:
            continue
        price = db.session.scalar(
            select(ProductPrice.unit_price).where(
                ProductPrice.price_group_id == group_id,
                ProductPrice.product_id == product_id,
                ProductPrice.effective_from <= now,
                or_(ProductPrice.effective_to.is_(None), ProductPrice.effective_to >= today),
            )
        )
        if price is not None:
            return price
    return None
