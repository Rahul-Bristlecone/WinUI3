from datetime import datetime, time
from decimal import ROUND_HALF_UP, Decimal

from flask import Blueprint
from pydantic import Field, model_validator
from sqlalchemy import and_, func, or_, select

from supplier_service.catalogue.models import Product
from supplier_service.catalogue.routes import owned_product
from supplier_service.common.base_model import utcnow
from supplier_service.common.errors import ApiError, not_found
from supplier_service.common.http import (
    CalendarDate,
    OptionalText,
    RecordStatus,
    RequestSchema,
    Text,
    contains,
    iso_calendar_date,
    paginate,
    parse_body,
    record_status,
    search_term,
)
from supplier_service.common.security import current_supplier, require_supplier
from supplier_service.extensions.database import db
from supplier_service.pricing.models import PriceGroup, ProductPrice
from supplier_service.retailers.models import RetailerPriceGroup, SupplierConnection
from supplier_service.retailers.service import assignment_join, effective_price_group_id

bp = Blueprint("pricing", __name__, url_prefix="/api")
bp.before_request(require_supplier)


STANDARD_ALWAYS_ACTIVE = "The Standard price group can't be deactivated: retailers without a price group use it."


class PriceGroupRequest(RequestSchema):
    name: Text = Field(min_length=1, max_length=100)
    description: OptionalText = Field(default=None, max_length=1000)
    status: RecordStatus = "Active"


class ProductPriceRequest(RequestSchema):
    price: Decimal = Field(gt=0, le=Decimal("99999999.99"))
    # Omitted: today (UTC), so the price applies at once. The price grid sends only the price.
    effective_from: CalendarDate | None = None
    effective_to: CalendarDate | None = None

    @model_validator(mode="after")
    def _window(self):
        if self.effective_from is None:
            self.effective_from = utcnow().date()
        if self.effective_to is not None and self.effective_to < self.effective_from:
            raise ValueError("Effective To cannot be before Effective From.")
        return self


def price_group_json(group: PriceGroup, product_count: int, retailer_count: int) -> dict:
    return {
        "id": group.id,
        "name": group.group_name,
        "description": group.description or "",
        "status": record_status(group.is_active),
        "isDefault": group.is_default,
        "productCount": product_count,
        "retailerCount": retailer_count,
    }


def price_item_json(product: Product, price: ProductPrice | None) -> dict:
    return {
        "productId": product.id,
        "productCode": product.product_code,
        "productName": product.product_name,
        "price": price.unit_price if price else None,
        "effectiveFrom": iso_calendar_date(price.effective_from) if price else None,
        "effectiveTo": iso_calendar_date(price.effective_to) if price else None,
    }


def _groups_with_counts():
    product_count = (
        select(func.count(ProductPrice.id)).where(ProductPrice.price_group_id == PriceGroup.id).scalar_subquery()
    )
    retailer_count = (
        select(func.count(SupplierConnection.id))
        .select_from(SupplierConnection)
        .outerjoin(RetailerPriceGroup, assignment_join())
        .where(SupplierConnection.supplier_id == PriceGroup.supplier_id, effective_price_group_id() == PriceGroup.id)
        .scalar_subquery()
    )
    return (
        select(PriceGroup, product_count, retailer_count)
        .where(PriceGroup.supplier_id == current_supplier().id)
        .order_by(PriceGroup.is_default.desc(), PriceGroup.id)  # Standard first
    )


def _group_response(group_id: int) -> dict:
    return price_group_json(*db.session.execute(_groups_with_counts().where(PriceGroup.id == group_id)).one())


def owned_price_group(group_id: int) -> PriceGroup:
    group = db.session.scalar(select(PriceGroup).filter_by(id=group_id, supplier_id=current_supplier().id))
    if group is None:
        raise not_found()
    return group


@bp.get("/pricegroups")
def list_price_groups():
    return [price_group_json(*row) for row in db.session.execute(_groups_with_counts())]


@bp.post("/pricegroups")
def create_price_group():
    group = PriceGroup(supplier_id=current_supplier().id)
    _apply_group(group, parse_body(PriceGroupRequest))
    db.session.add(group)
    db.session.commit()
    return _group_response(group.id), 201


@bp.put("/pricegroups/<int:group_id>")
def update_price_group(group_id: int):
    group = owned_price_group(group_id)
    _apply_group(group, parse_body(PriceGroupRequest))
    db.session.commit()
    return _group_response(group.id)


@bp.post("/pricegroups/<int:group_id>/deactivate")
def deactivate_price_group(group_id: int):
    group = owned_price_group(group_id)
    if group.is_default:
        raise ApiError(400, STANDARD_ALWAYS_ACTIVE)
    in_group = (
        select(SupplierConnection.id)
        .outerjoin(RetailerPriceGroup, assignment_join())
        .where(SupplierConnection.supplier_id == group.supplier_id, effective_price_group_id() == group.id)
        .limit(1)
    )
    if db.session.scalar(in_group) is not None:
        raise ApiError(400, "Move the retailers in this group to another price group before deactivating it.")
    group.is_active = False
    db.session.commit()
    return "", 204


@bp.get("/pricegroups/matrix")
def price_matrix():
    """The Price Groups grid: active products (paged, searchable), each with its price in every group.

    items: [{ productId, productCode, productName, prices: { "<groupId>": price } }]; a group with no
    price for the product has no key.
    """
    supplier_id = current_supplier().id
    stmt = (
        select(Product)
        .where(Product.supplier_id == supplier_id, Product.is_active.is_(True))
        .order_by(Product.product_code, Product.id)
    )
    if term := search_term():
        pattern = contains(term)
        stmt = stmt.where(or_(Product.product_name.ilike(pattern, escape="\\"), Product.product_code.ilike(pattern, escape="\\")))
    page = paginate(stmt, lambda product: {
        "productId": product.id, "productCode": product.product_code, "productName": product.product_name, "prices": {},
    })
    prices = {item["productId"]: item["prices"] for item in page["items"]}
    if prices:
        rows = db.session.execute(
            select(ProductPrice.product_id, ProductPrice.price_group_id, ProductPrice.unit_price)
            .join(PriceGroup, PriceGroup.id == ProductPrice.price_group_id)
            .where(PriceGroup.supplier_id == supplier_id, ProductPrice.product_id.in_(prices))
        )
        for product_id, group_id, unit_price in rows:
            prices[product_id][str(group_id)] = unit_price
    return page


@bp.get("/pricegroups/<int:group_id>/prices")
def list_group_prices(group_id: int):
    group = owned_price_group(group_id)
    stmt = (
        select(Product, ProductPrice)
        .outerjoin(ProductPrice, and_(ProductPrice.product_id == Product.id, ProductPrice.price_group_id == group.id))
        .where(Product.supplier_id == current_supplier().id)
        .order_by(Product.product_code, Product.id)
    )
    if term := search_term():
        pattern = contains(term)
        stmt = stmt.where(or_(Product.product_name.ilike(pattern, escape="\\"), Product.product_code.ilike(pattern, escape="\\")))
    return paginate(stmt, lambda row: price_item_json(*row), scalars=False)


@bp.put("/pricegroups/<int:group_id>/prices/<int:product_id>")
def set_product_price(group_id: int, product_id: int):
    body = parse_body(ProductPriceRequest)
    group = owned_price_group(group_id)
    product = owned_product(product_id)
    price = db.session.scalar(select(ProductPrice).filter_by(price_group_id=group.id, product_id=product.id))
    if price is None:
        price = ProductPrice(price_group_id=group.id, product_id=product.id)
        db.session.add(price)
    price.unit_price = body.price.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    price.effective_from = datetime.combine(body.effective_from, time.min)
    price.effective_to = datetime.combine(body.effective_to, time.min) if body.effective_to else None
    db.session.commit()
    return price_item_json(product, price)


@bp.delete("/pricegroups/<int:group_id>/prices/<int:product_id>")
def remove_product_price(group_id: int, product_id: int):
    """Retailers in the group then see no price for the product."""
    group = owned_price_group(group_id)
    product = owned_product(product_id)
    price = db.session.scalar(select(ProductPrice).filter_by(price_group_id=group.id, product_id=product.id))
    if price is not None:
        db.session.delete(price)
        db.session.commit()
    return "", 204


def _apply_group(group: PriceGroup, body: PriceGroupRequest) -> None:
    clash = select(PriceGroup.id).where(
        PriceGroup.supplier_id == group.supplier_id, func.lower(PriceGroup.group_name) == body.name.lower()
    )
    if group.id is not None:
        clash = clash.where(PriceGroup.id != group.id)
    if db.session.scalar(clash) is not None:
        raise ApiError(409, "A price group with this name already exists.")
    if group.is_default and body.status != "Active":
        raise ApiError(400, STANDARD_ALWAYS_ACTIVE)
    group.group_name = body.name
    group.description = body.description
    group.is_active = body.status == "Active"
