from sqlalchemy import UniqueConstraint, false
from supplier_service.catalogue.models import Product
from supplier_service.common.base_model import BaseModel
from supplier_service.extensions.database import db

STANDARD_GROUP = "Standard"


class PriceGroup(BaseModel):
    __tablename__ = "price_groups"
    __table_args__ = (
        UniqueConstraint("supplier_id", "group_name", name="uq_price_group_name"),
    )
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False, index=True)
    group_name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    # The supplier's Standard group (one per supplier, created at registration): retailers without an
    # assigned group use it, and it can't be deactivated.
    is_default = db.Column(db.Boolean, nullable=False, default=False, server_default=false())
    supplier = db.relationship("Supplier", backref=db.backref("price_groups", lazy="dynamic"))


class ProductPrice(BaseModel):
    __tablename__ = "product_prices"
    __table_args__ = (
        UniqueConstraint("price_group_id", "product_id", name="uq_price_group_product"),
    )
    id = db.Column(db.Integer, primary_key=True)
    price_group_id = db.Column(db.Integer, db.ForeignKey("price_groups.id"), nullable=False, index=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)
    unit_price = db.Column(db.Numeric(10, 2), nullable=False)
    effective_from = db.Column(db.DateTime, nullable=False)
    effective_to = db.Column(db.DateTime, nullable=True)
    price_group = db.relationship("PriceGroup", backref=db.backref("products", lazy="dynamic"))
    product = db.relationship("Product", backref=db.backref("pricing", lazy="dynamic"))
