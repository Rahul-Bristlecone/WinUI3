"""Ledger balances.

What a retailer owes = opening balance + offline orders + online orders (sent invoices, GST included)
− payments. Voided entries don't count. Days are business days in BUSINESS_TIMEZONE: a recorded entry
carries its day, and an invoice belongs to the business day it was sent on.
"""

from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, time, timezone
from decimal import Decimal

from flask import current_app
from sqlalchemy import and_, func, select
from sqlalchemy.exc import IntegrityError

from supplier_service.common.base_model import utcnow
from supplier_service.extensions.database import db
from supplier_service.invoices.models import Invoice, InvoiceStatus
from supplier_service.ledger.models import EntryType, LedgerAccount, LedgerEntry
from supplier_service.retailers.models import SupplierConnection

ZERO = Decimal("0")


def business_today() -> date:
    return utcnow().astimezone(current_app.config["BUSINESS_TIMEZONE"]).date()


def business_day(stamp: datetime) -> date:
    """The business day of a stored timestamp (naive values are UTC)."""
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=timezone.utc)
    return stamp.astimezone(current_app.config["BUSINESS_TIMEZONE"]).date()


def day_start(day: date) -> datetime:
    """The UTC instant a business day starts, naive like the stored timestamps it is compared with."""
    start = datetime.combine(day, time.min, current_app.config["BUSINESS_TIMEZONE"])
    return start.astimezone(timezone.utc).replace(tzinfo=None)


def sent_invoices():
    """Invoices that count as online orders (drafts are only planned quantities)."""
    return Invoice.status != InvoiceStatus.DRAFT


@dataclass
class Totals:
    opening: Decimal = ZERO
    offline_orders: Decimal = ZERO
    online_orders: Decimal = ZERO
    payments: Decimal = ZERO

    @property
    def net(self) -> Decimal:
        return self.opening + self.offline_orders + self.online_orders - self.payments


_TOTALS_FIELD = {
    EntryType.OPENING_BALANCE: "opening",
    EntryType.OFFLINE_ORDER: "offline_orders",
    EntryType.PAYMENT: "payments",
}


def totals(supplier_id: int, start: date | None = None, end: date | None = None, account_id: int | None = None) -> dict[int, Totals]:
    """Per account id: what counts on business days start <= day < end (None = unbounded)."""
    result: dict[int, Totals] = defaultdict(Totals)

    recorded = (
        select(LedgerEntry.account_id, LedgerEntry.entry_type, func.sum(LedgerEntry.amount))
        .join(LedgerAccount, LedgerAccount.id == LedgerEntry.account_id)
        .where(LedgerAccount.supplier_id == supplier_id, LedgerEntry.voided_at.is_(None))
        .group_by(LedgerEntry.account_id, LedgerEntry.entry_type)
    )
    online = (
        select(LedgerAccount.id, func.sum(Invoice.grand_total))
        .join(Invoice, and_(Invoice.supplier_id == LedgerAccount.supplier_id, Invoice.retailer_id == LedgerAccount.retailer_id))
        .where(LedgerAccount.supplier_id == supplier_id, sent_invoices())
        .group_by(LedgerAccount.id)
    )
    if start is not None:
        recorded = recorded.where(LedgerEntry.entry_date >= start)
        online = online.where(Invoice.invoice_date >= day_start(start))
    if end is not None:
        recorded = recorded.where(LedgerEntry.entry_date < end)
        online = online.where(Invoice.invoice_date < day_start(end))
    if account_id is not None:
        recorded = recorded.where(LedgerAccount.id == account_id)
        online = online.where(LedgerAccount.id == account_id)

    for entry_account, entry_type, amount in db.session.execute(recorded):
        setattr(result[entry_account], _TOTALS_FIELD[entry_type], amount or ZERO)
    for entry_account, amount in db.session.execute(online):
        result[entry_account].online_orders = amount or ZERO
    return result


def _counted(supplier_id: int, entry_type: str, account_id: int | None):
    """WHERE clause: the supplier's non-voided entries of one type (optionally one account's)."""
    clause = and_(
        LedgerAccount.supplier_id == supplier_id,
        LedgerEntry.entry_type == entry_type,
        LedgerEntry.voided_at.is_(None),
    )
    return clause if account_id is None else and_(clause, LedgerAccount.id == account_id)


def last_payments(supplier_id: int, account_id: int | None = None) -> dict[int, tuple[date, Decimal]]:
    """Per account id: the latest day a payment was received, and the total received that day."""
    latest = (
        select(LedgerEntry.account_id, func.max(LedgerEntry.entry_date).label("day"))
        .join(LedgerAccount, LedgerAccount.id == LedgerEntry.account_id)
        .where(_counted(supplier_id, EntryType.PAYMENT, account_id))
        .group_by(LedgerEntry.account_id)
        .subquery()
    )
    rows = db.session.execute(
        select(LedgerEntry.account_id, latest.c.day, func.sum(LedgerEntry.amount))
        .join(LedgerAccount, LedgerAccount.id == LedgerEntry.account_id)
        .join(latest, and_(latest.c.account_id == LedgerEntry.account_id, latest.c.day == LedgerEntry.entry_date))
        .where(_counted(supplier_id, EntryType.PAYMENT, account_id))
        .group_by(LedgerEntry.account_id, latest.c.day)
    )
    return {account: (day, amount) for account, day, amount in rows}


def opening_balances(supplier_id: int, account_id: int | None = None) -> dict[int, tuple[date, Decimal]]:
    """Per account id: its opening balance and date. Linking two accounts can leave two: their total, from the earlier date."""
    rows = db.session.execute(
        select(LedgerEntry.account_id, func.min(LedgerEntry.entry_date), func.sum(LedgerEntry.amount))
        .join(LedgerAccount, LedgerAccount.id == LedgerEntry.account_id)
        .where(_counted(supplier_id, EntryType.OPENING_BALANCE, account_id))
        .group_by(LedgerEntry.account_id)
    )
    return {account: (day, amount) for account, day, amount in rows}


def ensure_online_accounts(supplier_id: int) -> None:
    """Gives every connected retailer, and every retailer invoiced, an account (the first time one is needed)."""
    connected = select(SupplierConnection.retailer_id).where(SupplierConnection.supplier_id == supplier_id)
    invoiced = select(Invoice.retailer_id).where(Invoice.supplier_id == supplier_id, sent_invoices())
    have = select(LedgerAccount.retailer_id).where(
        LedgerAccount.supplier_id == supplier_id, LedgerAccount.retailer_id.is_not(None)
    )
    missing = set(db.session.scalars(connected.union(invoiced))) - set(db.session.scalars(have))
    if not missing:
        return
    db.session.add_all(LedgerAccount(supplier_id=supplier_id, retailer_id=retailer_id) for retailer_id in sorted(missing))
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()  # another request created them first
