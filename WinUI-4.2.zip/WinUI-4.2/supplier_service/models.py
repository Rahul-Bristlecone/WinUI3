"""Imports every model so SQLAlchemy can resolve string relationships and Alembic sees the full schema."""

from supplier_service.auth.models import Supplier, SupplierSession
from supplier_service.catalogue.models import Category, Product
from supplier_service.circles.models import Circle, CircleLocation
from supplier_service.inventory.models import Inventory, InventoryTransaction
from supplier_service.invoices.models import Invoice, InvoiceLine
from supplier_service.ledger.models import LedgerAccount, LedgerEntry
from supplier_service.orders.models import Order, OrderItem
from supplier_service.pricing.models import PriceGroup, ProductPrice
from supplier_service.retailers.models import InvoiceAcceptance, Retailer, RetailerPriceGroup, SupplierConnection

__all__ = [
    "Category",
    "Circle",
    "CircleLocation",
    "Inventory",
    "InventoryTransaction",
    "Invoice",
    "InvoiceAcceptance",
    "InvoiceLine",
    "LedgerAccount",
    "LedgerEntry",
    "Order",
    "OrderItem",
    "PriceGroup",
    "Product",
    "ProductPrice",
    "Retailer",
    "RetailerPriceGroup",
    "Supplier",
    "SupplierConnection",
    "SupplierSession",
]
