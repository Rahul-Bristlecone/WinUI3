from flask import Blueprint, request
from sqlalchemy import or_, select

from supplier_service.circles.models import Circle, CircleLocation
from supplier_service.circles.service import area_json, checked_area
from supplier_service.common.errors import ApiError, not_found
from supplier_service.common.http import RequestSchema, contains, iso_timestamp, paginate, parse_body, search_term
from supplier_service.common.security import current_supplier, require_supplier
from supplier_service.extensions.database import db
from supplier_service.pricing.models import PriceGroup
from supplier_service.retailers.models import (
    Retailer, RetailerPriceGroup, RetailerSettings, RetailerStatus, SupplierConnection,
)
from supplier_service.retailers.service import retailer_rows, settings_for

bp = Blueprint("retailers", __name__, url_prefix="/api")
bp.before_request(require_supplier)


class ChangePriceGroupRequest(RequestSchema):
    price_group_id: int


class GstApplicableRequest(RequestSchema):
    gst_applicable: bool


class AreaRequest(RequestSchema):
    # A null circle clears both.
    circle_id: int | None = None
    location_id: int | None = None


def retailer_json(
    connection: SupplierConnection,
    retailer: Retailer,
    group: PriceGroup | None,
    gst_applicable: bool,
    circle: Circle | None,
    location: CircleLocation | None,
) -> dict:
    return {
        "id": retailer.id,
        "retailerCode": retailer.retailer_code or "",
        "name": retailer.business_name,
        "contactPerson": retailer.contact_person,
        "email": retailer.email,
        "phone": retailer.phone,
        "address": retailer.address,
        "city": retailer.city,
        "state": retailer.state,
        "postalCode": retailer.postal_code,
        "country": retailer.country,
        "gstNumber": retailer.gst_number or "",
        # The assigned group, else the supplier's Standard group; 0 / "" only if the supplier somehow has no Standard group.
        "priceGroupId": group.id if group else 0,
        "priceGroupName": group.group_name if group else "",
        "connectionDate": iso_timestamp(connection.connected_at),
        "status": RetailerStatus.from_db(connection.status),
        "gstApplicable": gst_applicable,
        **area_json(circle, location),
    }


def _retailer_response(retailer_id: int) -> dict:
    row = db.session.execute(retailer_rows(current_supplier().id).where(SupplierConnection.retailer_id == retailer_id)).one()
    return retailer_json(*row)


def _connection(retailer_id: int) -> SupplierConnection:
    connection = db.session.scalar(
        select(SupplierConnection).filter_by(supplier_id=current_supplier().id, retailer_id=retailer_id)
    )
    if connection is None:
        raise not_found()
    return connection


@bp.get("/retailers")
def list_retailers():
    """circleId and locationId filter, alongside search and paging."""
    stmt = retailer_rows(current_supplier().id)
    if term := search_term():
        pattern = contains(term)
        stmt = stmt.where(
            or_(Retailer.business_name.ilike(pattern, escape="\\"), Retailer.retailer_code.ilike(pattern, escape="\\"))
        )
    if (circle_id := request.args.get("circleId", type=int)) is not None:
        stmt = stmt.where(RetailerSettings.circle_id == circle_id)
    if (location_id := request.args.get("locationId", type=int)) is not None:
        stmt = stmt.where(RetailerSettings.location_id == location_id)
    return paginate(stmt, lambda row: retailer_json(*row), scalars=False)


@bp.put("/retailers/<int:retailer_id>/price-group")
def change_price_group(retailer_id: int):
    body = parse_body(ChangePriceGroupRequest)
    supplier_id = current_supplier().id
    _connection(retailer_id)
    group = db.session.scalar(select(PriceGroup).filter_by(id=body.price_group_id, supplier_id=supplier_id, is_active=True))
    if group is None:
        raise ApiError(400, "Price group not found or inactive.")
    assignment = db.session.scalar(select(RetailerPriceGroup).filter_by(supplier_id=supplier_id, retailer_id=retailer_id))
    if assignment is None:
        db.session.add(RetailerPriceGroup(supplier_id=supplier_id, retailer_id=retailer_id, price_group_id=group.id))
    else:
        assignment.price_group_id = group.id
    db.session.commit()
    return _retailer_response(retailer_id)


@bp.put("/retailers/<int:retailer_id>/gst")
def set_gst_applicable(retailer_id: int):
    """Applies to invoices raised from now on; invoices already sent keep their tax."""
    body = parse_body(GstApplicableRequest)
    supplier_id = current_supplier().id
    _connection(retailer_id)
    settings_for(supplier_id, retailer_id).gst_applicable = body.gst_applicable
    db.session.commit()
    return _retailer_response(retailer_id)


@bp.put("/retailers/<int:retailer_id>/area")
def set_area(retailer_id: int):
    """The retailer's circle, and optionally one of its locations."""
    body = parse_body(AreaRequest)
    supplier_id = current_supplier().id
    _connection(retailer_id)
    settings = settings_for(supplier_id, retailer_id)
    settings.circle_id, settings.location_id = checked_area(supplier_id, body.circle_id, body.location_id)
    db.session.commit()
    return _retailer_response(retailer_id)


@bp.post("/retailers/<int:retailer_id>/block")
def block_retailer(retailer_id: int):
    return _set_status(retailer_id, RetailerStatus.BLOCKED)


@bp.post("/retailers/<int:retailer_id>/activate")
def activate_retailer(retailer_id: int):
    return _set_status(retailer_id, RetailerStatus.ACTIVE)


def _set_status(retailer_id: int, status: str) -> dict:
    _connection(retailer_id).status = status
    db.session.commit()
    return _retailer_response(retailer_id)
