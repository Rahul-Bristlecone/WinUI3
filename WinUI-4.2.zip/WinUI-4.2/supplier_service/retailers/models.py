from sqlalchemy import UniqueConstraint, true
from supplier_service.common.base_model import BaseModel, utcnow
from supplier_service.extensions.database import db

# The `retailer` schema belongs to the retailer service. These models map the columns this
# service reads (and, for supplier_connections.status, writes); Alembic never creates or alters them
# (see extensions/database.py:skip_external_tables).
RETAILER_SCHEMA = "retailer"


class RetailerStatus:
    ACTIVE = "Active"
    BLOCKED = "Blocked"
    VALUES = {ACTIVE, BLOCKED}

    @classmethod
    def from_db(cls, value: str | None) -> str:
        """The supplier portal only distinguishes blocked retailers; any other connection state reads as Active."""
        return cls.BLOCKED if (value or "").strip().lower() == "blocked" else cls.ACTIVE


class Retailer(db.Model):
    __tablename__ = "retailers"
    __table_args__ = {"schema": RETAILER_SCHEMA}
    id = db.Column(db.Integer, primary_key=True)
    retailer_code = db.Column(db.String(16), nullable=True)
    business_name = db.Column(db.String(120), nullable=False)
    contact_person = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(254), nullable=False)
    # Never loaded by this service; mapped so tests and the demo seed can create retailers.
    password_hash = db.deferred(db.Column(db.String(255), nullable=False))
    phone = db.Column(db.String(20), nullable=False)
    address = db.Column(db.String(500), nullable=False)
    city = db.Column(db.String(100), nullable=False)
    state = db.Column(db.String(100), nullable=False)
    country = db.Column(db.String(100), nullable=False)
    postal_code = db.Column(db.String(10), nullable=False)
    gst_number = db.Column(db.String(15), nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)

    @property
    def full_address(self) -> str:
        return f"{self.address}\n{self.city}, {self.state}, {self.postal_code}, {self.country}"


class SupplierConnection(db.Model):
    """A retailer's connection to a supplier. The supplier portal changes `status` (block / activate)."""

    __tablename__ = "supplier_connections"
    __table_args__ = (
        UniqueConstraint("retailer_id", "supplier_id", name="uq_retailer_supplier"),
        {"schema": RETAILER_SCHEMA},
    )
    id = db.Column(db.Integer, primary_key=True)
    retailer_id = db.Column(db.Integer, db.ForeignKey(f"{RETAILER_SCHEMA}.retailers.id"), nullable=False, index=True)
    supplier_id = db.Column(db.Integer, nullable=False, index=True)
    status = db.Column(db.String(20), nullable=False, default=RetailerStatus.ACTIVE)
    connected_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)
    retailer = db.relationship("Retailer")


class InvoiceAcceptance(db.Model):
    """Written by the retailer service when a retailer accepts an invoice."""

    __tablename__ = "invoice_acceptances"
    __table_args__ = {"schema": RETAILER_SCHEMA}
    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, nullable=False, unique=True)
    retailer_id = db.Column(db.Integer, db.ForeignKey(f"{RETAILER_SCHEMA}.retailers.id"), nullable=False, index=True)
    accepted_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)


class OrderDelivery(db.Model):
    """Written by the retailer service when an order is placed: the delivery location the retailer picked, copied
    so later edits to the location don't change it. Orders placed before the retailer service recorded this have none."""

    __tablename__ = "order_deliveries"
    __table_args__ = {"schema": RETAILER_SCHEMA}
    order_id = db.Column(db.Integer, primary_key=True)  # the supplier service's orders.id
    retailer_id = db.Column(db.Integer, db.ForeignKey(f"{RETAILER_SCHEMA}.retailers.id"), nullable=False)
    location_type = db.Column(db.String(20), nullable=False)  # e.g. "Store"
    name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    address = db.Column(db.String(500), nullable=False)
    city = db.Column(db.String(100), nullable=False)
    state = db.Column(db.String(100), nullable=False)
    country = db.Column(db.String(100), nullable=False)
    postal_code = db.Column(db.String(10), nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)


class RetailerPriceGroup(BaseModel):
    """The price group a supplier has put a retailer in. Retailers without a row use the supplier's default group."""

    __tablename__ = "retailer_price_groups"
    __table_args__ = (
        UniqueConstraint("supplier_id", "retailer_id", name="uq_retailer_price_group"),
    )
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False, index=True)
    # No foreign key: retailers live in the retailer service's schema.
    retailer_id = db.Column(db.Integer, nullable=False, index=True)
    price_group_id = db.Column(db.Integer, db.ForeignKey("price_groups.id"), nullable=False, index=True)
    price_group = db.relationship("PriceGroup")


class RetailerSettings(BaseModel):
    """A supplier's own settings for one retailer. Retailers without a row use the defaults."""

    __tablename__ = "retailer_settings"
    __table_args__ = (
        UniqueConstraint("supplier_id", "retailer_id", name="uq_retailer_settings"),
    )
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False, index=True)
    # No foreign key: retailers live in the retailer service's schema.
    retailer_id = db.Column(db.Integer, nullable=False, index=True)
    # False: invoices to this retailer are raised without GST.
    gst_applicable = db.Column(db.Boolean, nullable=False, default=True, server_default=true())
    # The supplier's circle for the retailer, optionally with one of its locations (see circles/service.py).
    circle_id = db.Column(db.Integer, db.ForeignKey("circles.id"), nullable=True, index=True)
    location_id = db.Column(db.Integer, db.ForeignKey("circle_locations.id"), nullable=True, index=True)
