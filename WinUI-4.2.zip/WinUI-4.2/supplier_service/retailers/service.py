from sqlalchemy import and_, func, select, true
from sqlalchemy.orm import aliased

from supplier_service.circles.models import Circle, CircleLocation
from supplier_service.extensions.database import db
from supplier_service.pricing.models import PriceGroup
from supplier_service.retailers.models import (
    OrderDelivery, Retailer, RetailerPriceGroup, RetailerSettings, SupplierConnection,
)


def assignment_join():
    """ON clause linking a connection to the supplier's price-group assignment for that retailer."""
    return and_(
        RetailerPriceGroup.supplier_id == SupplierConnection.supplier_id,
        RetailerPriceGroup.retailer_id == SupplierConnection.retailer_id,
    )


def effective_price_group_id():
    """SQL: the retailer's assigned group, else the supplier's Standard group.

    Needs SupplierConnection and an outer join to RetailerPriceGroup (assignment_join) in the query.
    """
    candidate = aliased(PriceGroup)  # aliased so it isn't correlated with PriceGroup in the outer query
    default = (
        select(candidate.id)
        .where(candidate.supplier_id == SupplierConnection.supplier_id, candidate.is_default.is_(True))
        .limit(1)
        .scalar_subquery()
    )
    return func.coalesce(RetailerPriceGroup.price_group_id, default)


def settings_for(supplier_id: int, retailer_id: int) -> RetailerSettings:
    """The supplier's settings row for a retailer, created (with the defaults) on first change."""
    settings = db.session.scalar(select(RetailerSettings).filter_by(supplier_id=supplier_id, retailer_id=retailer_id))
    if settings is None:
        settings = RetailerSettings(supplier_id=supplier_id, retailer_id=retailer_id)
        db.session.add(settings)
    return settings


def delivery_address_json(order_id: int) -> dict | None:
    """Where the retailer asked for the order to be delivered, or None if the order predates delivery addresses."""
    delivery = db.session.get(OrderDelivery, order_id)
    if delivery is None:
        return None
    return {
        "name": delivery.name,
        "locationType": delivery.location_type,
        "phone": delivery.phone,
        "address": delivery.address,
        "city": delivery.city,
        "state": delivery.state,
        "postalCode": delivery.postal_code,
        "country": delivery.country,
    }


def gst_applicable(supplier_id: int, retailer_id: int) -> bool:
    """True unless the supplier has turned GST off for this retailer."""
    value = db.session.scalar(
        select(RetailerSettings.gst_applicable).filter_by(supplier_id=supplier_id, retailer_id=retailer_id)
    )
    return True if value is None else value


def retailer_rows(supplier_id: int):
    """select(SupplierConnection, Retailer, PriceGroup | None, gst_applicable, Circle | None, CircleLocation | None)
    for a supplier's connected retailers."""
    return (
        select(
            SupplierConnection, Retailer, PriceGroup,
            func.coalesce(RetailerSettings.gst_applicable, true()), Circle, CircleLocation,
        )
        .join(Retailer, Retailer.id == SupplierConnection.retailer_id)
        .outerjoin(RetailerPriceGroup, assignment_join())
        .outerjoin(PriceGroup, PriceGroup.id == effective_price_group_id())
        .outerjoin(
            RetailerSettings,
            and_(
                RetailerSettings.supplier_id == SupplierConnection.supplier_id,
                RetailerSettings.retailer_id == SupplierConnection.retailer_id,
            ),
        )
        .outerjoin(Circle, Circle.id == RetailerSettings.circle_id)
        .outerjoin(CircleLocation, CircleLocation.id == RetailerSettings.location_id)
        .where(SupplierConnection.supplier_id == supplier_id)
        .order_by(Retailer.business_name, Retailer.id)
    )
