from flask import Blueprint
from sqlalchemy import case, func, select

from supplier_service.catalogue.models import Product
from supplier_service.common.security import current_supplier, require_supplier
from supplier_service.extensions.database import db
from supplier_service.invoices.models import Invoice, InvoiceStatus
from supplier_service.orders.models import Order, OrderStatus
from supplier_service.orders.schemas import order_json, order_rows
from supplier_service.retailers.models import SupplierConnection

bp = Blueprint("dashboard", __name__, url_prefix="/api")
bp.before_request(require_supplier)

RECENT_ORDERS = 15


@bp.get("/dashboard")
def dashboard():
    supplier_id = current_supplier().id

    def count(column, *conditions) -> int:
        return db.session.scalar(select(func.count(column)).where(*conditions)) or 0

    pending_first = case((Order.status == OrderStatus.PENDING, 0), else_=1)
    recent = db.session.execute(
        order_rows(supplier_id).order_by(pending_first, Order.order_date.desc(), Order.id.desc()).limit(RECENT_ORDERS)
    ).all()
    return {
        "totalProducts": count(Product.id, Product.supplier_id == supplier_id, Product.is_active.is_(True)),
        "totalRetailers": count(SupplierConnection.id, SupplierConnection.supplier_id == supplier_id),
        "pendingOrders": count(Order.id, Order.supplier_id == supplier_id, Order.status == OrderStatus.PENDING),
        "invoicesSent": count(Invoice.id, Invoice.supplier_id == supplier_id, Invoice.status != InvoiceStatus.DRAFT),
        "orders": [order_json(*row) for row in recent],
    }
