"""Where product image files live.

`ImageStorage` is the only thing the rest of the service knows about image files, so moving from local
disk to object storage (Azure Blob / S3 behind a CDN) means adding a class here and a config value;
routes, the database column and the API responses stay the same. Keys are plain file names.
"""

from pathlib import Path
from typing import Protocol

from flask import current_app, url_for


class ImageStorage(Protocol):
    def save(self, key: str, data: bytes) -> None: ...

    def exists(self, key: str) -> bool: ...

    def read(self, key: str) -> bytes: ...

    def delete(self, key: str) -> None:
        """Removes the file; a missing file is not an error."""

    def url(self, key: str) -> str:
        """Absolute URL a client can load the file from (a CDN URL for cloud backends)."""


class LocalImageStorage:
    """Files under UPLOAD_FOLDER/products, served by the service itself at /media/products/<key>."""

    @property
    def folder(self) -> Path:
        return Path(current_app.config["UPLOAD_FOLDER"]) / "products"

    def _path(self, key: str) -> Path:
        return self.folder / Path(key).name  # never anything but a file name

    def save(self, key: str, data: bytes) -> None:
        self.folder.mkdir(parents=True, exist_ok=True)
        self._path(key).write_bytes(data)

    def exists(self, key: str) -> bool:
        return self._path(key).is_file()

    def read(self, key: str) -> bytes:
        return self._path(key).read_bytes()

    def delete(self, key: str) -> None:
        self._path(key).unlink(missing_ok=True)

    def url(self, key: str) -> str:
        base = current_app.config.get("PUBLIC_BASE_URL")
        if base:
            return f"{base.rstrip('/')}/media/products/{key}"
        return url_for("media.product_image", filename=key, _external=True)


def get_storage() -> ImageStorage:
    backend = current_app.config["IMAGE_STORAGE"]
    if backend == "local":
        return LocalImageStorage()
    raise RuntimeError(f"Unknown IMAGE_STORAGE '{backend}' (supported: local).")
