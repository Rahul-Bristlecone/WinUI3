from flask import Blueprint, request, send_from_directory
from sqlalchemy import asc, case, desc, func, or_, select
from sqlalchemy.orm import selectinload

from supplier_service.catalogue import images
from supplier_service.catalogue.storage import LocalImageStorage
from supplier_service.catalogue.models import Category, Product
from supplier_service.catalogue.schemas import CategoryRequest, ProductRequest, category_json, product_json
from supplier_service.common.errors import ApiError, not_found
from supplier_service.common.http import contains, paginate, parse_body, search_term, sort_descending
from supplier_service.common.security import current_supplier, require_supplier
from supplier_service.extensions.database import db
from supplier_service.inventory.models import Inventory, ReferenceType, TransactionType
from supplier_service.inventory.service import new_inventory, record_movement

bp = Blueprint("catalogue", __name__, url_prefix="/api")
bp.before_request(require_supplier)

# Public: the client's Image control loads imageUrl without an Authorization header.
media_bp = Blueprint("media", __name__, url_prefix="/media")


# ---- categories ---------------------------------------------------------------------------------


def _categories():
    return (
        select(Category)
        .where(Category.supplier_id == current_supplier().id)
        .options(selectinload(Category.parent_category))
        .order_by(Category.category_name, Category.id)
    )


def find_category(category_id: int) -> Category | None:
    return db.session.scalar(select(Category).filter_by(id=category_id, supplier_id=current_supplier().id))


def owned_category(category_id: int) -> Category:
    category = find_category(category_id)
    if category is None:
        raise not_found()
    return category


@bp.get("/categories")
def list_categories():
    stmt = _categories()
    if term := search_term():
        stmt = stmt.where(Category.category_name.ilike(contains(term), escape="\\"))
    return paginate(stmt, category_json)


@bp.get("/categories/all")
def all_categories():
    return [category_json(c) for c in db.session.scalars(_categories())]


@bp.post("/categories")
def create_category():
    category = Category(supplier_id=current_supplier().id)
    _apply_category(category, parse_body(CategoryRequest))
    db.session.add(category)
    db.session.commit()
    return category_json(category), 201


@bp.put("/categories/<int:category_id>")
def update_category(category_id: int):
    category = owned_category(category_id)
    _apply_category(category, parse_body(CategoryRequest))
    db.session.commit()
    return category_json(category)


@bp.post("/categories/<int:category_id>/deactivate")
def deactivate_category(category_id: int):
    category = owned_category(category_id)
    category.is_active = False
    db.session.commit()
    return "", 204


def _apply_category(category: Category, body: CategoryRequest) -> None:
    clash = select(Category.id).where(
        Category.supplier_id == category.supplier_id,
        func.lower(Category.category_name) == body.name.lower(),
    )
    if category.id is not None:
        clash = clash.where(Category.id != category.id)
    if db.session.scalar(clash) is not None:
        raise ApiError(409, "A category with this name already exists.")

    parent = None
    if body.parent_category_id is not None:
        parent = find_category(body.parent_category_id)
        if parent is None:
            raise ApiError(400, "Parent category not found.")
        if category.id is not None and _is_self_or_descendant(parent, category):
            raise ApiError(400, "A category cannot be its own parent or sit under one of its subcategories.")

    category.category_name = body.name
    category.parent_category = parent
    category.is_active = body.status == "Active"


def _is_self_or_descendant(candidate: Category, ancestor: Category) -> bool:
    seen = set()
    node = candidate
    while node is not None and node.id not in seen:
        if node.id == ancestor.id:
            return True
        seen.add(node.id)
        node = node.parent_category
    return False


# ---- products -----------------------------------------------------------------------------------


def owned_product(product_id: int) -> Product:
    product = db.session.scalar(select(Product).filter_by(id=product_id, supplier_id=current_supplier().id))
    if product is None:
        raise not_found()
    return product


@bp.get("/products")
def list_products():
    stock = func.coalesce(Inventory.on_hand_quantity, 0).label("stock")
    stmt = (
        select(Product, stock, Category.category_name)
        .outerjoin(Inventory, Inventory.product_id == Product.id)
        .outerjoin(Category, Category.id == Product.category_id)
        .where(Product.supplier_id == current_supplier().id)
    )
    if term := search_term():
        pattern = contains(term)
        stmt = stmt.where(or_(Product.product_name.ilike(pattern, escape="\\"), Product.product_code.ilike(pattern, escape="\\")))
    if (category_id := request.args.get("categoryId", type=int)) is not None:
        stmt = stmt.where(Product.category_id == category_id)
    if (status := request.args.get("status")) in ("Active", "Inactive"):
        stmt = stmt.where(Product.is_active == (status == "Active"))

    sort_keys = {
        "name": Product.product_name,
        "category": Category.category_name,
        "uom": Product.unit_of_measure,
        "stock": stock,
        "status": case((Product.is_active, 0), else_=1),
    }
    key = sort_keys.get(request.args.get("sortBy"), Product.product_code)
    stmt = stmt.order_by((desc if sort_descending() else asc)(key), Product.id)
    return paginate(stmt, lambda row: product_json(*row), scalars=False)


@bp.post("/products")
def create_product():
    body = parse_body(ProductRequest)
    supplier = current_supplier()
    product = Product(supplier_id=supplier.id)
    category = _apply_product(product, body)
    db.session.add(product)
    db.session.flush()

    inventory = new_inventory(product.id)
    db.session.add(inventory)
    if body.initial_stock:
        record_movement(
            inventory, TransactionType.STOCK_ADDED, body.initial_stock,
            reference_type=ReferenceType.OPENING_STOCK, remarks="Opening stock",
        )
    db.session.commit()
    return product_json(product, inventory.on_hand_quantity, category.category_name), 201


@bp.put("/products/<int:product_id>")
def update_product(product_id: int):
    product = owned_product(product_id)
    _apply_product(product, parse_body(ProductRequest))
    db.session.commit()
    return _product_response(product)


@bp.post("/products/<int:product_id>/deactivate")
def deactivate_product(product_id: int):
    owned_product(product_id).is_active = False
    db.session.commit()
    return "", 204


@bp.post("/products/<int:product_id>/image")
def upload_product_image(product_id: int):
    product = owned_product(product_id)
    upload = request.files.get("file")
    if upload is None or not upload.filename:
        raise ApiError(400, "An image file is required (multipart field 'file').")
    new_name = images.store_product_image(product.id, upload)
    old_name, product.image_filename = product.image_filename, new_name
    try:
        db.session.commit()
    except Exception:
        images.delete_product_image(new_name)
        raise
    images.delete_product_image(old_name)
    return _product_response(product)


@bp.delete("/products/<int:product_id>/image")
def delete_product_image(product_id: int):
    product = owned_product(product_id)
    old_name, product.image_filename = product.image_filename, None
    db.session.commit()
    images.delete_product_image(old_name)
    return "", 204


@media_bp.get("/products/<filename>")
def product_image(filename: str):
    # Local-disk storage only: with cloud storage the CDN serves these files and this route goes away.
    images.ensure_thumbnail(filename)  # images uploaded before thumbnails existed get theirs on first request
    # File names are unique per upload, so they can be cached indefinitely.
    return send_from_directory(LocalImageStorage().folder, filename, max_age=31_536_000)


def _apply_product(product: Product, body: ProductRequest) -> Category:
    code_clash = select(Product.id).where(
        Product.supplier_id == product.supplier_id, func.upper(Product.product_code) == body.product_code
    )
    if product.id is not None:
        code_clash = code_clash.where(Product.id != product.id)
    if db.session.scalar(code_clash) is not None:
        raise ApiError(409, f"Product code '{body.product_code}' already exists.")

    if body.barcode is not None:
        barcode_clash = select(Product.id).where(Product.barcode == body.barcode)
        if product.id is not None:
            barcode_clash = barcode_clash.where(Product.id != product.id)
        if db.session.scalar(barcode_clash) is not None:
            raise ApiError(409, f"Barcode '{body.barcode}' is already in use.")

    category = find_category(body.category_id)
    if category is None:
        raise ApiError(400, "Category not found.")
    product.product_code = body.product_code
    product.product_name = body.name
    product.description = body.description
    product.category = category
    product.unit_of_measure = body.unit_of_measure
    product.barcode = body.barcode
    product.is_active = body.status == "Active"
    return category


def _product_response(product: Product) -> dict:
    stock = product.inventory.on_hand_quantity if product.inventory else 0
    return product_json(product, stock, product.category.category_name if product.category else None)
