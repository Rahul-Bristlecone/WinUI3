"""Product images: validation, thumbnails, naming. File storage itself is in storage.py.

Each upload is stored twice under fresh names, so clients never show a cached copy of a replaced image:
  <productId>-<uuid>.png|jpg          the original, as uploaded (served as imageUrl)
  <productId>-<uuid>-thumb.jpg        a small JPEG for lists and previews (served as thumbnailUrl)
Only the original's name is saved on the product; the thumbnail's name is derived from it.
"""

import logging
import re
from io import BytesIO
from pathlib import Path
from uuid import uuid4

from flask import current_app
from PIL import Image, ImageOps, UnidentifiedImageError
from werkzeug.datastructures import FileStorage

from supplier_service.catalogue.storage import get_storage
from supplier_service.common.errors import ApiError

log = logging.getLogger(__name__)

# Extension -> (Pillow format, leading magic bytes). The file name alone is not trusted.
_FORMATS = {
    ".png": ("PNG", b"\x89PNG\r\n\x1a\n"),
    ".jpg": ("JPEG", b"\xff\xd8\xff"),
    ".jpeg": ("JPEG", b"\xff\xd8\xff"),
}
_THUMB_SUFFIX = "-thumb.jpg"
_THUMB_NAME = re.compile(r"^(?P<stem>\d+-[0-9a-f]{32})" + re.escape(_THUMB_SUFFIX) + "$")
_NOT_AN_IMAGE = "The file is not a valid PNG or JPEG image."


def thumbnail_key(name: str) -> str:
    return f"{Path(name).stem}{_THUMB_SUFFIX}"


def store_product_image(product_id: int, upload: FileStorage) -> str:
    """Validates the upload, stores it and its thumbnail; returns the original's file name."""
    extension = Path(upload.filename or "").suffix.lower()
    if extension not in _FORMATS:
        raise ApiError(400, "Only PNG or JPEG images are supported.")
    limit = current_app.config["MAX_IMAGE_BYTES"]
    data = upload.stream.read(limit + 1)
    if len(data) > limit:
        raise ApiError(400, f"Image must be {limit // (1024 * 1024)} MB or smaller.")
    image_format, signature = _FORMATS[extension]
    if not data.startswith(signature):
        raise ApiError(400, _NOT_AN_IMAGE)

    thumbnail = _checked_thumbnail(data, image_format)  # decoding the whole file also catches truncated images

    stem = f"{product_id}-{uuid4().hex}"
    name = f"{stem}{'.png' if image_format == 'PNG' else '.jpg'}"
    storage = get_storage()
    storage.save(name, data)
    storage.save(f"{stem}{_THUMB_SUFFIX}", thumbnail)
    return name


def delete_product_image(name: str | None) -> None:
    """Best effort: a leftover file is harmless, failing the request over one is not."""
    if not name:
        return
    storage = get_storage()
    for key in (name, thumbnail_key(name)):
        try:
            storage.delete(key)
        except OSError:  # e.g. still open by a download on Windows
            log.warning("Could not delete product image %s", key, exc_info=True)


def product_image_url(name: str | None) -> str | None:
    return get_storage().url(name) if name else None


def product_thumbnail_url(name: str | None) -> str | None:
    return get_storage().url(thumbnail_key(name)) if name else None


def ensure_thumbnail(key: str) -> None:
    """Creates a missing thumbnail from its original (images uploaded before thumbnails existed)."""
    match = _THUMB_NAME.match(key)
    storage = get_storage()
    if match is None or storage.exists(key):
        return
    for extension in (".png", ".jpg"):
        original = f"{match['stem']}{extension}"
        if storage.exists(original):
            try:
                storage.save(key, make_thumbnail(storage.read(original)))
            except (OSError, UnidentifiedImageError, Image.DecompressionBombError):
                log.warning("Could not create thumbnail %s", key, exc_info=True)
            return


def _checked_thumbnail(data: bytes, expected_format: str) -> bytes:
    try:
        with Image.open(BytesIO(data)) as image:
            if image.format != expected_format:
                raise ApiError(400, _NOT_AN_IMAGE)
            width, height = image.size
            if width * height > current_app.config["MAX_IMAGE_PIXELS"]:
                raise ApiError(400, "The image's dimensions are too large.")
        return make_thumbnail(data)
    except (OSError, UnidentifiedImageError, Image.DecompressionBombError, SyntaxError, ValueError):
        raise ApiError(400, _NOT_AN_IMAGE) from None


def make_thumbnail(data: bytes) -> bytes:
    """A JPEG no larger than THUMBNAIL_SIZE on its longer side (also drops metadata such as GPS)."""
    size = current_app.config["THUMBNAIL_SIZE"]
    with Image.open(BytesIO(data)) as source:
        image = ImageOps.exif_transpose(source)  # honour the camera's rotation before it is lost
        image.thumbnail((size, size), Image.Resampling.LANCZOS)
        if image.mode in ("RGBA", "LA", "P"):  # JPEG has no transparency: flatten onto white
            image = image.convert("RGBA")
            flattened = Image.new("RGB", image.size, "white")
            flattened.paste(image, mask=image.getchannel("A"))
            image = flattened
        else:
            image = image.convert("RGB")
        out = BytesIO()
        image.save(out, "JPEG", quality=82, optimize=True)
        return out.getvalue()
