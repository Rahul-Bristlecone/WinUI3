from sqlalchemy import UniqueConstraint
from supplier_service.auth.models import Supplier
from supplier_service.common.base_model import BaseModel
from supplier_service.extensions.database import db


class Category(BaseModel):
    __tablename__ = "categories"
    __table_args__ = (
        UniqueConstraint("supplier_id", "category_name", name="uq_supplier_category_name"),
    )
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False, index=True)
    category_name = db.Column(db.String(150), nullable=False)
    parent_category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=True)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    supplier = db.relationship("Supplier", backref=db.backref("categories", lazy="dynamic"))
    parent_category = db.relationship("Category", remote_side="Category.id", backref="children")


class Product(BaseModel):
    __tablename__ = "products"
    __table_args__ = (
        UniqueConstraint("supplier_id", "product_code", name="uq_supplier_product_code"),
        UniqueConstraint("barcode", name="uq_products_barcode"),
    )
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False, index=True)
    product_code = db.Column(db.String(64), nullable=False)
    product_name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=True)
    unit_of_measure = db.Column(db.String(64), nullable=False, default="pcs")
    barcode = db.Column(db.String(128), nullable=True, unique=True, index=True)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    # Stored file name under UPLOAD_FOLDER/products (see catalogue/images.py); served at /media/products/<name>.
    image_filename = db.Column(db.String(255), nullable=True)
    supplier = db.relationship("Supplier", backref=db.backref("products", lazy="dynamic"))
    category = db.relationship("Category", backref=db.backref("products", lazy="dynamic"))
