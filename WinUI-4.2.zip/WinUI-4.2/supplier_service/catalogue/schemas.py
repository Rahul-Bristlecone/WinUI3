import re

from pydantic import Field, field_validator

from supplier_service.catalogue.images import product_image_url, product_thumbnail_url
from supplier_service.catalogue.models import Category, Product
from supplier_service.common.http import OptionalText, Quantity, RecordStatus, RequestSchema, Text, record_status

PRODUCT_CODE_RULE = re.compile(r"^[A-Za-z0-9\-_]{2,64}$")


class CategoryRequest(RequestSchema):
    name: Text = Field(min_length=1, max_length=150)
    parent_category_id: int | None = None
    status: RecordStatus = "Active"


class ProductRequest(RequestSchema):
    product_code: Text
    name: Text = Field(min_length=1, max_length=255)
    description: OptionalText = None
    category_id: int
    unit_of_measure: Text = Field(default="pcs", min_length=1, max_length=64)
    initial_stock: Quantity = Field(default=0, ge=0)  # only used on create
    status: RecordStatus = "Active"
    barcode: OptionalText = Field(default=None, max_length=128)

    @field_validator("product_code")
    @classmethod
    def _product_code(cls, value: str) -> str:
        if not PRODUCT_CODE_RULE.fullmatch(value):
            raise ValueError("Product code must be 2–64 letters, digits, '-' or '_'.")
        return value.upper()


def category_json(category: Category) -> dict:
    parent = category.parent_category
    return {
        "id": category.id,
        "name": category.category_name,
        "parentCategoryId": category.parent_category_id,
        "parentCategoryName": parent.category_name if parent else None,
        "status": record_status(category.is_active),
    }


def product_json(product: Product, current_stock: int, category_name: str | None) -> dict:
    return {
        "id": product.id,
        "productCode": product.product_code,
        "name": product.product_name,
        "description": product.description or "",
        # The client's CategoryId is a non-nullable int.
        "categoryId": product.category_id or 0,
        "categoryName": category_name or "",
        "unitOfMeasure": product.unit_of_measure,
        "barcode": product.barcode,
        "currentStock": current_stock,
        "status": record_status(product.is_active),
        "imageUrl": product_image_url(product.image_filename),
        # ~256 px JPEG for lists and previews; null when there is no image.
        "thumbnailUrl": product_thumbnail_url(product.image_filename),
    }
